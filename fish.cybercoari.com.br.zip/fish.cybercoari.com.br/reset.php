<?php
require 'config.php';

// Zera todas as estatísticas dos times
$pdo->exec("UPDATE times SET PJ=0, V=0, E=0, D=0, GP=0, GC=0, SG=0, Pts=0");

// Remove todos os jogos
$pdo->exec("DELETE FROM partidas");

// Mensagem e redirecionamento
echo "<!DOCTYPE html>
<html lang='pt-br'>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Reiniciar Campeonato</title>
<style>
body { font-family: Arial, sans-serif; background: #f5f5f5; text-align: center; padding: 40px; }
.container { background: #fff; display: inline-block; padding: 20px 40px; border-radius: 10px; box-shadow: 0 0 8px rgba(0,0,0,0.1); }
h1 { color: #dc3545; }
a { display: inline-block; margin-top: 20px; padding: 10px 15px; background: #007bff; color: #fff; border-radius: 6px; text-decoration: none; }
a:hover { background: #0056b3; }
</style>
</head>
<body>
<div class='container'>
<h1>🏁 Campeonato reiniciado com sucesso!</h1>
<p>Todas as partidas foram apagadas e as estatísticas zeradas.</p>
<a href='index.php'>Voltar à Tabela</a>
</div>
</body>
</html>";