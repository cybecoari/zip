<?php
if (!function_exists('e')) {
    // Escapa HTML para evitar XSS
    function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

/**
 * 🔄 Recalcula a classificação completa e envia à API
 */
function atualizarClassificacao(PDO $pdo)
{
    // Zera estatísticas
    $pdo->exec("UPDATE times SET PJ=0, V=0, E=0, D=0, GP=0, GC=0, SG=0, Pts=0");

    // Busca partidas com placar definido
    $sql = "SELECT * FROM partidas WHERE gols_m IS NOT NULL AND gols_v IS NOT NULL";
    $partidas = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

    foreach ($partidas as $jogo) {
        $m = (int)$jogo['mandante_id'];
        $v = (int)$jogo['visitante_id'];
        $gm = (int)$jogo['gols_m'];
        $gv = (int)$jogo['gols_v'];

        // Atualiza estatísticas básicas
        $pdo->prepare("UPDATE times SET PJ = PJ + 1, GP = GP + ?, GC = GC + ? WHERE id = ?")
            ->execute([$gm, $gv, $m]);
        $pdo->prepare("UPDATE times SET PJ = PJ + 1, GP = GP + ?, GC = GC + ? WHERE id = ?")
            ->execute([$gv, $gm, $v]);

        // Define resultado
        if ($gm > $gv) {
            // Mandante venceu
            $pdo->prepare("UPDATE times SET V = V + 1, Pts = Pts + 3 WHERE id = ?")->execute([$m]);
            $pdo->prepare("UPDATE times SET D = D + 1 WHERE id = ?")->execute([$v]);
        } elseif ($gm < $gv) {
            // Visitante venceu
            $pdo->prepare("UPDATE times SET V = V + 1, Pts = Pts + 3 WHERE id = ?")->execute([$v]);
            $pdo->prepare("UPDATE times SET D = D + 1 WHERE id = ?")->execute([$m]);
        } else {
            // Empate
            $pdo->prepare("UPDATE times SET E = E + 1, Pts = Pts + 1 WHERE id IN (?, ?)")->execute([$m, $v]);
        }
    }

    // Atualiza saldo de gols corretamente
    $pdo->exec("UPDATE times SET SG = GP - GC");

    // Envia para a API
    enviarClassificacaoAPI($pdo);
}

/**
 * 📤 Envia a classificação atualizada para a API
 */
function enviarClassificacaoAPI(PDO $pdo)
{
    try {
        $dados = getClassificacao($pdo);
        $json = json_encode($dados, JSON_UNESCAPED_UNICODE);

        $ch = curl_init("https://cybercoari.com.br/api/atualizar.php");
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_TIMEOUT => 10
        ]);
        $resposta = curl_exec($ch);
        curl_close($ch);

        // Opcional: gravar log local (para debug)
        // file_put_contents(__DIR__ . '/../logs/api_log.txt', date('Y-m-d H:i:s') . " - API resposta: $resposta\n", FILE_APPEND);
    } catch (Exception $e) {
        // Log de erro silencioso (sem interromper o site)
        // file_put_contents(__DIR__ . '/../logs/api_log.txt', date('Y-m-d H:i:s') . " - ERRO: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}

/**
 * 📊 Retorna classificação ordenada por pontos, vitórias e saldo
 */
function getClassificacao(PDO $pdo)
{
    $stmt = $pdo->query("
        SELECT * FROM times
        ORDER BY Pts DESC, V DESC, SG DESC, GP DESC, nome ASC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * ⚙️ Formata data para exibição
 */
function formatarData($data)
{
    if (!$data) return '';
    return date('d/m/Y', strtotime($data));
}

/**
 * 🕒 Retorna o turno com base na rodada
 */
function getTurno($rodada)
{
    if ($rodada >= 1 && $rodada <= 19) {
        return "1º Turno";
    } elseif ($rodada >= 20 && $rodada <= 38) {
        return "2º Turno";
    }
    return "Rodada inválida";
}
?>