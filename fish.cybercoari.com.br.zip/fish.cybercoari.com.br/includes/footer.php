</main>
<footer>
  <p>© <?= date('Y') ?> Meu Campeonato - Desenvolvido com ❤️ em PHP</p>
</footer>
</body>
</html>