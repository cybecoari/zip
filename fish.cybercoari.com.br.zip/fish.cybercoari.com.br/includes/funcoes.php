<?php
if (!function_exists('e')) {
    // Função para escapar HTML e evitar XSS
    function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

/**
 * 🔄 Recalcula a classificação completa
 * Atualiza automaticamente todos os times conforme resultados das partidas finalizadas.
 */
function atualizarClassificacao(PDO $pdo)
{
    // Zera estatísticas
    $pdo->exec("UPDATE times SET PJ=0, V=0, E=0, D=0, GP=0, GC=0, SG=0, Pts=0");

    // Busca todas as partidas finalizadas (ou com placar)
    $sql = "SELECT * FROM partidas WHERE gols_m IS NOT NULL AND gols_v IS NOT NULL";
    $partidas = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

    foreach ($partidas as $jogo) {
        $m = (int)$jogo['mandante_id'];
        $v = (int)$jogo['visitante_id'];
        $gm = (int)$jogo['gols_m'];
        $gv = (int)$jogo['gols_v'];

        // Atualiza partidas jogadas
        $pdo->prepare("UPDATE times SET PJ = PJ + 1, GP = GP + ?, GC = GC + ?, SG = GP - GC WHERE id = ?")
            ->execute([$gm, $gv, $m]);
        $pdo->prepare("UPDATE times SET PJ = PJ + 1, GP = GP + ?, GC = GC + ?, SG = GP - GC WHERE id = ?")
            ->execute([$gv, $gm, $v]);

        // Define resultado
        if ($gm > $gv) {
            // Mandante venceu
            $pdo->prepare("UPDATE times SET V = V + 1, Pts = Pts + 3 WHERE id = ?")->execute([$m]);
            $pdo->prepare("UPDATE times SET D = D + 1 WHERE id = ?")->execute([$v]);
        } elseif ($gm < $gv) {
            // Visitante venceu
            $pdo->prepare("UPDATE times SET V = V + 1, Pts = Pts + 3 WHERE id = ?")->execute([$v]);
            $pdo->prepare("UPDATE times SET D = D + 1 WHERE id = ?")->execute([$m]);
        } else {
            // Empate
            $pdo->prepare("UPDATE times SET E = E + 1, Pts = Pts + 1 WHERE id IN (?, ?)")->execute([$m, $v]);
        }
    }
}

/**
 * 📊 Retorna classificação ordenada por pontos, vitórias e saldo
 */
function getClassificacao(PDO $pdo)
{
    $stmt = $pdo->query("
        SELECT * FROM times
        ORDER BY Pts DESC, V DESC, SG DESC, GP DESC, nome ASC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * ⚙️ Formata data para exibição (de Y-m-d → d/m/Y)
 */
function formatarData($data)
{
    if (!$data) return '';
    return date('d/m/Y', strtotime($data));
}

/**
 * 🕒 Retorna o turno com base na rodada
 */
function getTurno($rodada)
{
    if ($rodada >= 1 && $rodada <= 19) {
        return "1º Turno";
    } elseif ($rodada >= 20 && $rodada <= 38) {
        return "2º Turno";
    }
    return "Rodada inválida";
}
?>