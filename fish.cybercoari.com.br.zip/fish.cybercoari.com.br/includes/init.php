<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/funcoes.php';
session_start();