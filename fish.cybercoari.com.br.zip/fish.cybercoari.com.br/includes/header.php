<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Campeonato ⚽</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<nav style="background:#007bff;padding:10px;text-align:center;">
  
  <a href="/index.php" style="color:white;margin:0 10px;text-decoration:none;"> Início</a>
  
  <a href="/pages/partidas.php" style="color:white;margin:0 10px;text-decoration:none;"> Partidas</a>
    <a href="/pages/jogos.php" style="color:white;margin:0 10px;text-decoration:none;"> Jogos</a>
  
  <a href="/pages/classificacao.php" style="color:white;margin:0 10px;text-decoration:none;"> Classificação</a>
  
  <a href="/pages/sobre.php" style="color:white;margin:0 10px;text-decoration:none;"> Sobre</a>
</nav>