<?php
require_once 'config.php';

try {
    $sql = "SELECT * FROM times ORDER BY Pts DESC, SG DESC, GP DESC, nome ASC";
    $stmt = $pdo->query($sql);
    $times = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao buscar classificação: " . $e->getMessage());
}

// Função para gerar nome do arquivo do escudo
function gerarNomeEscudo($nome) {
    $nome = iconv('UTF-8', 'ASCII//TRANSLIT', $nome);
    $nome = strtolower($nome);
    $nome = preg_replace('/[^a-z0-9]/', '', $nome);
    return $nome . '.svg';
}

// Caminho base da CDN CORRIGIDO
$cdnBase = "https://raw.githubusercontent.com/cybecoari/times/main/";
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Classificação - Brasileirão 2026</title>
<style>
body {
    font-family: "Segoe UI", Arial, sans-serif;
    background: #f3f4f6;
    margin: 0;
    padding: 20px;
    animation: fadeIn 0.6s ease-in-out;
}
h3 {
    text-align: center;
    color: #1a1a1a;
    margin-bottom: 20px;
    font-size: 1.8em;
}
.selector-container {
    text-align: center;
    margin-bottom: 25px;
}
select {
    padding: 8px 12px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 16px;
    background: #fff;
    transition: border 0.3s, box-shadow 0.3s;
}
select:focus {
    outline: none;
    border-color: #28a745;
    box-shadow: 0 0 6px rgba(40,167,69,0.3);
}
table {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    border-collapse: collapse;
    background: #fff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
th, td {
    padding: 12px 8px;
    text-align: center;
    font-size: 14px;
}
th {
    background: #28a745;
    color: #fff;
    font-weight: 600;
    position: sticky;
    top: 0;
}
tr {
    border-bottom: 1px solid #eee;
    transition: all 0.25s ease;
}
tr:hover {
    background: #e9f7ef;
}
tr.favorito {
    background: #fff8e1 !important;
    box-shadow: 0 0 10px #ffd54f inset;
}
tr.favorito td {
    font-weight: bold;
}
.pos-bar { 
    width: 5px; 
    padding: 0 !important;
}
.bar-g4 { background: #007f3f; }
.bar-pre-lib { background: #17a2b8; }
.bar-sula { background: #ffc107; }
.bar-meio { background: #adb5bd; }
.bar-z4 { background: #dc3545; }

.time-nome {
    display: flex;
    align-items: center;
    gap: 8px;
    justify-content: flex-start;
    padding-left: 8px;
}
.time-nome img {
    width: 30px;
    height: 30px;
    object-fit: contain;
    border-radius: 10%;
    transition: transform 0.3s ease;
}
.time-nome img:hover { transform: scale(1.2); }

.legenda {
    margin-top: 25px;
    text-align: center;
}
.legenda-item {
    display: inline-flex;
    align-items: center;
    margin: 4px 12px;
    font-size: 15px;
    color: #333;
}
.legenda-cor {
    width: 18px;
    height: 18px;
    margin-right: 6px;
    border-radius: 3px;
}
.verde{background:#007f3f;}
.azul{background:#17a2b8;}
.amarelo{background:#ffc107;}
.cinza{background:#adb5bd;}
.vermelho{background:#dc3545;}

a {
    display: inline-block;
    margin: 25px auto;
    text-align: center;
    text-decoration: none;
    color: #fff;
    background: #28a745;
    padding: 12px 24px;
    border-radius: 6px;
    font-weight: bold;
    transition: background 0.3s, transform 0.2s;
}
a:hover {
    background: #1e7e34;
    transform: scale(1.05);
}
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

@media (max-width: 768px) {
    body {
        padding: 10px;
    }
    table {
        font-size: 12px;
    }
    th, td { 
        padding: 6px 4px;
        font-size: 12px;
    }
    .time-nome img { 
        width: 24px; 
        height: 24px; 
    }
    select { 
        width: 90%; 
        font-size: 14px; 
    }
    h3 {
        font-size: 1.4em;
    }
}

@media (max-width: 480px) {
    th, td {
        padding: 4px 2px;
        font-size: 11px;
    }
    .time-nome {
        gap: 4px;
    }
    .time-nome img {
        width: 20px;
        height: 20px;
    }
}
</style>
</head>
<body>
<h3>🏆 Classificação - Brasileirão 2026</h3>

<div class="selector-container">
    <label for="timeFavorito"><strong>⚽ Escolha seu time:</strong></label>
    <select id="timeFavorito">
        <option value="">-- Selecione --</option>
        <?php foreach($times as $index => $t): ?>
            <option value="<?= $index ?>"><?= htmlspecialchars($t['nome']) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<table id="tabela">
<thead>
<tr>
    <th></th>
    <th>Pos</th>
    <th>Time</th>
    <th>P</th>
    <th>J</th>
    <th>V</th>
    <th>E</th>
    <th>D</th>
    <th>GP</th>
    <th>GC</th>
    <th>SG</th>
    <th>%</th>
</tr>
</thead>
<tbody>
<?php
$pos = 1;
foreach($times as $index => $time):
    $nome = htmlspecialchars($time['nome']);
    $arquivo = gerarNomeEscudo($time['nome']); // Usar o nome original, não o com htmlspecialchars
    $imgURL = $cdnBase . $arquivo;
    
    // Classes para colorir a posição
    if ($pos <= 4) {
        $barClass = "bar-g4";
    } elseif ($pos <= 6) {
        $barClass = "bar-pre-lib";
    } elseif ($pos <= 12) {
        $barClass = "bar-sula";
    } elseif ($pos <= 16) {
        $barClass = "bar-meio";
    } else {
        $barClass = "bar-z4";
    }
?>
<tr data-index="<?= $index ?>">
    <td class="pos-bar <?= $barClass ?>"></td>
    <td><?= $pos++ ?></td>
    <td class="time-nome">
        <img src="<?= $imgURL ?>" alt="<?= $nome ?>" 
             onerror="this.onerror=null; this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiIHZpZXdCb3g9IjAgMCAzMCAzMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNSIgY3k9IjE1IiByPSIxNCIgZmlsbD0iI2YwZjBmMCIgc3Ryb2tlPSIjZGRkIi8+PHRleHQgeD0iMTUiIHk9IjE3IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiM2NjYiPj88L3RleHQ+PC9zdmc+';">
        <?= $nome ?>
    </td>
    <td><strong><?= $time['Pts'] ?></strong></td>
    <td><?= $time['PJ'] ?></td>
    <td><?= $time['V'] ?></td>
    <td><?= $time['E'] ?></td>
    <td><?= $time['D'] ?></td>
    <td><?= $time['GP'] ?></td>
    <td><?= $time['GC'] ?></td>
    <td><?= $time['SG'] ?></td>
    <td><?= number_format($time['Aproveitamento'], 1, ',', '.') ?>%</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<div class="legenda">
    <div class="legenda-item"><span class="legenda-cor verde"></span> Libertadores</div>
    <div class="legenda-item"><span class="legenda-cor azul"></span> Pré-Libertadores</div>
    <div class="legenda-item"><span class="legenda-cor amarelo"></span> Sul-Americana</div>
    <div class="legenda-item"><span class="legenda-cor cinza"></span> Meio da Tabela</div>
    <div class="legenda-item"><span class="legenda-cor vermelho"></span> Rebaixamento</div>
</div>

<div style="text-align:center;">
    <a href="partidas.php">📋 Registrar partidas</a>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const select = document.getElementById("timeFavorito");
    const linhas = document.querySelectorAll("tbody tr");
    const salvo = localStorage.getItem("timeFavorito");

    function aplicarFavorito(idx) {
        linhas.forEach(tr => tr.classList.remove("favorito"));
        if (idx !== "" && linhas[idx]) {
            linhas[idx].classList.add("favorito");
            // Scroll para o time favorito
            linhas[idx].scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    if (salvo !== null && salvo !== "") {
        aplicarFavorito(Number(salvo));
        select.value = salvo;
    }

    select.addEventListener("change", () => {
        const idx = select.value;
        localStorage.setItem("timeFavorito", idx);
        aplicarFavorito(idx);
    });
    
    // Adicionar tooltip nas imagens
    document.querySelectorAll('.time-nome img').forEach(img => {
        img.title = img.alt;
    });
});
</script>
</body>
</html>