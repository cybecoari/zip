<?php
require_once 'config.php';

try {
    $sql = "SELECT * FROM times ORDER BY nome ASC";
    $stmt = $pdo->query($sql);
    $times = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao buscar clubes: " . $e->getMessage());
}

// Função para gerar o nome do escudo
function gerarNomeEscudo($nome) {
    $nome = iconv('UTF-8', 'ASCII//TRANSLIT', $nome);
    $nome = strtolower($nome);
    $nome = preg_replace('/[^a-z0-9]/', '', $nome);
    return $nome . '.svg';
}

$cdnBase = "https://cdn.jsdelivr.net/gh/cybercoary/cdn/";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Todos os Escudos - Brasileirão 2025</title>
<style>
body {
    font-family: "Segoe UI", Arial, sans-serif;
    background: #f3f4f6;
    margin: 0;
    padding: 20px;
}
h3 {
    text-align: center;
    margin-bottom: 15px;
    color: #222;
}
#buscaTimes {
    width: 100%;
    max-width: 400px;
    display: block;
    margin: 0 auto 20px auto;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
}
.escudos-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
    gap: 15px;
    justify-items: center;
}
.escudo-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    background: #fff;
    padding: 10px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    transition: transform 0.2s;
}
.escudo-item:hover {
    transform: scale(1.05);
}
.escudo-item img {
    width: 60px;
    height: 60px;
    object-fit: contain;
    border-radius: 5%;
    margin-bottom: 8px;
}
.escudo-item span {
    text-align: center;
    font-size: 14px;
    font-weight: 500;
    color: #333;
    word-break: break-word;
}
a {
    display: block;
    text-align: center;
    margin: 20px auto;
    text-decoration: none;
    color: #fff;
    background: #007bff;
    padding: 10px 18px;
    border-radius: 6px;
    width: 180px;
    transition: background 0.3s;
}
a:hover {
    background: #0056b3;
}
@media(max-width:480px) {
    .escudo-item img { width: 50px; height: 50px; }
    .escudo-item span { font-size: 12px; }
}
</style>
</head>
<body>

<h3>🏟️ Todos os Escudos - Brasileirão 2025</h3>

<input type="text" id="buscaTimes" placeholder="🔍 Buscar time...">

<div class="escudos-container" id="listaTimes">
<?php foreach ($times as $time):
    $nome = htmlspecialchars($time['nome']);
    $arquivo = gerarNomeEscudo($nome);
    $imgURL = $cdnBase . $arquivo;
?>
    <div class="escudo-item">
        <img src="<?= $imgURL ?>" alt="<?= $nome ?>" onerror="this.src='<?= $cdnBase ?>default.png'">
        <span><?= $nome ?></span>
    </div>
<?php endforeach; ?>
</div>

<a href="index.php">⬅️ Voltar para a Classificação</a>

<script>
document.getElementById('buscaTimes').addEventListener('keyup', function() {
    let termo = this.value.toLowerCase();
    let times = document.querySelectorAll('#listaTimes .escudo-item');

    times.forEach(function(item) {
        let nome = item.querySelector('span').innerText.toLowerCase();
        item.style.display = nome.includes(termo) ? "flex" : "none";
    });
});
</script>

</body>
</html>