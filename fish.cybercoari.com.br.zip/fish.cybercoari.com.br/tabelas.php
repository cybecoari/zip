<?php
session_start();

if (!isset($_SESSION['times'])) {
    header("Location: index.php");
    exit;
}

// Recalcula tabela
foreach ($_SESSION['times'] as $time => &$t) {
    $t = array_merge(['PJ'=>0,'V'=>0,'E'=>0,'D'=>0,'GP'=>0,'GC'=>0,'SG'=>0,'Pts'=>0], $t);
}
unset($t);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    foreach ($_SESSION['jogos'] as $i => $jogo) {
        if (isset($_POST['gols_m_'.$i]) && isset($_POST['gols_v_'.$i])) {
            $_SESSION['jogos'][$i]['gols_m'] = (int)$_POST['gols_m_'.$i];
            $_SESSION['jogos'][$i]['gols_v'] = (int)$_POST['gols_v_'.$i];
        }
    }
}

// Zera estatísticas
foreach ($_SESSION['times'] as $time => &$d) {
    $d = ['PJ'=>0,'V'=>0,'E'=>0,'D'=>0,'GP'=>0,'GC'=>0,'SG'=>0,'Pts'=>0];
}
unset($d);

// Recalcula classificação
foreach ($_SESSION['jogos'] as $jogo) {
    if ($jogo['gols_m'] === '' || $jogo['gols_v'] === '') continue;
    $m = $jogo['mandante']; $v = $jogo['visitante'];
    $gm = $jogo['gols_m']; $gv = $jogo['gols_v'];
    $_SESSION['times'][$m]['PJ']++; $_SESSION['times'][$v]['PJ']++;
    $_SESSION['times'][$m]['GP'] += $gm; $_SESSION['times'][$m]['GC'] += $gv;
    $_SESSION['times'][$v]['GP'] += $gv; $_SESSION['times'][$v]['GC'] += $gm;
    if ($gm > $gv) { $_SESSION['times'][$m]['V']++; $_SESSION['times'][$v]['D']++; $_SESSION['times'][$m]['Pts']+=3; }
    elseif ($gm < $gv) { $_SESSION['times'][$v]['V']++; $_SESSION['times'][$m]['D']++; $_SESSION['times'][$v]['Pts']+=3; }
    else { $_SESSION['times'][$m]['E']++; $_SESSION['times'][$v]['E']++; $_SESSION['times'][$m]['Pts']++; $_SESSION['times'][$v]['Pts']++; }
    $_SESSION['times'][$m]['SG'] = $_SESSION['times'][$m]['GP'] - $_SESSION['times'][$m]['GC'];
    $_SESSION['times'][$v]['SG'] = $_SESSION['times'][$v]['GP'] - $_SESSION['times'][$v]['GC'];
}

$times = $_SESSION['times'];
uasort($times, fn($a,$b)=>[$b['Pts'],$b['V'],$b['SG'],$b['GP']] <=> [$a['Pts'],$a['V'],$a['SG'],$a['GP']]);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tabela do Campeonato</title>
<?php include 'cdn.php'; ?>
</head>
<body class="bg-light">
<div class="container py-4">
  <h1 class="text-center mb-4">🏆 Tabela do Campeonato</h1>

  <div class="d-flex justify-content-center gap-2 mb-4">
    <a href="index.php" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Adicionar Partida</a>
    <a href="reset.php" class="btn btn-danger"><i class="fa-solid fa-rotate-right"></i> Reiniciar</a>
  </div>

  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-primary text-white">Classificação</div>
    <div class="card-body p-0">
      <table class="table table-striped table-sm text-center mb-0">
        <thead class="table-primary">
          <tr><th>#</th><th>Time</th><th>PJ</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th><th>Pts</th></tr>
        </thead>
        <tbody>
        <?php $pos=1; foreach($times as $time=>$d): ?>
          <tr>
            <td><?= $pos++ ?></td>
            <td><?= htmlspecialchars($time) ?></td>
            <td><?= $d['PJ'] ?></td><td><?= $d['V'] ?></td><td><?= $d['E'] ?></td><td><?= $d['D'] ?></td>
            <td><?= $d['GP'] ?></td><td><?= $d['GC'] ?></td><td><?= $d['SG'] ?></td>
            <td><b><?= $d['Pts'] ?></b></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <form method="POST" class="card shadow-sm">
    <div class="card-header bg-success text-white">Atualizar Placar das Partidas</div>
    <div class="card-body p-0">
      <table class="table table-bordered table-sm text-center mb-0">
        <thead class="table-success">
          <tr><th>#</th><th>Mandante</th><th>Placar</th><th>Visitante</th></tr>
        </thead>
        <tbody>
        <?php foreach($_SESSION['jogos'] as $i=>$jogo): ?>
          <tr>
            <td><?= $i+1 ?></td>
            <td><?= htmlspecialchars($jogo['mandante']) ?></td>
            <td>
              <input type="number" name="gols_m_<?= $i ?>" value="<?= $jogo['gols_m'] ?>" class="form-control d-inline w-auto" min="0">
              x
              <input type="number" name="gols_v_<?= $i ?>" value="<?= $jogo['gols_v'] ?>" class="form-control d-inline w-auto" min="0">
            </td>
            <td><?= htmlspecialchars($jogo['visitante']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="card-footer text-center">
      <button type="submit" name="update" value="1" class="btn btn-success">
        <i class="fa-solid fa-floppy-disk"></i> Salvar Atualizações
      </button>
    </div>
  </form>

  <div class="card mt-4 shadow-sm">
    <div class="card-header bg-info text-white">📊 Gráfico de Pontos</div>
    <div class="card-body">
      <canvas id="grafico"></canvas>
    </div>
  </div>
</div>

<script>
const ctx = document.getElementById('grafico');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_keys($times)) ?>,
    datasets: [{
      label: 'Pontos',
      data: <?= json_encode(array_column($times, 'Pts')) ?>,
      backgroundColor: 'rgba(0, 123, 255, 0.7)'
    }]
  },
  options: {responsive:true, scales:{y:{beginAtZero:true}}}
});
</script>
</body>
</html>