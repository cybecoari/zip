$grupos = [
    "Hospedeiros" => ["Canadá", "Estados Unidos", "México"],
    "Ásia (AFC)" => ["Japão", "Irã", "Coreia do Sul", "Austrália", "Uzbequistão", "Jordânia", "Arabia Saudita", "Catar"],
    "Europa (UEFA)" => ["Inglaterra", "UEFE2"],
    "América do Sul (CONMEBOL)" => ["Argentina", "Brasil", "Uruguai", "Colômbia", "Equador", "Paraguai"],
    "África (CAF)" => ["Marrocos", "Tunísia", "Egito", "Gana", "Argélia", "Cabo Verde"],
    "Oceania (OFC)" => ["Nova Zelândia"]
];

$flags = [
    "Canadá" => "ca", "Estados Unidos" => "us", "México" => "mx",
    "Japão" => "jp", "Irã" => "ir", "Coreia do Sul" => "kr",
    "Austrália" => "au", "Uzbequistão" => "uz", "Jordânia" => "jo",
    "Argentina" => "ar", "Brasil" => "br", "Uruguai" => "uy",
    "Colômbia" => "co", "Equador" => "ec", "Paraguai" => "py",
    "Marrocos" => "ma", "Tunísia" => "tn", "Egito" => "eg",
    "Gana" => "gh", "Argélia" => "dz", "Cabo Verde" => "cv",
    "Nova Zelândia" => "nz", "Inglaterra" => "eng"
];

// Processar inserção das seleções
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['inserir_selecoes'])) {
    $success_count = 0;
    $errors = [];
    
    try {
        // Limpar tabela de times primeiro (opcional - comente se não quiser apagar times existentes)
        // $pdo->query("DELETE FROM times");
        
        // Inserir todas as seleções
        foreach ($grupos as $confederacao => $selecoes) {
            foreach ($selecoes as $selecao) {
                // Verificar se o time já existe
                $stmt_check = $pdo->prepare("SELECT id FROM times WHERE nome = ?");
                $stmt_check->execute([$selecao]);
                
                if (!$stmt_check->fetch()) {
                    // Inserir novo time
                    $stmt = $pdo->prepare("INSERT INTO times (nome, PJ, V, E, D, GP, GC, SG, Pts) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0)");
                    $stmt->execute([$selecao]);
                    $success_count++;
                }
            }
        }
        
        $_SESSION['success'] = "$success_count seleções inseridas com sucesso!";
        header("Location: index.php");
        exit;
        
    } catch (PDOException $e) {
        $errors[] = "Erro ao inserir seleções: " . $e->getMessage();
    }
}

// Buscar times existentes
$times_existentes = $pdo->query("SELECT * FROM times ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserir Seleções Copa 2026 - Cyber Fish</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .flag {
            width: 30px;
            height: 20px;
            object-fit: cover;
            border-radius: 2px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .escudos {
            width: 30px;
            height: 30px;
            object-fit: cover;
            border-radius: 1px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .confederacao-card {
            transition: all 0.3s ease;
        }
        .confederacao-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-green-50 min-h-screen">
    <div class="container mx-auto px-4 py-8 max-w-6xl">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="flex items-center justify-center mb-4">
                <div class="w-16 h-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-trophy text-white text-2xl"></i>
                </div>
                <div>
                    <h1 class="text-4xl font-bold text-gray-800">Copa do Mundo 2026</h1>
                    <p class="text-gray-600">Seleções Classificadas</p>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-4 inline-block">
                <p class="text-sm text-gray-700">
                    <strong>Estádios:</strong> Estados Unidos, Canadá e México
                </p>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if(isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                <i class="fas fa-check-circle mr-2"></i>
                <?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if(!empty($errors)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <ul class="list-disc list-inside">
                    <?php foreach($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Estatísticas -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div class="bg-white rounded-xl shadow-lg p-4 text-center">
                <div class="text-2xl font-bold text-blue-600"><?= array_sum(array_map('count', $grupos)) ?></div>
                <div class="text-gray-600 text-sm">Seleções</div>
            </div>
            <div class="bg-white rounded-xl shadow-lg p-4 text-center">
                <div class="text-2xl font-bold text-green-600"><?= count($grupos) ?></div>
                <div class="text-gray-600 text-sm">Confederações</div>
            </div>
            <div class="bg-white rounded-xl shadow-lg p-4 text-center">
                <div class="text-2xl font-bold text-purple-600"><?= count($times_existentes) ?></div>
                <div class="text-gray-600 text-sm">Já Cadastradas</div>
            </div>
            <div class="bg-white rounded-xl shadow-lg p-4 text-center">
                <div class="text-2xl font-bold text-orange-600"><?= array_sum(array_map('count', $grupos)) - count($times_existentes) ?></div>
                <div class="text-gray-600 text-sm">Para Cadastrar</div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Lista de Confederações -->
            <div class="space-y-6">
                <h2 class="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-globe-americas text-blue-500 mr-3"></i>
                    Confederações
                </h2>

                <?php foreach($grupos as $confederacao => $selecoes): ?>
                    <div class="confederacao-card bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center justify-between">
                            <span><?= htmlspecialchars($confederacao) ?></span>
                            <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-normal">
                                <?= count($selecoes) ?> seleções
                            </span>
                        </h3>
                        
                        <div class="space-y-2">
                            <?php foreach($selecoes as $selecao): 
                                $codigo_bandeira = $flags[$selecao] ?? 'un';
                                $ja_cadastrado = in_array($selecao, array_column($times_existentes, 'nome'));
                            ?>
                                <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg <?= $ja_cadastrado ? 'bg-green-50 border-green-200' : 'bg-gray-50' ?>">
                                    <div class="flex items-center space-x-3">
                                    
    <img src="https://cybercoari.com.br/assets/flags/svg/<?= $codigo_bandeira ?>.svg" alt="<?= htmlspecialchars($selecao) ?>" class="flag">
    
    <img src="https://cybercoari.com.br/assets/flags/escudos/<?= $codigo_bandeira ?>.png" alt="<?= htmlspecialchars($selecao) ?>" class="flag">
                                    
    <!--<img src="https://flagcdn.com/w40/<?= $codigo_bandeira ?>.png" alt="<?= htmlspecialchars($selecao) ?>" class="flag">-->
                                        
                                        <span class="font-medium text-gray-800"><?= htmlspecialchars($selecao) ?></span>
                                    </div>
                                    <div>
                                        <?php if($ja_cadastrado): ?>
                                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-sm flex items-center">
                                                <i class="fas fa-check mr-1"></i>
                                                Cadastrado
                                            </span>
                                        <?php else: ?>
                                            <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-sm">
                                                Pendente
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Painel de Controle -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h2 class="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-cogs text-green-500 mr-3"></i>
                    Gerenciamento
                </h2>

                <!-- Formulário de Inserção -->
               <!-- <div class="mb-6 p-4 border border-gray-200 rounded-lg bg-gray-50">
                    <h3 class="text-lg font-semibold text-gray-800 mb-3">Inserir Todas as Seleções</h3>
                    <p class="text-sm text-gray-600 mb-4">
                        Clique no botão abaixo para inserir todas as <?= array_sum(array_map('count', $grupos)) ?> seleções classificadas para a Copa 2026.
                    </p>
                    
                    <form method="post">
                        <button type="submit" name="inserir_selecoes"
                                class="w-full bg-green-600 hover:bg-green-700 text-white px-6 py-4 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2">
                            <i class="fas fa-download"></i>
                            <span>Inserir Todas as Seleções</span>
                        </button>
                    </form> -->
                </div>

                <!-- Times Já Cadastrados -->
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-3 flex items-center justify-between">
                        <span>Times Cadastrados</span>
                        <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-normal">
                            <?= count($times_existentes) ?> times
                        </span>
                    </h3>

                    <?php if(empty($times_existentes)): ?>
                        <div class="text-center py-6 text-gray-500 border-2 border-dashed border-gray-300 rounded-lg">
                            <i class="fas fa-users text-gray-300 text-3xl mb-2"></i>
                            <p>Nenhum time cadastrado ainda.</p>
                        </div>
                    <?php else: ?>
                        <div class="space-y-2 max-h-80 overflow-y-auto">
                            <?php foreach($times_existentes as $index => $time): ?>
                                <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-semibold text-sm">
                                            <?= $index + 1 ?>
                                        </div>
                                        <span class="font-medium text-gray-800"><?= htmlspecialchars($time['nome']) ?></span>
                                    </div>
                                    <div class="text-sm text-gray-500 space-x-2">
                                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded">PJ: <?= $time['PJ'] ?></span>
                                        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded">Pts: <?= $time['Pts'] ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Ações Rápidas -->
                <div class="mt-6 space-y-3">
                    <a href="jogos.php" 
                       class="block w-full bg-orange-500 hover:bg-orange-600 text-white px-4 py-3 rounded-lg font-semibold transition-all duration-200 text-center">
                        <i class="fas fa-plus-circle mr-2"></i>
                        Criar Partidas da Copa
                    </a>
                    
                    <a href="classificacao.php" 
                       class="block w-full bg-purple-500 hover:bg-purple-600 text-white px-4 py-3 rounded-lg font-semibold transition-all duration-200 text-center">
                        <i class="fas fa-trophy mr-2"></i>
                        Ver Classificação
                    </a>
                    
                    <a href="index.php" 
                       class="block w-full bg-gray-500 hover:bg-gray-600 text-white px-4 py-3 rounded-lg font-semibold transition-all duration-200 text-center">
                        <i class="fas fa-home mr-2"></i>
                        Página Inicial
                    </a>
                </div>
            </div>
        </div>

        <!-- Informações Adicionais -->
        <div class="mt-8 bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-3">Informações da Copa 2026</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                <div>
                    <strong>🌍 Países Sede:</strong><br>
                    Estados Unidos, Canadá e México
                </div>
                <div>
                    <strong>🏟︄1�7 Estádios:</strong><br>
                    16 cidades sedes
                </div>
                <div>
                    <strong>👥 Seleções:</strong><br>
                    48 times (expansão)
                </div>
            </div>
        </div>
    </div>

    <script>
        // Animação de confirmação
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    if (!confirm('Tem certeza que deseja inserir todas as seleções da Copa 2026?')) {
                        e.preventDefault();
                    }
                });
            }
        });
    </script>
</body>
</html>