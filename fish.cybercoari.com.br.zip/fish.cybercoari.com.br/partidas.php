<?php
require_once 'config.php';

// Função que atualiza a classificação automaticamente
function atualizarClassificacao($pdo, $mandante_id, $visitante_id, $gols_m, $gols_v) {
    // Busca os dados dos dois times
    $stmt = $pdo->prepare("SELECT * FROM times WHERE id IN (?, ?)");
    $stmt->execute([$mandante_id, $visitante_id]);
    $times = $stmt->fetchAll(PDO::FETCH_UNIQUE);

    $m = $times[$mandante_id];
    $v = $times[$visitante_id];

    // Atualiza partidas jogadas
    $m['PJ']++; 
    $v['PJ']++;

    // Atualiza gols
    $m['GP'] += $gols_m;
    $m['GC'] += $gols_v;
    $v['GP'] += $gols_v;
    $v['GC'] += $gols_m;

    // Calcula saldo
    $m['SG'] = $m['GP'] - $m['GC'];
    $v['SG'] = $v['GP'] - $v['GC'];

    // Define resultado
    if ($gols_m > $gols_v) {
        $m['V']++; $v['D']++;
        $m['Pts'] += 3;
    } elseif ($gols_m < $gols_v) {
        $v['V']++; $m['D']++;
        $v['Pts'] += 3;
    } else {
        $m['E']++; $v['E']++;
        $m['Pts']++; $v['Pts']++;
    }

    // Atualiza no banco
    $sql = "UPDATE times SET PJ=?, V=?, E=?, D=?, GP=?, GC=?, SG=?, Pts=? WHERE id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$m['PJ'], $m['V'], $m['E'], $m['D'], $m['GP'], $m['GC'], $m['SG'], $m['Pts'], $mandante_id]);
    $stmt->execute([$v['PJ'], $v['V'], $v['E'], $v['D'], $v['GP'], $v['GC'], $v['SG'], $v['Pts'], $visitante_id]);
}

// Quando enviar o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rodada = $_POST['rodada'];
    $dataInformada = trim($_POST['data']);
    $mandante_id = $_POST['mandante_id'];
    $visitante_id = $_POST['visitante_id'];
    $gols_m = $_POST['gols_m'];
    $gols_v = $_POST['gols_v'];

    // Converte data do formato dd/mm/yyyy para yyyy-mm-dd
    if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $dataInformada, $matches)) {
        $dataConvertida = "$matches[3]-$matches[2]-$matches[1]";
    } else {
        $dataConvertida = $dataInformada; // Caso já venha no formato certo
    }

    // Salva a partida
    $sql = "INSERT INTO partidas (rodada, data, mandante_id, visitante_id, gols_m, gols_v)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$rodada, $dataConvertida, $mandante_id, $visitante_id, $gols_m, $gols_v]);

    // Atualiza classificação
    atualizarClassificacao($pdo, $mandante_id, $visitante_id, $gols_m, $gols_v);

    header("Location: partidas.php?sucesso=1");
    exit;
}

// Puxa lista de times e partidas existentes
$times = $pdo->query("SELECT * FROM times ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
$partidas = $pdo->query("
    SELECT p.*, 
           t1.nome AS mandante_nome, 
           t2.nome AS visitante_nome
    FROM partidas p
    LEFT JOIN times t1 ON p.mandante_id = t1.id
    LEFT JOIN times t2 ON p.visitante_id = t2.id
    ORDER BY p.id DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gerenciar Partidas ⚽</title>
<?php include '/cdn.php'; ?>
<link rel="stylesheet" href="style.css">
<style>
body { font-family: Arial, sans-serif; background: #f9f9f9; padding: 20px; }
h1, h2 { text-align: center; }
form { max-width: 700px; margin: 20px auto; background: white; padding: 15px; border-radius: 10px; box-shadow: 0 0 8px rgba(0,0,0,0.1); }
label { display: block; margin-top: 10px; font-weight: bold; }
input, select { width: 100%; padding: 8px; margin-top: 4px; border: 1px solid #ccc; border-radius: 5px; }
button { margin-top: 15px; padding: 10px 15px; background: #007bff; border: none; color: white; border-radius: 5px; cursor: pointer; }
button:hover { background: #0056b3; }
table { width: 100%; border-collapse: collapse; margin-top: 30px; }
th, td { border: 1px solid #ccc; padding: 6px; text-align: center; }
th { background: #007bff; color: white; }
</style>
</head>
<body>
<h1>🏟️ Gerenciar Partidas</h1>

<form method="POST">
    <label>Rodada:</label>
    <input type="number" name="rodada" min="1" max="38" required>

    <label>Data da Partida:</label>
    <input type="text" name="data" placeholder="Ex: 01/01/2025" required>

    <label>Time Mandante:</label>
    <select name="mandante_id" required>
        <option value="">Selecione</option>
        <?php foreach ($times as $t): ?>
            <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['nome']) ?></option>
        <?php endforeach; ?>
    </select>

    <label>Time Visitante:</label>
    <select name="visitante_id" required>
        <option value="">Selecione</option>
        <?php foreach ($times as $t): ?>
            <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['nome']) ?></option>
        <?php endforeach; ?>
    </select>

    <label>Gols Mandante:</label>
    <input type="number" name="gols_m" min="0" required>

    <label>Gols Visitante:</label>
    <input type="number" name="gols_v" min="0" required>

    <button type="submit">💾 Salvar Partida</button>
</form>

<?php if (isset($_GET['sucesso'])): ?>
    <p style="text-align:center; color:green;">✅ Partida salva e classificação atualizada!</p>
<?php endif; ?>

<h2>📋 Partidas Registradas</h2>
<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Rod</th>
            <th>Data</th>
            <th>Mandante</th>
            <th>Placar</th>
            <th>Visitante</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($partidas as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= $p['rodada'] ?></td>
            <td><?= date('d/m/Y', strtotime($p['data'])) ?></td>
            <td><?= htmlspecialchars($p['mandante_nome']) ?></td>
            <td><?= $p['gols_m'] ?> x <?= $p['gols_v'] ?></td>
            <td><?= htmlspecialchars($p['visitante_nome']) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<p style="text-align:center; margin-top:20px;">
    <a href="index.php" style="background:#28a745; color:white; padding:8px 12px; border-radius:5px; text-decoration:none;">⬅️ Voltar à Classificação</a>
</p>
</body>
</html>