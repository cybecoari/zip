-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geraÃ§Ã£o: 04/11/2025 Ã s 23:17
-- VersÃ£o do servidor: 10.6.21-MariaDB-cll-lve
-- VersÃ£o do PHP: 8.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cyber_fish`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `partidas`
--

CREATE TABLE `partidas` (
  `id` int(11) NOT NULL,
  `rodada` int(11) DEFAULT 1,
  `data` date DEFAULT NULL,
  `mandante_id` int(11) DEFAULT NULL,
  `visitante_id` int(11) DEFAULT NULL,
  `gols_m` int(11) DEFAULT NULL,
  `gols_v` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `times`
--

CREATE TABLE `times` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `PJ` int(11) DEFAULT 0,
  `V` int(11) DEFAULT 0,
  `E` int(11) DEFAULT 0,
  `D` int(11) DEFAULT 0,
  `GP` int(11) DEFAULT 0,
  `GC` int(11) DEFAULT 0,
  `SG` int(11) DEFAULT 0,
  `Pts` int(11) DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `times`
--

INSERT INTO `times` (`id`, `nome`, `PJ`, `V`, `E`, `D`, `GP`, `GC`, `SG`, `Pts`) VALUES
(1, 'Ãgua Santa', 0, 0, 0, 0, 0, 0, 0, 0),
(2, 'Botafogofc', 0, 0, 0, 0, 0, 0, 0, 0),
(3, 'Corinthians', 0, 0, 0, 0, 0, 0, 0, 0),
(4, 'Guarani', 0, 0, 0, 0, 0, 0, 0, 0),
(5, 'Inter', 0, 0, 0, 0, 0, 0, 0, 0),
(6, 'Mirassol', 0, 0, 0, 0, 0, 0, 0, 0),
(7, 'Noroeste', 0, 0, 0, 0, 0, 0, 0, 0),
(8, 'Novo Horizontino', 0, 0, 0, 0, 0, 0, 0, 0),
(9, 'Palmeiras', 0, 0, 0, 0, 0, 0, 0, 0),
(10, 'Ponte Preta', 0, 0, 0, 0, 0, 0, 0, 0),
(11, 'Portuguesa', 0, 0, 0, 0, 0, 0, 0, 0),
(12, 'Red Bull', 0, 0, 0, 0, 0, 0, 0, 0),
(13, 'Santos', 0, 0, 0, 0, 0, 0, 0, 0),
(14, 'SÃ£o Bernardo', 0, 0, 0, 0, 0, 0, 0, 0),
(15, 'SÃ£o Paulo', 0, 0, 0, 0, 0, 0, 0, 0),
(16, 'Velo Clube', 0, 0, 0, 0, 0, 0, 0, 0),
(17, 'Ituano', 0, 0, 0, 0, 0, 0, 0, 0),
(18, 'FerroviÃ¡ria', 0, 0, 0, 0, 0, 0, 0, 0),
(19, 'SÃ£o Bento', 0, 0, 0, 0, 0, 0, 0, 0),
(20, 'Linense', 0, 0, 0, 0, 0, 0, 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;