<?php
/**
 * Desenvolvido por: THEFULLNET
 * linkedin: https://www.linkedin.com/in/wellington-alves-217199265/
 * Data: <?php echo date('Y'); ?> 
 * Descrição: Gerador de código Pix dinâmico com QR Code e opção de "Pix Copia e Cola"
 */

// Pega o valor do parâmetro PIX da URL
$valor = isset($_GET['PIX']) ? floatval(str_replace(',', '.', $_GET['PIX'])) : 0.01; // Converte a vírgula para ponto se necessário

function gerarPixCode($nome, $cidade, $chave, $valor = null) {
    $nome = strtoupper($nome);
    $cidade = strtoupper($cidade);

    $payloadFormat = '000201';
    $merchantAccount = montarMerchantAccount($chave);
    $merchantCategoryCode = '52040000';
    $transactionCurrency = '5303986';
    $transactionAmount = $valor ? '54'.str_pad(strlen(number_format($valor, 2, '.', '')), 2, '0', STR_PAD_LEFT).number_format($valor, 2, '.', '') : '';
    $countryCode = '5802BR';
    $merchantName = '59'.str_pad(strlen($nome), 2, '0', STR_PAD_LEFT).$nome;
    $merchantCity = '60'.str_pad(strlen($cidade), 2, '0', STR_PAD_LEFT).$cidade;
    $txid = '62070503***';

    $fullPix = $payloadFormat.
               $merchantAccount.
               $merchantCategoryCode.
               $transactionCurrency.
               $transactionAmount.
               $countryCode.
               $merchantName.
               $merchantCity.
               $txid;

    $fullPix .= '6304';
    $crc = crc16($fullPix);
    return $fullPix.strtoupper($crc);
}

function montarMerchantAccount($chave) {
    $gui = 'BR.GOV.BCB.PIX';
    $guiLength = str_pad(strlen($gui), 2, '0', STR_PAD_LEFT);
    $chaveLength = str_pad(strlen($chave), 2, '0', STR_PAD_LEFT);
    $value = '0014'.$gui.'01'.$chaveLength.$chave;
    return '26'.str_pad(strlen($value), 2, '0', STR_PAD_LEFT).$value;
}

function crc16($payload) {
    $polynom = 0x1021;
    $result = 0xFFFF;

    for ($offset = 0; $offset < strlen($payload); $offset++) {
        $result ^= (ord($payload[$offset]) << 8);
        for ($bitwise = 0; $bitwise < 8; $bitwise++) {
            if (($result <<= 1) & 0x10000) $result ^= $polynom;
            $result &= 0xFFFF;
        }
    }

    return strtoupper(str_pad(dechex($result), 4, '0', STR_PAD_LEFT));
}

// Parâmetros para editar
$nome = "Doacao";
$cidade = "Manaus"; // crie o nome tudo junto
$chave = "40695c10-3a90-452a-9cad-30453604cf6a"; // chave aleatoria ou email, outros pode falhar

$codigoPix = gerarPixCode($nome, $cidade, $chave, $valor);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Pagamento via Pix - R$<?php echo number_format($valor, 2, ',', '.'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        body {
            background-color: #f2f4f8;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .pix-box {
            max-width: 540px;
            margin: auto;
            background: #ffffff;
            border-radius: 16px;
            padding: 30px 25px;
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.1);
        }

        .pix-box h2 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 25px;
            text-align: center;
            color: #2c3e50;
        }

        .pix-info, .pix-expiry {
            font-size: 1rem;
            margin-bottom: 10px;
            color: #555;
        }

        #qrcode {
            display: flex;
            justify-content: center;
            margin: 25px 0;
        }

        textarea {
            font-size: 0.95rem;
            resize: none;
        }

        .copy-btn {
            width: 100%;
            font-weight: 500;
        }

        .steps {
            background-color: #f8f9fa;
            border-left: 4px solid #0d6efd;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .steps h5 {
            margin-bottom: 10px;
            font-weight: 600;
        }

        .steps ol {
            padding-left: 20px;
            margin: 0;
        }

        .steps li {
            margin-bottom: 10px;
        }

        .pix-expiry {
            margin-top: 20px;
            font-style: italic;
            color: #999;
            text-align: center;
        }

        @media (max-width: 576px) {
            .pix-box {
                padding: 20px 15px;
            }

            .pix-box h2 {
                font-size: 1.6rem;
            }

            textarea {
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="pix-box">
            <h2>CYBERCOARI</h2>
            <div class="pix-info"><strong>Valor:</strong> R$ <?php echo number_format($valor, 2, ',', '.'); ?></div>
            <div class="pix-info"><strong>Recebedor:</strong> <?php echo $nome; ?></div>

            <div id="qrcode"></div>

            <div class="pix-info"><strong>Pix Copia e Cola:</strong></div>
            <textarea id="pixCode" class="form-control mb-3" rows="3" readonly><?php echo $codigoPix; ?></textarea>
            <button class="btn btn-success copy-btn mb-3" onclick="copiarPix()">📋 Copiar Código Pix</button>

            <div class="steps">
                <h5>Como pagar com Pix:</h5>
                <ol>
                    <li>Abra o app do seu banco.</li>
                    <li>Escolha a opção <strong>Pix</strong> e depois <strong>Pagar com QR Code</strong>.</li>
                    <li>Aponte a câmera para o QR Code acima.</li>
                    <li>Ou cole o código Pix Copia e Cola.</li>
                    <li>Confirme os dados e finalize o pagamento.</li>
                </ol>
            </div>

         <div class="pix-expiry">⚠️ Este código expira em 1 dia.</div>

<div style="text-align: center; margin-top: 10px;">
    <a href="https://wa.me/5511912997247?text=📸%20Olá!%20Segue%20o%20comprovante." target="_blank" style="display: inline-block; padding: 10px 15px; background-color: #25D366; color: white; border-radius: 8px; text-decoration: none; font-weight: bold;">
        📲 Enviar Comprovante no WhatsApp
    </a>
</div>

        </div>
    </div>

    <script>
        new QRCode(document.getElementById("qrcode"), {
            text: "<?php echo $codigoPix; ?>",
            width: 200,
            height: 200
        });

        function copiarPix() {
            const copyText = document.getElementById("pixCode");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            alert("Código Pix copiado com sucesso!");
        }
    </script>
</body>
</html>