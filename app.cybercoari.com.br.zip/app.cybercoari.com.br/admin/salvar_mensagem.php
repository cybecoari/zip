<?php
require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

if (!isAdmin()) {
    header("Location: /painel.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo']);
    $msg    = trim($_POST['msg']);
    $tipo   = $_POST['tipo'];
    $idu    = !empty($_POST['idu']) ? (int)$_POST['idu'] : null;

    $sql = "INSERT INTO mensagens (titulo, msg, tipo, idu, criado_em)
            VALUES (:titulo, :msg, :tipo, :idu, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':titulo', $titulo);
    $stmt->bindValue(':msg', $msg);
    $stmt->bindValue(':tipo', $tipo);
    $stmt->bindValue(':idu', $idu, $idu ? PDO::PARAM_INT : PDO::PARAM_NULL);

    $stmt->execute();
}

header("Location: mensagens.php");
exit;