<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../includes/sessao.php';

checkLogin();

if (!isAdmin()) {
    header("Location: /painel.php?msg=no_permission");
    exit;
}

// Verificar se o ID foi passado
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: /admin/mensagens.php?msg=id_nao_informado");
    exit;
}

$id = intval($_GET['id']);

if ($id <= 0) {
    header("Location: /admin/mensagens.php?msg=id_invalido");
    exit;
}

try {
    // Verificar se a mensagem existe
    $stmt = $pdo->prepare("SELECT id FROM mensagens WHERE id = ?");
    $stmt->execute([$id]);
    $mensagem = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$mensagem) {
        header("Location: /admin/mensagens.php?msg=mensagem_nao_encontrada");
        exit;
    }
    
    // Excluir a mensagem
    $stmt = $pdo->prepare("DELETE FROM mensagens WHERE id = ?");
    $resultado = $stmt->execute([$id]);
    
    if ($resultado) {
        header("Location: /admin/mensagens.php?msg=excluido_sucesso");
    } else {
        header("Location: /admin/mensagens.php?msg=erro_exclusao");
    }
    exit;
    
} catch (PDOException $e) {
    error_log("Erro ao excluir mensagem: " . $e->getMessage());
    header("Location: /admin/mensagens.php?msg=erro_sistema");
    exit;
}