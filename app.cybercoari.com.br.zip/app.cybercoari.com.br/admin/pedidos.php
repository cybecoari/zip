<?php
session_start();
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

// 🔒 Verificação de login
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

// 🔹 Recupera usuário e tema
$usuario = getUsuario($pdo);
$tema = $usuario['tema'] ?? ($_SESSION['tema'] ?? 'claro');
$_SESSION['tema'] = $tema;

// 🔄 AJAX: atualização de status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'], $_POST['id'], $_POST['status']) && $_POST['acao'] === 'atualizar') {
    header('Content-Type: application/json; charset=utf-8');

    $id = (int) $_POST['id'];
    $status = $_POST['status'];

    $permitidos = ['pendente', 'pago', 'cancelado'];
    if (in_array($status, $permitidos)) {
        $stmt = $pdo->prepare("UPDATE pedidos SET status = ? WHERE id = ?");
        if ($stmt->execute([$status, $id])) {
            echo json_encode(["success" => true, "msg" => "Status atualizado com sucesso"]);
        } else {
            echo json_encode(["success" => false, "msg" => "Erro ao atualizar pedido"]);
        }
    } else {
        echo json_encode(["success" => false, "msg" => "Status inválido"]);
    }
    exit();
}

// 📋 Lista pedidos
$stmt = $pdo->query("SELECT * FROM pedidos ORDER BY id DESC");
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Painel de Pedidos</title>
  <?php include __DIR__ . '/includes/cdn.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Bootstrap + Ícones -->
  <link rel="stylesheet" href="https://cybercoari.com.br/cyber/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <!-- SweetAlert -->
  <script src="https://cybercoari.com.br/cyber/js/sweetalert2.all.min.js"></script>
  <script src="https://cybercoari.com.br/cyber/js/jquery-3.7.1.min.js"></script>

  <!-- Darkmode CSS -->
  <link rel="stylesheet" href="/assets/css/darkmode.css?v=7">

  <style>
    body.dark-mode {
      background-color: #121212;
      color: #f1f1f1;
    }
    .table-dark th, .table-dark td {
      color: #f1f1f1;
    }
  </style>
</head>
<body class="container py-4 <?= $tema === 'escuro' ? 'dark-mode bg-dark text-white' : 'bg-light' ?>">

  <h2 class="mb-4"><i class="bi bi-bag-check"></i> Painel de Pedidos</h2>

  <table class="table table-bordered table-striped <?= $tema === 'escuro' ? 'table-dark' : '' ?>" id="tabela-pedidos">
    <thead class="<?= $tema === 'escuro' ? 'table-light text-dark' : 'table-dark' ?>">
      <tr>
        <th>#</th>
        <th>Produto</th>
        <th>Valor</th>
        <th>Txid</th>
        <th>Status</th>
        <th>Criado em</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($pedidos): ?>
        <?php foreach ($pedidos as $p): ?>
        <tr data-id="<?= $p['id'] ?>">
          <td><?= $p['id'] ?></td>
          <td><?= htmlspecialchars($p['produto_nome']) ?></td>
          <td>R$ <?= number_format($p['valor'], 2, ',', '.') ?></td>
          <td><small><?= htmlspecialchars($p['txid']) ?></small></td>
          <td class="col-status">
            <?php if ($p['status'] === 'pendente'): ?>
              <span class="badge bg-warning text-dark">Pendente</span>
            <?php elseif ($p['status'] === 'pago'): ?>
              <span class="badge bg-success">Pago</span>
            <?php else: ?>
              <span class="badge bg-danger">Cancelado</span>
            <?php endif; ?>
          </td>
          <td><?= date("d/m/Y H:i", strtotime($p['criado_em'])) ?></td>
          <td class="col-acoes">
            <?php if ($p['status'] !== 'pago'): ?>
              <button class="btn btn-sm btn-success btn-status" data-id="<?= $p['id'] ?>" data-status="pago">
                <i class="bi bi-check-circle"></i> Marcar Pago
              </button>
            <?php endif; ?>

            <?php if ($p['status'] !== 'cancelado'): ?>
              <button class="btn btn-sm btn-danger btn-status" data-id="<?= $p['id'] ?>" data-status="cancelado">
                <i class="bi bi-x-circle"></i> Cancelar
              </button>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr>
          <td colspan="7" class="text-center">Nenhum pedido encontrado</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <a href="../painel.php" class="btn btn-outline-secondary mt-3" onclick="document.getElementById('som-clique').play();">
    <i class="bi bi-arrow-left"></i> Voltar
  </a>

  <!-- Sons -->
  <audio id="som-clique" src="https://cybercoari.com.br/cyber/audio/click.mp3" preload="auto"></audio>
  <audio id="som-sucesso" src="https://cybercoari.com.br/cyber/audio/sucesso.mp3" preload="auto"></audio>
  <audio id="som-erro" src="https://cybercoari.com.br/cyber/audio/erro.mp3" preload="auto"></audio>

  <script>
    document.querySelectorAll(".btn-status").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        const status = btn.dataset.status;

        document.getElementById("som-clique").play();

        fetch("", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: `acao=atualizar&id=${id}&status=${status}`
        })
        .then(r => r.json())
        .then(dados => {
          if (dados.success) {
            document.getElementById("som-sucesso").play();
            Swal.fire({
              icon: "success",
              title: "Sucesso",
              text: dados.msg,
              timer: 1500,
              showConfirmButton: false
            }).then(() => location.reload());
          } else {
            document.getElementById("som-erro").play();
            Swal.fire({
              icon: "error",
              title: "Erro",
              text: dados.msg
            });
          }
        });
      });
    });
  </script>
</body>
</html>