<?php
session_start();
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../config/debug.php';

// Garante login
checkLogin();

// Carrega dados do usuário logado
$usuario = getUsuario($pdo);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <?php include __DIR__ . '/../config/cdn.php'; ?>
    <link rel="stylesheet" href="/assets/css/darkmode.css?v=3">
</head>
<body class="<?= $usuario['tema'] === 'escuro' ? 'dark-mode' : ''; ?>">

<?php include __DIR__ . '/../includes/header.php'; ?>

<div class="container mt-4">
    <form action="salvar_perfil.php" method="post">
        <div class="mb-3">
            <label for="tema" class="form-label">Tema:</label>
            <select name="tema" id="tema" class="form-select">
                <option value="claro" <?= $usuario['tema'] === 'claro' ? 'selected' : ''; ?>>Claro</option>
                <option value="escuro" <?= $usuario['tema'] === 'escuro' ? 'selected' : ''; ?>>Escuro</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="banner" class="form-label">Link do Banner:</label>
            <input type="url" name="banner" id="banner" class="form-control"
                   value="<?= e($usuario['banner']); ?>"
                   placeholder="https://exemplo.com/imagem.png" required
                   oninput="previewBanner(this.value)">
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="largura" class="form-label">Largura (px):</label>
                <input type="number" name="largura" id="largura" class="form-control"
                       value="<?= e($usuario['banner_largura'] ?? 400); ?>" min="50" max="2000"
                       oninput="ajustarPreview()">
            </div>
            <div class="col-md-6 mb-3">
                <label for="altura" class="form-label">Altura (px):</label>
                <input type="number" name="altura" id="altura" class="form-control"
                       value="<?= e($usuario['banner_altura'] ?? 200); ?>" min="50" max="2000"
                       oninput="ajustarPreview()">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        <a href="/painel.php" class="btn btn-secondary">Voltar ao Painel</a>
    </form>

    <hr>

    <h3>Pré-visualização:</h3>
    <img id="previewBanner" 
         src="<?= e($usuario['banner']); ?>" 
         alt="Prévia do banner"
         style="max-width:100%; width:<?= e($usuario['banner_largura'] ?? 400); ?>px; height:<?= e($usuario['banner_altura'] ?? 200); ?>px; border-radius:10px;">
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<script>
function previewBanner(url) {
    const img = document.getElementById('previewBanner');
    if (url) img.src = url;
}

function ajustarPreview() {
    const img = document.getElementById('previewBanner');
    const largura = document.getElementById('largura').value;
    const altura = document.getElementById('altura').value;
    img.style.width = largura + 'px';
    img.style.height = altura + 'px';
}

<?php if (isset($_GET['atualizado'])): ?>
Swal.fire({
    icon: 'success',
    title: 'Perfil atualizado!',
    text: 'As alterações foram salvas com sucesso.',
    confirmButtonColor: '#3085d6',
    confirmButtonText: 'OK'
});
<?php elseif (isset($_GET['erro'])): ?>
Swal.fire({
    icon: 'error',
    title: 'Erro!',
    text: 'Não foi possível atualizar o perfil. Tente novamente.',
    confirmButtonColor: '#d33',
    confirmButtonText: 'Fechar'
});
<?php endif; ?>
</script>

</body>
</html>