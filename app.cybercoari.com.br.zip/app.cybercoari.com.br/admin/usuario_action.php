<?php
session_start();
require_once '../config/conexao.php';
require_once '../config/funcoes.php';

// Verifica login
checkLogin();

// Apenas Admin ou SuperAdmin
if (!isAdmin()) {
    $_SESSION['flash_message'] = "Acesso negado!";
    $_SESSION['flash_type'] = "error";
    header("Location: ../painel.php");
    exit;
}

$acao = $_GET['acao'] ?? '';
$id   = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    $_SESSION['flash_message'] = "ID inválido!";
    $_SESSION['flash_type'] = "error";
    header("Location: ../painel.php");
    exit;
}

switch ($acao) {
    case 'excluir':
        // Impede exclusão do próprio usuário
        if ($id == $_SESSION['usuario_id']) {
            $_SESSION['flash_message'] = "Você não pode excluir seu próprio usuário!";
            $_SESSION['flash_type'] = "warning";
            header("Location: ../painel.php");
            exit;
        }

        // Busca nível do usuário alvo
        $stmt = $pdo->prepare("SELECT nivel FROM usuarios WHERE id=?");
        $stmt->execute([$id]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$usuario) {
            $_SESSION['flash_message'] = "Usuário não encontrado!";
            $_SESSION['flash_type'] = "error";
            header("Location: ../painel.php");
            exit;
        }

        // Impede exclusão de SuperAdmin
        if ($usuario['nivel'] == 3) {
            $_SESSION['flash_message'] = "Você não pode excluir um SuperAdmin!";
            $_SESSION['flash_type'] = "warning";
            header("Location: ../painel.php");
            exit;
        }

        // Executa exclusão
        $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id=?");
        if ($stmt->execute([$id])) {
            $_SESSION['flash_message'] = "Usuário excluído com sucesso!";
            $_SESSION['flash_type'] = "success";
        } else {
            $_SESSION['flash_message'] = "Erro ao excluir usuário.";
            $_SESSION['flash_type'] = "error";
        }

        header("Location: ../painel.php");
        exit;

    case 'editar':
        header("Location: editar_usuario.php?id=$id");
        exit;

    default:
        $_SESSION['flash_message'] = "Ação inválida!";
        $_SESSION['flash_type'] = "error";
        header("Location: ../painel.php");
        exit;
}