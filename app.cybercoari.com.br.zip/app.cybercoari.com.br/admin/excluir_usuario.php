<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../config/debug.php';

checkLogin();
if (!isAdmin()) {
    die("Acesso negado!");
}

$id = intval($_GET['id'] ?? 0);

// Impede exclusão inválida
if ($id <= 0) {
    header("Location: ../painel.php?msg=erro");
    exit;
}

// Impede excluir a si mesmo
if ($id === intval($_SESSION['usuario_id'])) {
    header("Location: ../painel.php?msg=erro&detalhe=self");
    exit;
}

try {
    // Verifica se o usuário existe e se não é SuperAdmin
    $stmt = $pdo->prepare("SELECT nivel FROM usuarios WHERE id=?");
    $stmt->execute([$id]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        header("Location: ../painel.php?msg=erro&detalhe=nao_encontrado");
        exit;
    }

    if ($usuario['nivel'] == 3) {
        header("Location: ../painel.php?msg=erro&detalhe=superadmin");
        exit;
    }

    // Exclui usuário
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id=?");
    if ($stmt->execute([$id])) {
        header("Location: ../painel.php?msg=deletado");
        exit;
    } else {
        header("Location: ../painel.php?msg=erro&detalhe=db");
        exit;
    }
} catch (PDOException $e) {
    header("Location: ../painel.php?msg=erro&detalhe=exception");
    exit;
}