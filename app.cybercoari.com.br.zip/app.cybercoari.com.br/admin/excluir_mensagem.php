<?php
require_once __DIR__ . "/../config/conexao.php";
require_once __DIR__ . "/../config/funcoes.php";

if (!isAdmin()) {
    die("Acesso negado!");
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    try {
        $stmt = $pdo->prepare("DELETE FROM mensagens WHERE id = :id");
        $stmt->execute([':id' => $id]);

        header("Location: /admin/mensagens.php?sucesso=1");
        exit;
    } catch (Exception $e) {
        echo "Erro ao excluir: " . $e->getMessage();
    }
} else {
    echo "ID inválido!";
}