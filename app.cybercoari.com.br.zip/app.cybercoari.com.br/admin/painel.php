<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../config/debug.php';

checkLogin();
$usuario = getUsuario($pdo);
if (!$usuario) {
    session_unset();
    session_destroy();
    header("Location: /login.php?msg=not_logged");
    exit;
}

// Atualiza atividade
registrarOnline($pdo, $usuario['id']);

// Só busca usuários se for admin
$usuarios = [];
if (isAdmin()) {
    try {
        $stmt = $pdo->query("SELECT * FROM usuarios ORDER BY id ASC");
        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (PDOException $e) {
        error_log("Erro ao buscar usuários: " . $e->getMessage());
        $erroUsuarios = "Erro ao carregar lista de usuários";
    }
}

// Tema vem do banco e sincroniza com a sessão
$tema = $usuario['tema'] ?? 'claro';
$_SESSION['tema'] = $tema;

// Totais
$totalCadastros = getTotalCadastros($pdo);
$onlineInfo     = getUsuariosOnlineInfo($pdo);

// Fundação do site
$fundacao = function_exists('getDiasFundacao') ? getDiasFundacao($pdo) : null;

// Flash messages
$flashMessage = "";
$flashType = "";
if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case 'excluido':
            $flashMessage = "Usuário excluído com sucesso!";
            $flashType = "success";
            break;
        case 'erro':
            $flashMessage = "Ocorreu um erro. Tente novamente.";
            $flashType = "error";
            break;
        case 'sucesso':
            $flashMessage = "Operação realizada com sucesso!";
            $flashType = "success";
            break;
    }
}

$title = "Painel Administrativo";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($title) ?></title>
  <?php include __DIR__ . '/../includes/cdn.php'; ?>
  <link rel="stylesheet" href="/assets/css/darkmode.css?v=5">
  <style>
    .stats-card {
      transition: transform 0.2s;
    }
    .stats-card:hover {
      transform: translateY(-2px);
    }
  </style>
</head>
<body 
    class="<?= $tema === 'escuro' ? 'dark-mode' : 'bg-light'; ?>"
    data-flash-message="<?= htmlspecialchars($flashMessage) ?>"
    data-flash-type="<?= htmlspecialchars($flashType) ?>"
>
  <?php include __DIR__ . '/../includes/navbar.php'; ?>

  <?php if (!empty($onlineInfo['lista'])): ?>
  <ul class="list-group list-group-flush">
    <?php foreach ($onlineInfo['lista'] as $u): ?>
      <li class="list-group-item d-flex justify-content-between align-items-center">
        <span>
          <i class="bi bi-person-circle"></i> 
          <?= e($u['usuario']); ?>
          <?php 
          // Verifica se é o usuário atual comparando o nome de usuário
          // em vez do ID (que não está disponível na lista online)
          if (isset($u['usuario']) && $u['usuario'] === $usuario['usuario']): 
          ?>
            <span class="badge bg-primary ms-1">Você</span>
          <?php endif; ?>
        </span>
        <small class="text-muted"><?= date("H:i", strtotime($u['ultima_atividade'])); ?></small>
      </li>
    <?php endforeach; ?>
  </ul>
<?php else: ?>
  <p class="text-muted mb-0 text-center">Nenhum usuário online no momento.</p>
<?php endif; ?>
            <p class="text-muted mb-0">Usuários Online</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card stats-card shadow-sm border-0">
          <div class="card-body text-center">
            <h3 class="text-info"><?= count($usuarios) ?></h3>
            <p class="text-muted mb-0">Usuários no Sistema</p>
          </div>
        </div>
      </div>
    </div>

    <?php if ($fundacao): ?>
      <div class="text-center mb-4">
        <div class="alert alert-info d-inline-block">
          <strong>🏗️ Site Online há <?= $fundacao['dias'] ?> dias</strong>
          <?php if ($fundacao['anos'] > 0): ?>
            <br><small>(<?= $fundacao['anos'] ?> anos, <?= $fundacao['meses'] ?> meses e <?= $fundacao['diasDetalhado'] ?> dias)</small>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <!-- Usuários Online -->
  <div class="container">
    <div class="card shadow-sm mb-4" style="border-radius:12px;">
      <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-people-fill"></i> Usuários Online</span>
        <span class="badge bg-light text-success"><?= e($onlineInfo['total']); ?></span>
      </div>
      <div class="card-body">
        <?php if (!empty($onlineInfo['lista'])): ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($onlineInfo['lista'] as $u): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center">
                <span>
                  <i class="bi bi-person-circle"></i> 
                  <?= e($u['usuario']); ?>
                  <?php if ($u['id'] == $usuario['id']): ?>
                    <span class="badge bg-primary ms-1">Você</span>
                  <?php endif; ?>
                </span>
                <small class="text-muted"><?= date("H:i", strtotime($u['ultima_atividade'])); ?></small>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="text-muted mb-0 text-center">Nenhum usuário online no momento.</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Lista de Usuários (somente Admin) -->
  <?php if (isAdmin()): ?>
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2><i class="bi bi-people"></i> Gerenciar Usuários</h2>
      <a href="/admin/criar_usuario.php" class="btn btn-primary">
        <i class="bi bi-person-plus"></i> Novo Usuário
      </a>
    </div>

    <?php if (isset($erroUsuarios)): ?>
      <div class="alert alert-warning"><?= $erroUsuarios ?></div>
    <?php endif; ?>

    <div class="table-responsive">
      <table class="table table-bordered table-striped table-hover rounded">
          <thead class="table-dark">
              <tr>
                  <th>ID</th>
                  <th>Usuário</th>
                  <th>Email</th>
                  <th>Nível</th>
                  <th>Tema</th>
                  <th>Data Fundação</th>
                  <th>Último Login</th>
                  <th>Ações</th>
              </tr>
          </thead>
          <tbody>
          <?php foreach ($usuarios as $u): ?>
              <tr>
                  <td><strong><?= $u['id'] ?></strong></td>
                  <td>
                    <?= htmlspecialchars($u['usuario']) ?>
                    <?php if ($u['id'] == $usuario['id']): ?>
                      <span class="badge bg-info">Você</span>
                    <?php endif; ?>
                  </td>
                  <td><?= htmlspecialchars($u['email']) ?></td>
                  <td>
                    <span class="badge bg-<?= match ($u['nivel']) {
                        1 => 'warning',
                        2 => 'secondary', 
                        3 => 'danger',
                        default => 'dark'
                    }; ?>">
                      <?= match ($u['nivel']) {
                          1 => "Administrador",
                          2 => "Usuário",
                          3 => "SuperAdmin",
                          default => "?"
                      }; ?>
                    </span>
                  </td>
                  <td>
                    <span class="badge bg-<?= $u['tema'] === 'escuro' ? 'dark' : 'light text-dark'; ?>">
                      <?= $u['tema'] === 'escuro' ? '🌙 Escuro' : '☀️ Claro'; ?>
                    </span>
                  </td>
                  <td><?= $u['data_fundacao'] ? date("d/m/Y", strtotime($u['data_fundacao'])) : '-' ?></td>
                  <td><?= $u['ultimo_login'] ? date("d/m/Y H:i", strtotime($u['ultimo_login'])) : 'Nunca' ?></td>
                  <td>
                      <a href="/admin/editar_usuario.php?id=<?= $u['id'] ?>" class="btn btn-primary btn-sm">
                        <i class="bi bi-pencil"></i> Editar
                      </a>
                      <?php if ($u['id'] != $usuario['id']): ?>
                      <a href="/admin/excluir_usuario.php?id=<?= $u['id'] ?>" 
                         class="btn btn-danger btn-sm"
                         onclick="return confirm('Tem certeza que deseja excluir <?= htmlspecialchars($u['usuario']) ?>?');">
                         <i class="bi bi-trash"></i> Excluir
                      </a>
                      <?php else: ?>
                        <button class="btn btn-outline-secondary btn-sm" disabled>Seu usuário</button>
                      <?php endif; ?>
                  </td>
              </tr>
          <?php endforeach; ?>
          </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

<?php include __DIR__ . "/../includes/footer.php"; ?>

<script>
// Flash messages com SweetAlert2
document.addEventListener('DOMContentLoaded', function() {
    const flashMessage = document.body.getAttribute('data-flash-message');
    const flashType = document.body.getAttribute('data-flash-type');
    
    if (flashMessage && flashType) {
        if (flashType === 'success') {
            Swal.fire({
                icon: 'success',
                title: 'Sucesso!',
                text: flashMessage,
                timer: 3000,
                showConfirmButton: false
            });
        } else if (flashType === 'error') {
            Swal.fire({
                icon: 'error',
                title: 'Erro!',
                text: flashMessage,
                timer: 4000
            });
        }
    }
});
</script>

</body>
</html>