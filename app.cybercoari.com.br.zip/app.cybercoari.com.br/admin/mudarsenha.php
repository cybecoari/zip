<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../config/debug.php';

checkLogin();

// Dados do usuário logado
$id = intval($_SESSION['usuario_id']);
if ($id <= 0) {
    header("Location: /login.php");
    exit;
}

// Recupera o tema
$usuario = getUsuario($pdo);
$tema = $usuario['tema'] ?? 'claro';
$_SESSION['tema'] = $tema;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senhaAtual = $_POST['senha_atual'] ?? '';
    $novaSenha  = $_POST['nova_senha'] ?? '';
    $confirmar  = $_POST['confirmar'] ?? '';

    if (empty($senhaAtual) || empty($novaSenha) || empty($confirmar)) {
        header("Location: mudarsenha.php?msg=erro&detalhe=campos");
        exit;
    }

    if ($novaSenha !== $confirmar) {
        header("Location: mudarsenha.php?msg=erro&detalhe=confirmacao");
        exit;
    }

    $stmt = $pdo->prepare("SELECT senha FROM usuarios WHERE id=?");
    $stmt->execute([$id]);
    $dadosUsuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($dadosUsuario && password_verify($senhaAtual, $dadosUsuario['senha'])) {
        $hash = password_hash($novaSenha, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE usuarios SET senha=? WHERE id=?");
        if ($stmt->execute([$hash, $id])) {
            header("Location: mudarsenha.php?msg=sucesso");
            exit;
        } else {
            header("Location: mudarsenha.php?msg=erro&detalhe=db");
            exit;
        }
    } else {
        header("Location: mudarsenha.php?msg=erro&detalhe=atual_invalida");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mudar Senha</title>
<?php include __DIR__ . '/../config/cdn.php'; ?>
<link rel="stylesheet" href="/assets/css/darkmode.css?v=4">
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode' : 'bg-light'; ?>">
<?php include __DIR__ . '/../includes/header.php'; ?>

<div class="container py-5">
    <h1 class="mb-4">Alterar Senha</h1>

    <form method="post">
        <div class="mb-3">
            <label class="form-label">Senha Atual</label>
            <input type="password" name="senha_atual" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Nova Senha</label>
            <input type="password" name="nova_senha" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Confirmar Nova Senha</label>
            <input type="password" name="confirmar" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-warning">Alterar Senha</button>
        <a href="/painel.php" class="btn btn-success">Voltar</a>
    </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php if (isset($_GET['msg'])): ?>
<script>
    <?php if ($_GET['msg'] === 'sucesso'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Senha Alterada!',
            text: 'Sua senha foi atualizada com sucesso.',
            confirmButtonText: 'OK'
        });
    <?php elseif ($_GET['msg'] === 'erro'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Erro!',
            text: 'Não foi possível alterar a senha.',
            confirmButtonText: 'OK'
        });
    <?php endif; ?>
</script>
<?php endif; ?>
</body>
</html>