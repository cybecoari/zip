<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../config/debug.php';

checkLogin();
if (!isAdmin()) {
    die("Acesso negado!");
}

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: painel.php?msg=erro");
    exit;
}

// Busca dados do usuário
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    header("Location: painel.php?msg=erro");
    exit;
}

// Atualiza usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email        = trim($_POST['email'] ?? '');
    $nivel        = intval($_POST['nivel'] ?? 2);
    $temaNovo     = $_POST['tema'] ?? 'claro';
    $dataFundacao = !empty($_POST['data_fundacao']) ? $_POST['data_fundacao'] : null;

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: editar_usuario.php?id=$id&msg=erro");
        exit;
    }

    if (!in_array($nivel, [1, 2, 3])) $nivel = 2;
    if (!in_array($temaNovo, ['claro', 'escuro'])) $temaNovo = 'claro';

    try {
        $stmt = $pdo->prepare("
            UPDATE usuarios 
            SET email=?, nivel=?, tema=?, data_fundacao=? 
            WHERE id=?
        ");
        $ok = $stmt->execute([$email, $nivel, $temaNovo, $dataFundacao, $id]);

        header("Location: editar_usuario.php?id=$id&msg=" . ($ok ? 'sucesso' : 'erro'));
        exit;
    } catch (PDOException $e) {
        header("Location: editar_usuario.php?id=$id&msg=erro");
        exit;
    }
}

// Tema do usuário logado (para body)
$tema = ($_SESSION['tema'] ?? 'claro') === 'escuro' ? 'escuro' : 'claro';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Editar Usuário</title>
<?php include __DIR__ . '/../config/cdn.php'; ?>
<link rel="stylesheet" href="/assets/css/darkmode.css?v=4">
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode' : 'bg-light'; ?>">

<?php include __DIR__ . '/../includes/header.php'; ?>

<div class="container py-5">
    <h1 class="mb-4">Editar Usuário</h1>

    <form method="post">
        <div class="mb-3">
            <label class="form-label">Usuário</label>
            <input type="text" value="<?= htmlspecialchars($usuario['usuario']) ?>" class="form-control" disabled>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($usuario['email']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Nível</label>
            <select name="nivel" class="form-select">
                <option value="2" <?= $usuario['nivel']==2?'selected':'' ?>>Usuário</option>
                <option value="1" <?= $usuario['nivel']==1?'selected':'' ?>>Administrador</option>
                <option value="3" <?= $usuario['nivel']==3?'selected':'' ?>>SuperAdmin</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Tema</label>
            <select name="tema" class="form-select">
                <option value="claro" <?= $usuario['tema']=='claro'?'selected':'' ?>>Claro</option>
                <option value="escuro" <?= $usuario['tema']=='escuro'?'selected':'' ?>>Escuro</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Data de Fundação</label>
            <input type="date" name="data_fundacao" class="form-control" value="<?= htmlspecialchars($usuario['data_fundacao'] ?? '') ?>">
        </div>

        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        <a href="/painel.php" class="btn btn-secondary">Voltar</a>
    </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php if (isset($_GET['msg'])): ?>
<script>
    <?php if ($_GET['msg'] === 'sucesso'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Sucesso!',
            text: 'Usuário atualizado com sucesso.',
            confirmButtonText: 'OK'
        });
    <?php elseif ($_GET['msg'] === 'erro'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Erro!',
            text: 'Não foi possível atualizar o usuário.',
            confirmButtonText: 'OK'
        });
    <?php endif; ?>
</script>
<?php endif; ?>

</body>
</html>