<?php
session_start();
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../config/debug.php';

// Garante login
checkLogin();

$id = $_SESSION['usuario_id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $id) {
    $tema    = $_POST['tema'] ?? 'claro';
    $banner  = trim($_POST['banner']);
    $largura = (int) ($_POST['largura'] ?? 400);
    $altura  = (int) ($_POST['altura'] ?? 200);

    // ✅ Validações
    $tema = in_array($tema, ['claro', 'escuro']) ? $tema : 'claro';

    if (!filter_var($banner, FILTER_VALIDATE_URL)) {
        header("Location: perfil.php?erro=link");
        exit;
    }

    $largura = max(50, min($largura, 2000));
    $altura  = max(50, min($altura, 2000));

    try {
        $stmt = $pdo->prepare("
            UPDATE usuarios 
            SET tema = :tema, banner = :banner, 
                banner_largura = :largura, banner_altura = :altura 
            WHERE id = :id
        ");
        $stmt->execute([
            'tema'    => $tema,
            'banner'  => $banner,
            'largura' => $largura,
            'altura'  => $altura,
            'id'      => $id
        ]);

        // Atualiza o tema na sessão também
        $_SESSION['tema'] = $tema;

        header("Location: perfil.php?atualizado=1");
        exit;
    } catch (Exception $e) {
        if (function_exists('debugLog')) {
            debugLog("Erro ao atualizar perfil: " . $e->getMessage());
        }
        header("Location: perfil.php?erro=db");
        exit;
    }
}

// Se não for POST ou não tiver id
header("Location: perfil.php?erro=1");
exit;