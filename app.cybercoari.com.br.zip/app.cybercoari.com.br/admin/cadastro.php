<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
require_once __DIR__ . '/../config/debug.php';

checkLogin();
if (!isAdmin()) {
    die("Acesso negado!");
}

// Dados do usuário logado
$usuario = getUsuario($pdo);
if (!$usuario) {
    session_unset();
    session_destroy();
    header("Location: /login.php");
    exit;
}

// Tema do banco e sincroniza com a sessão
$tema = $usuario['tema'] ?? 'claro';
$_SESSION['tema'] = $tema;

// Processa cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $novoUsuario   = trim($_POST['usuario'] ?? '');
    $senha         = $_POST['senha'] ?? '';
    $email         = trim($_POST['email'] ?? '');
    $nivel         = intval($_POST['nivel'] ?? 2);
    $temaNovo      = $_POST['tema'] ?? 'claro';
    $dataFundacao  = !empty($_POST['data_fundacao']) ? $_POST['data_fundacao'] : null;

    // Força nível válido
    $nivel = in_array($nivel, [1,2,3]) ? $nivel : 2;

    if (empty($novoUsuario) || empty($senha)) {
        header("Location: cadastro.php?msg=erro&detalhe=campos");
        exit;
    }

    try {
        // Verifica duplicado
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE usuario = ?");
        $stmt->execute([$novoUsuario]);

        if ($stmt->rowCount() > 0) {
            header("Location: cadastro.php?msg=erro&detalhe=duplicado");
            exit;
        } else {
            // Insere
            $hash = password_hash($senha, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("
                INSERT INTO usuarios (usuario, senha, email, nivel, tema, data_fundacao) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            if ($stmt->execute([$novoUsuario, $hash, $email, $nivel, $temaNovo, $dataFundacao])) {
                header("Location: cadastro.php?msg=sucesso");
                exit;
            } else {
                header("Location: cadastro.php?msg=erro&detalhe=db");
                exit;
            }
        }
    } catch (PDOException $e) {
        header("Location: cadastro.php?msg=erro&detalhe=exception");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cadastrar Usuário</title>
<?php include __DIR__ . '/../config/cdn.php'; ?>
<link rel="stylesheet" href="/assets/css/darkmode.css?v=4">
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode' : 'bg-light'; ?>">

<?php include __DIR__ . '/../includes/header.php'; ?>

<div class="container py-5">
    <h1 class="mb-4">Cadastrar Usuário</h1>

    <form method="post">
        <div class="mb-3">
            <label class="form-label">Usuário</label>
            <input type="text" name="usuario" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Senha</label>
            <input type="password" name="senha" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Nível</label>
            <select name="nivel" class="form-select">
                <option value="2">Usuário</option>
                <option value="1">Administrador</option>
                <option value="3">SuperAdmin</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Tema</label>
            <select name="tema" class="form-select">
                <option value="claro">Claro</option>
                <option value="escuro">Escuro</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Data de Fundação</label>
            <input type="date" name="data_fundacao" class="form-control">
            <small class="text-muted">Opcional — se não preencher, ficará vazio.</small>
        </div>

        <button type="submit" class="btn btn-secondary">Cadastrar</button>
        <a href="/painel.php" class="btn btn-success">Voltar</a>
    </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php if (isset($_GET['msg'])): ?>
<script>
    <?php if ($_GET['msg'] === 'sucesso'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Sucesso!',
            text: 'Usuário cadastrado com sucesso.',
            confirmButtonText: 'OK'
        });
    <?php elseif ($_GET['msg'] === 'erro'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Erro!',
            text: 'Não foi possível cadastrar o usuário.',
            confirmButtonText: 'OK'
        });
    <?php endif; ?>
</script>
<?php endif; ?>

</body>
</html>