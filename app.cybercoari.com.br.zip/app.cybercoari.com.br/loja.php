<?php
include 'config/conexao.php';
include 'config/funcoes.php';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Loja | CyberCoari</title>
  <?php include __DIR__ . "/includes/cdn.php"?>

  

  <style>
    body {
      padding: 20px;
    }
    .produto-card {
      border: 1px solid #dee2e6;
      border-radius: 12px;
      padding: 15px;
      margin-bottom: 20px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      text-align: center;
    }
    .produto-img {
      max-height: 200px;
      object-fit: cover;
    }
  </style>
</head>
<body>
  
   <div class="container">

    <!-- Botão Voltar -->
    <a href="/painel.php" class="btn btn-outline-secondary mb-3">
      <i class="bi bi-arrow-left"></i> Voltar
    </a>

    <h2 class="mb-4 text-center"><i class="bi bi-shop"></i> Produtos disponíveis</h2>

    <div class="row justify-content-center text-center">
      <?php
      $sql = "SELECT * FROM products ORDER BY id DESC";
      $stmt = $pdo->query($sql);

      if ($stmt->rowCount() > 0):
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
      ?>
        <div class="col-md-4">
          <div class="produto-card">
            <?php if (!empty($row['image_url'])): ?>
              <img src="<?= htmlspecialchars($row['image_url']) ?>" class="img-fluid produto-img mb-3" alt="Produto">
            <?php endif; ?>
            <h5><?= htmlspecialchars($row['name']) ?></h5>
            <p class="mb-1">Preço: R$ <?= number_format($row['price'], 2, ',', '.') ?></p>
            <p class="mb-3">Entrega: <?= htmlspecialchars($row['delivery_type']) ?></p>
    
    <a href="api/pagamento.php?id=<?= $row['id'] ?>" class="btn btn-success w-100">
    
    <i class="bi bi-cash-coin"></i> Comprar com PIX
            </a>
          </div>
        </div>
      <?php
        endwhile;
      else:
        echo "<div class='alert alert-warning w-100 text-center'>Nenhum produto cadastrado ainda.</div>";
      endif;
      ?>
    </div>
  </div>

  <!-- Sons -->
  <audio id="som-clique" src="https://cybercoari.com.br/cyber/audio/click.mp3" preload="auto"></audio>
  <audio id="som-sucesso" src="https://cybercoari.com.br/cyber/audio/success.mp3" preload="auto"></audio>
  <audio id="som-erro" src="https://cybercoari.com.br/cyber/audio/error.mp3" preload="auto"></audio>

  <script>
    $(document).on('click', 'a.btn-success', function () {
      document.getElementById('som-clique').play();
    });
  </script>

</body>
</html>