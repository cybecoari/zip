<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ferramentas de QR Code</title>

  <!-- Bootstrap CSS -->
  <link href="https://cybercoari.com.br/cyber/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cybercoari.com.br/cyber/icones/font/bootstrap-icons.css" rel="stylesheet">
  <!-- jQuery -->
  <script src="https://cybercoari.com.br/cyber/js/jquery-3.7.1.min.js"></script>
  <!-- SweetAlert2 -->
  <script src="https://cybercoari.com.br/cyber/js/sweetalert2.all.min.js"></script>
  <!-- QRCodeJS -->
  <script src="https://cybercoari.com.br/cyber/js/qrcode.min.js"></script>
  <!-- Html5 QR Code -->
  <script src="https://unpkg.com/html5-qrcode@2.3.8/dist/html5-qrcode.min.js"></script>
  <!--<script src="/assets/js/html5-qrcode.min.js"></script>-->

  <style>
    body {
      background: #121212;
      color: #f0f0f0;
    }
    .form-control, .btn {
      background-color: #1f1f1f;
      color: #fff;
      border: 1px solid #444;
    }
    .qr-container canvas {
      max-width: 100%;
      margin-top: 15px;
    }
    #reader {
      width: 100%;
      max-width: 300px;
      margin: auto;
    }
  </style>
</head>
<body class="container py-4">

  <h2 class="text-center mb-4">Ferramentas de QR Code</h2>

  <div class="row g-4">
    <!-- GERADOR -->
    <div class="col-md-6">
      <h5>Gerar QR Code</h5>
      <input type="text" id="texto" class="form-control" placeholder="Digite um link ou texto...">
      <div id="qrcode" class="qr-container text-center mt-3"></div>
      <div class="text-center mt-2">
        <button class="btn btn-success me-2" id="btnDownload" style="display:none;" onclick="baixarQRCode()">
          <i class="bi bi-download"></i> Baixar QR Code
        </button>
        <button class="btn btn-outline-light" id="btnCopiar" style="display:none;" onclick="copiarQRCode()">
          <i class="bi bi-clipboard"></i> Copiar QR Code
        </button>
      </div>
    </div>

    <!-- LEITOR -->
    <div class="col-md-6">
      <h5>Ler QR Code</h5>
      <input type="file" accept="image/*" id="qr-input" class="form-control mb-3">
      <div id="qr-reader" class="text-center mb-3"></div>
      <button class="btn btn-primary w-100" onclick="iniciarCamera()">
        <i class="bi bi-camera-video"></i> Ler com câmera
      </button>
      <div id="reader" class="mt-3"></div>
    </div>
  </div>

  <audio id="beep" src="/assets/sounds/beep.mp3" preload="auto"></audio>

  <script>
    // Gerador QR Code
    const input = document.getElementById('texto');
    const qrcodeDiv = document.getElementById("qrcode");
    const btnDownload = document.getElementById("btnDownload");
    const btnCopiar = document.getElementById("btnCopiar");
    let qrcode;

    input.addEventListener("input", () => {
      const texto = input.value.trim();
      qrcodeDiv.innerHTML = "";
      btnDownload.style.display = "none";
      btnCopiar.style.display = "none";
      if (texto !== "") {
        qrcode = new QRCode(qrcodeDiv, {
          text: texto,
          width: 200,
          height: 200,
          colorDark: "#ffffff",
          colorLight: "#121212",
          correctLevel: QRCode.CorrectLevel.H
        });
        setTimeout(() => {
          btnDownload.style.display = "inline-block";
          btnCopiar.style.display = "inline-block";
        }, 300);
      }
    });

    function baixarQRCode() {
      const canvas = document.querySelector("#qrcode canvas");
      if (canvas) {
        const url = canvas.toDataURL("image/png");
        const link = document.createElement('a');
        link.href = url;
        link.download = 'qrcode.png';
        link.click();
      }
    }

    function copiarQRCode() {
      const canvas = document.querySelector("#qrcode canvas");
      if (!canvas) return;
      canvas.toBlob(blob => {
        const item = new ClipboardItem({ "image/png": blob });
        navigator.clipboard.write([item]).then(() => {
          Swal.fire('Copiado!', 'QR Code copiado para a área de transferência.', 'success');
        }).catch(() => {
          Swal.fire('Erro', 'Não foi possível copiar o QR Code.', 'error');
        });
      });
    }

    // Leitura por imagem
    document.getElementById('qr-input').addEventListener('change', function (e) {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function () {
        const img = new Image();
        img.src = reader.result;
        img.onload = () => {
          const qr = new Html5Qrcode("qr-reader");
          qr.scanFile(file, true)
            .then(result => {
              document.getElementById('beep').play();
              Swal.fire('QR Code detectado!', `<b>${result}</b>`, 'success');
            })
            .catch(() => {
              Swal.fire('Erro', 'QR Code não encontrado.', 'error');
            });
        };
      };
      reader.readAsDataURL(file);
    });

    // Leitura por câmera
    function iniciarCamera() {
      const html5QrCode = new Html5Qrcode("reader");
      const config = { fps: 10, qrbox: 250 };

      Html5Qrcode.getCameras().then(cameras => {
        if (cameras && cameras.length) {
          html5QrCode.start(
            { facingMode: "environment" },
            config,
            qrCodeMessage => {
              document.getElementById('beep').play();
              Swal.fire('Código detectado', `<b>${qrCodeMessage}</b>`, 'success');
              html5QrCode.stop();
              document.getElementById("reader").innerHTML = "";
            },
            error => { console.log("Erro contínuo: ", error); }
          );
        } else {
          Swal.fire('Erro', 'Nenhuma câmera encontrada.', 'error');
        }
      }).catch(err => {
        Swal.fire('Erro', 'Não foi possível acessar a câmera.', 'error');
      });
    }
  </script>
</body>
</html>