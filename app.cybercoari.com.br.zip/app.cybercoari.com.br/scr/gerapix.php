<!DOCTYPE html>
<html lang="pt-br">
<head>
  <?php 
  $title = "Gerador de PIX";
  include __DIR__ . "/../includes/header.php"; 
  ?>

  <!-- Biblioteca QRCode.js -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
</head>
<body class="bg-dark text-light">

  <div class="container py-5">
    <h2 class="text-center mb-4">
      <i class="bi bi-qr-code"></i> Gerador de QR Code PIX
    </h2>

    <!-- Formulário -->
    <div class="card shadow-lg p-4 mx-auto" style="max-width: 500px;">
      <div class="input-group mb-3">
        <span class="input-group-text"><i class="bi bi-key-fill"></i></span>
        <input type="text" id="chave" class="form-control" placeholder="Chave PIX (CPF, telefone, e-mail ou chave aleatória)" required />
      </div>

      <div class="input-group mb-3">
        <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
        <input type="text" id="nome" class="form-control" placeholder="Nome do recebedor" required />
      </div>

      <div class="input-group mb-3">
        <span class="input-group-text"><i class="bi bi-geo-alt-fill"></i></span>
        <input type="text" id="cidade" class="form-control" placeholder="Cidade do recebedor" required />
      </div>

      <div class="input-group mb-3">
        <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
        <input type="number" step="0.01" min="0" id="valor" class="form-control" placeholder="Valor (opcional)" />
      </div>

      <!-- Botão principal -->
      <button onclick="gerarPIX()" id="gerarBtn" class="btn btn-primary w-100 mb-3">
        <i class="bi bi-qr-code"></i> Gerar QR Code
      </button>

      <!-- QR Code + dados -->
      <div id="qrcode" class="d-none text-center my-3"></div>
      <div class="dados d-none" id="dados"></div>

      <!-- Botão de voltar -->
      <a href="/painel.php" class="btn btn-success w-100 mt-3">
        <i class="bi bi-speedometer2"></i> Voltar ao Painel
      </a>
    </div>
  </div>

  <!-- Sons -->
  <audio id="somSucesso"><source src="https://cybercoari.com.br/cyber/audio/sucesso.mp3" type="audio/mpeg"></audio>
  <audio id="somErro"><source src="https://cybercoari.com.br/cyber/audio/erro.mp3" type="audio/mpeg"></audio>
  <audio id="somCopiado"><source src="https://cybercoari.com.br/cyber/audio/copiado.mp3" type="audio/mpeg"></audio>

  <?php include __DIR__ . "/../includes/footer.php"; ?>

  <script>
    const chaveInput = document.getElementById('chave');
    const nomeInput = document.getElementById('nome');
    const cidadeInput = document.getElementById('cidade');
    const valorInput = document.getElementById('valor');
    const gerarBtn = document.getElementById('gerarBtn');
    const qrcodeDiv = document.getElementById('qrcode');
    const dadosDiv = document.getElementById('dados');
    const somSucesso = document.getElementById('somSucesso');
    const somErro = document.getElementById('somErro');
    const somCopiado = document.getElementById('somCopiado');

    // --- VALIDAR CHAVE PIX ---
    function chavePIXValida(chave) {
      chave = chave.trim();

      // CPF (11 dígitos)
      const cpf = /^[0-9]{11}$/;
      // CNPJ (14 dígitos)
      const cnpj = /^[0-9]{14}$/;
      // E-mail
      const email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      // Telefone (+55DDDNÚMERO ou apenas DDDNÚMERO)
      const telefone = /^(\+55)?\d{10,11}$/;
      // UUID (chave aleatória)
      const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

      return cpf.test(chave) || cnpj.test(chave) || email.test(chave) || telefone.test(chave) || uuid.test(chave);
    }

    async function gerarPIX() {
      const chave = chaveInput.value.trim().replace(/\s/g, '');
      const nome = nomeInput.value.trim().replace(/\s+/g, ' ').toUpperCase();
      const cidade = cidadeInput.value.trim().replace(/\s+/g, ' ').toUpperCase();
      const valor = parseFloat(valorInput.value) || 0;

      if (!chave || !nome || !cidade) {
        mostrarErro("Preencha todos os campos obrigatórios.");
        return;
      }

      if (!chavePIXValida(chave)) {
        mostrarErro("A chave PIX informada não é válida.");
        return;
      }

      try {
        gerarBtn.innerHTML = '<i class="bi bi-hourglass"></i> Gerando...';
        gerarBtn.disabled = true;

        qrcodeDiv.innerHTML = "";
        qrcodeDiv.classList.add('d-none');
        dadosDiv.classList.add('d-none');

        const payload = geraPayloadPIX(chave, nome, cidade, valor);

        // Gera QR Code
        new QRCode(qrcodeDiv, {
          text: payload,
          width: 256,
          height: 256,
          colorDark: "#000000",
          colorLight: "#ffffff",
          correctLevel: QRCode.CorrectLevel.H
        });

        qrcodeDiv.classList.remove('d-none');
        try { await somSucesso.play(); } catch(e) {}

        dadosDiv.innerHTML = `
          <textarea id="codigoPix" readonly class="form-control my-2">${payload}</textarea>
          <button onclick="copiarCodigo()" class="btn btn-outline-light w-100 mt-2">
            <i class="bi bi-clipboard"></i> Copiar Código PIX
          </button>
          <button onclick="compartilharWhatsapp()" class="btn btn-success w-100 mt-2">
            <i class="bi bi-whatsapp"></i> Compartilhar via WhatsApp
          </button>
          <button onclick="baixarQR()" class="btn btn-warning w-100 mt-2">
            <i class="bi bi-download"></i> Baixar QR Code
          </button>
        `;
        dadosDiv.classList.remove('d-none');

      } catch (err) {
        console.error(err);
        mostrarErro("Erro ao gerar QR Code.");
      } finally {
        gerarBtn.innerHTML = '<i class="bi bi-qr-code"></i> Gerar QR Code';
        gerarBtn.disabled = false;
      }
    }

    function mostrarErro(msg) {
      try { somErro.play(); } catch(e) {}
      Swal.fire({ icon: "error", title: "Erro", text: msg });
    }

    function geraPayloadPIX(chave, nome, cidade, valor) {
      function add(t, v) {
        v = String(v);
        return t + v.length.toString().padStart(2, '0') + v;
      }
      const gui = add('00', 'BR.GOV.BCB.PIX');
      const chavePix = add('01', chave);
      const merchantAccount = add('26', gui + chavePix);
      const merchantCategoryCode = '52040000';
      const transactionCurrency = '5303986';
      const txValue = valor > 0 ? add('54', valor.toFixed(2)) : '';
      const countryCode = '5802BR';
      const merchantName = add('59', nome.substring(0, 25));
      const merchantCity = add('60', cidade.substring(0, 15));
      const txid = add('05', '***');
      const additionalDataField = add('62', txid);

      let payloadSemCRC = '000201' + merchantAccount + merchantCategoryCode +
        transactionCurrency + txValue + countryCode + merchantName +
        merchantCity + additionalDataField;
      payloadSemCRC += '6304';
      return payloadSemCRC + geraCRC16(payloadSemCRC);
    }

    function geraCRC16(str) {
      let crc = 0xFFFF;
      for (let i = 0; i < str.length; i++) {
        crc ^= str.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
          if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
          else crc <<= 1;
          crc &= 0xFFFF;
        }
      }
      return crc.toString(16).toUpperCase().padStart(4, '0');
    }

    async function copiarCodigo() {
      try {
        const codigo = document.getElementById("codigoPix");
        await navigator.clipboard.writeText(codigo.value);
        try { await somCopiado.play(); } catch(e) {}
        Swal.fire({ icon: "success", title: "Copiado!", timer: 1500, showConfirmButton: false });
      } catch {
        mostrarErro("Não foi possível copiar.");
      }
    }

    function compartilharWhatsapp() {
      const codigoPIX = document.getElementById('codigoPix').value;
      const msg = `PIX para pagamento:\n\n${codigoPIX}`;
      window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
    }

    function baixarQR() {
      const canvas = qrcodeDiv.querySelector("canvas");
      if (!canvas) {
        Swal.fire("Aviso", "Este QR Code não está em <canvas>, não é possível baixar em PNG.", "info");
        return;
      }
      const link = document.createElement("a");
      link.href = canvas.toDataURL("image/png");
      link.download = "qrcode-pix.png";
      link.click();
    }
  </script>
</body>
</html>