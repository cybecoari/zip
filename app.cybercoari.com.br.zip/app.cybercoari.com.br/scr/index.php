<?php
session_start();

// 🔒 Verificação de login
if (!isset($_SESSION['usuario_id'])) {
    header("Location: /login.php");
    exit();
}

// Tema do usuário
$tema = $_SESSION['tema'] ?? 'claro';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Cybercoari - Painel</title>
 <?php include __DIR__ . "/../includes/cdn.php" ?>
 <?php include __DIR__ . "/../includes/header.php" ?>
  <style>
    body.dark-mode {
      background-color: #121212;
      color: #f1f1f1;
    }
  </style>
</head>
<body class="container py-4 <?= $tema === 'escuro' ? 'dark-mode bg-dark text-white' : 'bg-light' ?>">

  <h2 class="text-center mb-4"><i class="bi bi-grid"></i> Painel de Atalhos</h2>

  <!-- Menu -->
  <div class="d-grid gap-2">
    <a href="/scr/gerapix.php" class="btn btn-outline-success w-100">
      <i class="bi bi-image me-2"></i> Gera QR Pix
    </a>

    <a href="/scr/gerasenha.php" class="btn btn-outline-primary w-100">
      <i class="bi bi-files me-2"></i> Gera Senha
    </a>

    <a href="/scr/dias.php" class="btn btn-outline-info w-100">
      <i class="bi bi-calendar-check me-2"></i> Contador de Dias
    </a>

    <a href="/scr/dominio.php" class="btn btn-outline-warning w-100">
      <i class="bi bi-diagram-3 me-2"></i> Domínio
    </a>

    <a href="/scr/host.php" class="btn btn-outline-secondary w-100">
      <i class="bi bi-hdd-network me-2"></i> Host
    </a>

    <a href="/scr/icones.php" class="btn btn-outline-dark w-100">
      <i class="bi bi-stars me-2"></i> Ícones
    </a>

    <a href="/scr/imc.php" class="btn btn-outline-success w-100">
      <i class="bi bi-calculator me-2"></i> Calculadora IMC
    </a>

    <a href="/scr/ipv4.php" class="btn btn-outline-primary w-100">
      <i class="bi bi-ethernet me-2"></i> IPV4/IPV6
    </a>

    <a href="/scr/whatsapp.php" class="btn btn-outline-success w-100">
      <i class="bi bi-whatsapp me-2"></i> Whatsapp
    </a>

    <a href="/logout.php" 
       class="btn btn-outline-danger w-100" 
       onclick="confirmLogout(); return false;">
      <i class="bi bi-box-arrow-right me-2"></i> Sair
    </a>
  </div>

  <!-- Sons -->
  <audio id="som-clique" src="https://cybercoari.com.br/cyber/audio/click.mp3" preload="auto"></audio>
  <audio id="som-sucesso" src="https://cybercoari.com.br/cyber/audio/sucesso.mp3" preload="auto"></audio>
  
  <?php include __DIR__ . "/../includes/footer.php" ?>
  <script>
    // 🔊 Som em cada clique
    document.querySelectorAll("a.btn").forEach(btn => {
      btn.addEventListener("click", () => {
        document.getElementById("som-clique").play();
      });
    });

    // 🚪 Logout com alerta
    function confirmLogout() {
      document.getElementById("som-clique").play();
      Swal.fire({
        title: "Deseja realmente sair?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Sim, sair",
        cancelButtonText: "Cancelar"
      }).then((result) => {
        if (result.isConfirmed) {
          document.getElementById("som-sucesso").play();
          window.location.href = "/logout.php";
        }
      });
    }
  </script>

</body>
</html>