<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ferramentas de QR Code</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <!-- QRCodeJS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  <!-- Html5 QR Code -->
  <script src="https://unpkg.com/html5-qrcode"></script>

  <!-- Seus estilos personalizados -->
  <style>
    body {
      background: #1a1a1a;
      color: #fff;
    }
    .form-control, .btn {
      background-color: #16213e;
      color: #fff;
      border: 1px solid #fff;
    }
    .form-control:focus {
      background-color: #16213e;
      color: #fff;
      border-color: #86b7fe;
      box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    }
    .qr-container canvas {
      max-width: 100%;
      margin-top: 15px;
      background: white;
      padding: 10px;
      border-radius: 5px;
    }
    #reader {
      width: 100%;
      max-width: 300px;
      margin: auto;
    }
    #qr-reader {
      min-height: 100px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255,255,255,0.1);
      border-radius: 5px;
      margin-bottom: 15px;
    }

    #hamburger {
      font-size: 1.8rem;
      cursor: pointer;
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1051;
      color: #fff;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: -250px;
      width: 250px;
      height: 100%;
      background-color: #1f1f1f;
      padding: 60px 15px 15px;
      transition: left 0.3s;
      z-index: 1050;
      box-shadow: 2px 0 5px rgba(0,0,0,0.5);
    }

    .sidebar.show {
      left: 0;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li {
      margin-bottom: 15px;
    }

    .sidebar ul li a {
      color: #fff;
      text-decoration: none;
      display: flex;
      align-items: center;
      font-size: 1rem;
      padding: 8px 12px;
      border-radius: 5px;
      transition: all 0.3s;
    }

    .sidebar ul li a:hover {
      background-color: rgba(255,255,255,0.1);
    }

    .sidebar ul li a i {
      margin-right: 10px;
    }

    .overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.5);
      z-index: 1049;
      backdrop-filter: blur(3px);
    }

    .overlay.show {
      display: block;
    }
    
    .card {
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 20px;
    }
    
    .btn-success {
      background-color: #198754 !important;
    }
    
    .btn-primary {
      background-color: #0d6efd !important;
    }
  </style>
</head>
<body class="container py-4">

  <!-- Botão hamburguer -->
  <i id="hamburger" class="bi bi-list"></i>

  <!-- Menu lateral -->
  <div class="sidebar" id="sidebar">
    <ul>
      <li><a href="/painel.php"><i class="bi bi-house"></i> Painel</a></li>
      <li><a href="/api/pix.php"><i class="bi bi-qr-code"></i> PIX</a></li>
      <li><a href="/api/qrcode.php"><i class="bi bi-tools"></i> Ferramentas</a></li>
      <li><a href="/api/leitorqr.php"><i class="bi bi-qr-code-scan"></i> Leitor QR</a></li>
      <li><a href="/api/leitorbarra.php"><i class="bi bi-upc-scan"></i> Leitor Cód Barras</a></li>
      <li><a href="/sair.php"><i class="bi bi-box-arrow-right"></i> Sair</a></li>
    </ul>
  </div>
  <div class="overlay" id="overlay"></div>

  <h2 class="text-center mb-4">Ferramentas de QR Code</h2>

  <div class="row g-4">
    <!-- GERADOR -->
    <div class="col-md-6">
      <div class="card">
        <h5 class="mb-3"><i class="bi bi-qr-code"></i> Gerar QR Code</h5>
        <input type="text" id="texto" class="form-control mb-3" placeholder="Digite um link ou texto...">
        <div id="qrcode" class="qr-container text-center mt-3"></div>
        <div class="text-center mt-3">
          <button class="btn btn-success me-2" id="btnDownload" style="display:none;" onclick="baixarQRCode()">
            <i class="bi bi-download"></i> Baixar QR Code
          </button>
          <button class="btn btn-outline-light" id="btnCopiar" style="display:none;" onclick="copiarQRCode()">
            <i class="bi bi-clipboard"></i> Copiar QR Code
          </button>
        </div>
      </div>
    </div>

    <!-- LEITOR -->
    <div class="col-md-6">
      <div class="card">
        <h5 class="mb-3"><i class="bi bi-qr-code-scan"></i> Ler QR Code</h5>
        <div class="mb-3">
          <label for="qr-input" class="form-label">Selecione uma imagem:</label>
          <input type="file" accept="image/*" id="qr-input" class="form-control">
        </div>
        <div id="qr-reader">
          <p class="text-muted">Nenhuma imagem selecionada</p>
        </div>
        <hr>
        <button class="btn btn-primary w-100" onclick="iniciarCamera()">
          <i class="bi bi-camera-video"></i> Ler com câmera
        </button>
        <div id="reader" class="mt-3"></div>
      </div>
    </div>
  </div>

  <audio id="beep" src="/assets/sounds/beep.mp3" preload="auto"></audio>

  <script>
    // Menu hamburguer toggle
    const hamburger = document.getElementById('hamburger');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    hamburger.addEventListener('click', () => {
      sidebar.classList.toggle('show');
      overlay.classList.toggle('show');
    });

    overlay.addEventListener('click', () => {
      sidebar.classList.remove('show');
      overlay.classList.remove('show');
    });

    // Gerador QR Code
    const input = document.getElementById('texto');
    const qrcodeDiv = document.getElementById("qrcode");
    const btnDownload = document.getElementById("btnDownload");
    const btnCopiar = document.getElementById("btnCopiar");
    let qrcode;

    input.addEventListener("input", () => {
      const texto = input.value.trim();
      qrcodeDiv.innerHTML = "";
      btnDownload.style.display = "none";
      btnCopiar.style.display = "none";
      
      if (texto !== "") {
        if (!qrcode) {
          qrcode = new QRCode(qrcodeDiv, {
            text: texto,
            width: 200,
            height: 200,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
          });
        } else {
          qrcode.clear();
          qrcode.makeCode(texto);
        }
        
        setTimeout(() => {
          btnDownload.style.display = "inline-block";
          btnCopiar.style.display = "inline-block";
        }, 300);
      }
    });

    function baixarQRCode() {
      const canvas = document.querySelector("#qrcode canvas");
      if (canvas) {
        const url = canvas.toDataURL("image/png");
        const link = document.createElement('a');
        link.href = url;
        link.download = 'qrcode_' + Date.now() + '.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }

    async function copiarQRCode() {
      try {
        const canvas = document.querySelector("#qrcode canvas");
        if (!canvas) return;
        
        const blob = await new Promise(resolve => canvas.toBlob(resolve));
        await navigator.clipboard.write([
          new ClipboardItem({ "image/png": blob })
        ]);
        
        Swal.fire({
          icon: 'success',
          title: 'Copiado!',
          text: 'QR Code copiado para a área de transferência.',
          timer: 2000,
          showConfirmButton: false
        });
      } catch (err) {
        console.error('Erro ao copiar:', err);
        Swal.fire({
          icon: 'error',
          title: 'Erro',
          text: 'Não foi possível copiar o QR Code.',
          timer: 2000,
          showConfirmButton: false
        });
      }
    }

    // Leitura por imagem
    document.getElementById('qr-input').addEventListener('change', function (e) {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function () {
        const img = new Image();
        img.src = reader.result;
        img.onload = () => {
          const qrReaderDiv = document.getElementById('qr-reader');
          qrReaderDiv.innerHTML = '<p class="text-light">Processando imagem...</p>';
          
          const qr = new Html5Qrcode("qr-reader");
          qr.scanFile(file, true)
            .then(result => {
              document.getElementById('beep').play();
              qrReaderDiv.innerHTML = `<p class="text-success">QR Code detectado!</p>`;
              Swal.fire({
                title: 'QR Code detectado!',
                html: `<p class="text-break">${result}</p>`,
                icon: 'success',
                confirmButtonText: 'OK'
              });
            })
            .catch(() => {
              qrReaderDiv.innerHTML = '<p class="text-danger">QR Code não encontrado.</p>';
              Swal.fire({
                title: 'Erro',
                text: 'QR Code não encontrado na imagem.',
                icon: 'error',
                confirmButtonText: 'OK'
              });
            });
        };
      };
      reader.readAsDataURL(file);
    });

    // Leitura por câmera
    function iniciarCamera() {
      const html5QrCode = new Html5Qrcode("reader");
      const config = { fps: 10, qrbox: 250 };
      
      // Verifica se já está escaneando
      if (html5QrCode.isScanning) {
        html5QrCode.stop().then(() => {
          document.getElementById("reader").innerHTML = "";
        });
        return;
      }

      Html5Qrcode.getCameras().then(cameras => {
        if (cameras && cameras.length) {
          html5QrCode.start(
            cameras[0].id,  // Usa a câmera traseira se disponível
            config,
            qrCodeMessage => {
              document.getElementById('beep').play();
              Swal.fire({
                title: 'Código detectado',
                html: `<p class="text-break">${qrCodeMessage}</p>`,
                icon: 'success',
                confirmButtonText: 'OK'
              }).then(() => {
                html5QrCode.stop();
                document.getElementById("reader").innerHTML = "";
              });
            },
            error => { 
              console.log("Erro contínuo: ", error); 
            }
          ).catch(err => {
            console.error("Erro ao iniciar scanner:", err);
            Swal.fire({
              title: 'Erro',
              text: 'Não foi possível iniciar a câmera.',
              icon: 'error',
              confirmButtonText: 'OK'
            });
          });
        } else {
          Swal.fire({
            title: 'Erro',
            text: 'Nenhuma câmera encontrada.',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        }
      }).catch(err => {
        console.error("Erro ao acessar câmeras:", err);
        Swal.fire({
          title: 'Erro',
          text: 'Permissão de câmera negada ou dispositivo sem câmera.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      });
    }
  </script>
  
  <!-- Bootstrap JS Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>