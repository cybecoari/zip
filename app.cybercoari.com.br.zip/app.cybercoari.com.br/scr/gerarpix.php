<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <title>Gerador de PIX</title>
  <?php
   include __DIR__ . "/../includes/header.php";
?>

  <!-- Bibliotecas externas com fallbacks -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    // Fallback para SweetAlert2
    if (typeof Swal === 'undefined') {
      document.write('<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"><\/script>');
    }
  </script>
  
  <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
  <script>
    // Fallback para QRCode
    if (typeof QRCode === 'undefined') {
      document.write('<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"><\/script>');
    }
  </script>
  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
  <script>
    // Verificação simples se os ícones carregaram
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(function() {
        const icons = document.querySelector('.bi-qr-code');
        if (!icons || getComputedStyle(icons).fontFamily !== 'BootstrapIcons') {
          console.warn('Ícones do Bootstrap não carregaram, usando fallback');
          // Poderíamos carregar um fallback local aqui
        }
      }, 1000);
    });
  </script>

  <!-- Estilo personalizado -->
  <!--<style>
    :root {
      --primary-bg: #16213e;
      --input-bg: #2d3748;
      --primary-color: #007bff;
      --success-color: #28a745;
      --whatsapp-color: #25D366;
      --text-color: #fff;
      --error-color: #dc3545;
    }
    
    body {
      font-family: Arial, sans-serif;
      background: var(--primary-bg);
      color: var(--text-color);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      padding: 20px;
      min-height: 100vh;
      margin: 0;
    }
    
    h2 {
      margin-bottom: 20px;
      text-align: center;
    }
    
    .container {
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 100%;
      max-width: 500px;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .input-group {
      position: relative;
      width: 100%;
      margin: 12px 0;
    }
    
    .input-group i {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: #aaa;
      z-index: 2;
    }
    
    input, button, textarea {
      padding: 12px;
      width: 100%;
      font-size: 16px;
      border-radius: 6px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-sizing: border-box;
      transition: all 0.3s ease;
    }
    
    input, textarea {
      background-color: var(--input-bg);
      color: var(--text-color);
    }
    
    input:focus, textarea:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25);
    }
    
    input.with-icon {
      padding-left: 40px;
    }
    
    button {
      background: var(--primary-color);
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      font-weight: 500;
      border: none;
    }
    
    button:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }
    
    button:active {
      transform: translateY(0);
    }
    
    button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none;
    }
    
    #copiar {
      background: var(--success-color);
    }
    
    #qrcode {
      margin: 20px 0;
      display: flex;
      justify-content: center;
      padding: 15px;
      background: white;
      border-radius: 8px;
    }
    
    .dados {
      margin-top: 20px;
      width: 100%;
      text-align: left;
    }
    
    .dados p {
      margin: 10px 0;
      padding: 8px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 5px;
    }
    
    textarea {
      height: 90px;
      resize: none;
      margin: 10px 0;
    }
    
    .hidden {
      display: none;
    }
    
    .pulse {
      animation: pulse 1.5s infinite;
    }
    
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.6; }
      100% { opacity: 1; }
    }
    
    @media (max-width: 600px) {
      body {
        padding: 15px;
      }
      
      .container {
        padding: 20px 15px;
      }
      
      input, button, textarea {
        font-size: 15px;
        padding: 10px;
      }
      
      h2 {
        font-size: 20px;
      }
      
      .input-group i {
        left: 10px;
      }
      
      input.with-icon {
        padding-left: 35px;
      }
    }
  </style>-->
</head>
<body>
 
  <h2><i class="bi bi-qr-code"></i> Gerador de QR Code PIX</h2>

  <!-- Formulário de entrada -->
  <div class="container">
    <div class="input-group">
      <i class="bi bi-key-fill"></i>
      <input type="text" id="chave" class="with-icon" placeholder="Chave PIX (CPF, telefone, e-mail ou chave aleatória)" required />
    </div>
    
    <div class="input-group">
      <i class="bi bi-person-fill"></i>
      <input type="text" id="nome" class="with-icon" placeholder="Nome do recebedor" required />
    </div>
    
    <div class="input-group">
      <i class="bi bi-geo-alt-fill"></i>
      <input type="text" id="cidade" class="with-icon" placeholder="Cidade do recebedor" required />
    </div>
    
    <div class="input-group">
      <i class="bi bi-currency-dollar"></i>
      <input type="number" step="0.01" min="0" id="valor" class="with-icon" placeholder="Valor (opcional)" />
    </div>
    
    <button onclick="gerarPIX()" id="gerarBtn">
      <i class="bi bi-qr-code"></i> Gerar QR Code
    </button>

    <!-- Área do QR Code e dados -->
    <div id="qrcode" class="hidden"></div>
    <div class="dados hidden" id="dados"></div>

    <!-- Botão de voltar -->
    <button onclick="window.location.href='/painel.php'" style="margin-top: 20px; background: green;">
      <i class="bi bi-speedometer2"></i> Voltar ao Painel
    </button>
  </div>

  <!-- Sons com fallback local -->
  <audio id="somSucesso">
  <source src="https://cybercoari.com.br/cyber/audio/sucesso.mp3" type="audio/mpeg">
  </audio>
  <audio id="somErro">
  <source src="https://cybercoari.com.br/cyber/audio/erro.mp3" type="audio/mpeg">
  </audio>
  <audio id="somCopiado">
  <source src="https://cybercoari.com.br/cyber/audio/copiado.mp3" type="audio/mpeg">
  </audio>
  
  <?php
   include __DIR__ . "/../includes/footer.php";
?>

  <!-- Script principal -->
  <script>
    // Elementos DOM
    const chaveInput = document.getElementById('chave');
    const nomeInput = document.getElementById('nome');
    const cidadeInput = document.getElementById('cidade');
    const valorInput = document.getElementById('valor');
    const gerarBtn = document.getElementById('gerarBtn');
    const qrcodeDiv = document.getElementById('qrcode');
    const dadosDiv = document.getElementById('dados');
    const somSucesso = document.getElementById('somSucesso');
    const somErro = document.getElementById('somErro');
    const somCopiado = document.getElementById('somCopiado');
    
    // Validação em tempo real
    chaveInput.addEventListener('blur', validarChavePIX);
    nomeInput.addEventListener('input', formatarNome);
    
    function validarChavePIX() {
      const chave = chaveInput.value.trim().replace(/\s/g, '');
      
      // Verificar se é um CPF (apenas números, 11 dígitos)
      if (/^\d{11}$/.test(chave)) {
        return true;
      }
      
      // Verificar se é um telefone (com DDD)
      if (/^(\+55|55|0)?([1-9]{2})?9[0-9]{8}$/.test(chave)) {
        return true;
      }
      
      // Verificar se é um email válido
      if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(chave)) {
        return true;
      }
      
      // Verificar se é uma chave aleatória (UUID)
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(chave)) {
        return true;
      }
      
      // Se não for nenhum dos formatos acima, mostrar aviso
      Swal.fire({
        icon: 'warning',
        title: 'Formato de chave',
        text: 'A chave informada não parece estar em um formato comum de PIX (CPF, telefone, e-mail ou chave aleatória). Verifique se está correta.',
        confirmButtonText: 'Entendi'
      });
      
      return true; // Permite continuar mesmo com o aviso
    }
    
    function formatarNome() {
      // Manter apenas letras, espaços e acentos
      nomeInput.value = nomeInput.value.replace(/[^a-zA-ZÀ-ÿ\s]/g, '');
    }
    
    // Função principal assíncrona
    async function gerarPIX() {
      const chave = chaveInput.value.trim().replace(/\s/g, '');
      const nome = nomeInput.value.trim().replace(/\s+/g, ' ').toUpperCase();
      const cidade = cidadeInput.value.trim().replace(/\s+/g, ' ').toUpperCase();
      const valor = parseFloat(valorInput.value) || 0;
      
      // Validação dos campos
      if (!chave) {
        mostrarErro('Por favor, informe a chave PIX.');
        return;
      }
      
      if (!nome) {
        mostrarErro('Por favor, informe o nome do recebedor.');
        return;
      }
      
      if (!cidade) {
        mostrarErro('Por favor, informe a cidade do recebedor.');
        return;
      }
      
      if (valor < 0) {
        mostrarErro('O valor não pode ser negativo.');
        return;
      }

      try {
        // Mostrar loading no botão
        gerarBtn.innerHTML = '<i class="bi bi-hourglass"></i> Gerando...';
        gerarBtn.disabled = true;
        gerarBtn.classList.add('pulse');

        // Limpar QR Code anterior
        qrcodeDiv.classList.add('hidden');
        dadosDiv.classList.add('hidden');
        while (qrcodeDiv.firstChild) {
          qrcodeDiv.removeChild(qrcodeDiv.firstChild);
        }

        // Gerar payload
        const payload = geraPayloadPIX(chave, nome, cidade, valor);

        // Gerar QR Code
        const canvas = await QRCode.toCanvas(payload, { 
          width: 256,
          errorCorrectionLevel: 'H',
          margin: 2
        });

        canvas.setAttribute('alt', 'QR Code para pagamento PIX');
        qrcodeDiv.appendChild(canvas);
        qrcodeDiv.classList.remove('hidden');
        
        // Reproduzir som de sucesso se disponível
        try {
          await somSucesso.play();
        } catch (audioError) {
          console.warn('Não foi possível reproduzir o áudio', audioError);
        }

        // Exibir dados
        dadosDiv.innerHTML = `
          <p><strong><i class="bi bi-key-fill"></i> Chave PIX:</strong> ${chave}</p>
          <p><strong><i class="bi bi-currency-dollar"></i> Valor:</strong> R$ ${valor.toFixed(2)}</p>
          <p><strong><i class="bi bi-person-fill"></i> Nome do recebedor:</strong> ${nome}</p>
          <p><strong><i class="bi bi-geo-alt-fill"></i> Cidade do recebedor:</strong> ${cidade}</p>
          <textarea id="codigoPix" readonly>${payload}</textarea>
          <button id="copiar" onclick="copiarCodigo()"><i class="bi bi-clipboard"></i> Copiar Código PIX</button>
          <button onclick="compartilharWhatsapp()" style="background: var(--whatsapp-color); margin-top: 10px;">
            <i class="bi bi-whatsapp"></i> Compartilhar via WhatsApp
          </button>
        `;
        
        dadosDiv.classList.remove('hidden');

      } catch (err) {
        console.error("Erro ao gerar QR Code:", err);
        mostrarErro('Não foi possível gerar o QR Code. Verifique os dados e tente novamente.');
      } finally {
        // Restaurar botão
        gerarBtn.innerHTML = '<i class="bi bi-qr-code"></i> Gerar QR Code';
        gerarBtn.disabled = false;
        gerarBtn.classList.remove('pulse');
      }
    }
    
    function mostrarErro(mensagem) {
      // Tentar reproduzir som de erro
      try {
        somErro.play();
      } catch (audioError) {
        console.warn('Não foi possível reproduzir o áudio de erro', audioError);
      }
      
      Swal.fire({
        icon: 'error',
        title: 'Erro',
        text: mensagem
      });
    }

    // Função que monta o payload do PIX com base no padrão EMV
    function geraPayloadPIX(chave, nome, cidade, valor) {
      function add(t, v) {
        v = String(v);
        return t + v.length.toString().padStart(2, '0') + v;
      }

      const gui = add('00', 'BR.GOV.BCB.PIX');
      const chavePix = add('01', chave);
      const merchantAccount = add('26', gui + chavePix);
      const merchantCategoryCode = '52040000';
      const transactionCurrency = '5303986';
      const txValue = valor > 0 ? add('54', valor.toFixed(2)) : '';
      const countryCode = '5802BR';
      const merchantName = add('59', nome.substring(0, 25)); // Limitar a 25 caracteres
      const merchantCity = add('60', cidade.substring(0, 15)); // Limitar a 15 caracteres
      const txid = add('05', '***');
      const additionalDataField = add('62', txid);

      let payloadSemCRC = '000201' + merchantAccount + merchantCategoryCode + transactionCurrency + txValue + countryCode + merchantName + merchantCity + additionalDataField;
      payloadSemCRC += '6304';
      return payloadSemCRC + geraCRC16(payloadSemCRC);
    }

    // Cálculo do CRC16 para o código PIX
    function geraCRC16(str) {
      let crc = 0xFFFF;
      for (let i = 0; i < str.length; i++) {
        crc ^= str.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
          if (crc & 0x8000) {
            crc = (crc << 1) ^ 0x1021;
          } else {
            crc <<= 1;
          }
          crc &= 0xFFFF;
        }
      }
      return crc.toString(16).toUpperCase().padStart(4, '0');
    }

    // Função para copiar o código PIX para a área de transferência
    async function copiarCodigo() {
      try {
        const codigo = document.getElementById("codigoPix");
        codigo.select();
        codigo.setSelectionRange(0, 99999); // Para dispositivos móveis
        
        // Usando a API moderna de clipboard
        if (navigator.clipboard) {
          await navigator.clipboard.writeText(codigo.value);
        } else {
          // Fallback para método antigo
          document.execCommand("copy");
        }
        
        // Reproduzir som se disponível
        try {
          await somCopiado.play();
        } catch (audioError) {
          console.warn('Não foi possível reproduzir o áudio', audioError);
        }
        
        await Swal.fire({
          icon: 'success',
          title: 'Copiado!',
          text: 'Código PIX copiado com sucesso.',
          timer: 1500,
          showConfirmButton: false
        });
      } catch (err) {
        console.error("Erro ao copiar:", err);
        Swal.fire({
          icon: 'error',
          title: 'Erro',
          text: 'Não foi possível copiar o código.'
        });
      }
    }

    // Compartilhamento via WhatsApp
    function compartilharWhatsapp() {
      try {
        const chave = chaveInput.value.trim();
        const nome = nomeInput.value.trim();
        const cidade = cidadeInput.value.trim();
        const valor = parseFloat(valorInput.value) || 0;
        const codigoPIX = document.getElementById('codigoPix').value;

        const msg = `💠 PIX para pagamento:\n\n🔑 Chave: ${chave}\n👤 Nome: ${nome}\n🏙︄1�7 Cidade: ${cidade}\n💲 Valor: R$ ${valor.toFixed(2)}\n\n📋 Copie e cole no app do banco:\n${codigoPIX}`;

        const url = `https://wa.me/?text=${encodeURIComponent(msg)}`;
        window.open(url, '_blank');
      } catch (err) {
        console.error("Erro ao compartilhar:", err);
        Swal.fire({
          icon: 'error',
          title: 'Erro',
          text: 'Não foi possível compartilhar via WhatsApp.'
        });
      }
    }
  </script>

</body>
</html>