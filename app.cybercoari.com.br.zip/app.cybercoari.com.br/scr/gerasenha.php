<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Gerador de Senhas Seguras</title>
    <?php include __DIR__ . "/../includes/cdn.php" ?>
    <?php include __DIR__ . "/../includes/header.php" ?>
    <style>
    /* Fonte padrão para todo o sistema */
body {
    font-family: 'Roboto', 'Poppins', sans-serif;
}

/* Se quiser títulos diferentes */
h1, h2, h3, h4, h5, h6 {
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
}

/* ================== MODO CLARO ================== */
body {
    background-color: #f8f9fa !important; /* fundo claro */
    color: #212529 !important;           /* texto escuro */
}

body .card,
body .password-display,
body .options,
body .list-group-item {
    background-color: #ffffff !important;
    color: #212529 !important;
    border-color: #dee2e6 !important;
}

body .btn-primary {
    background-color: #0d6efd !important;
    border-color: #0d6efd !important;
    color: #fff !important;
}

body .btn-success {
    background-color: #198754 !important;
    border-color: #198754 !important;
    color: #fff !important;
}

body .btn-outline-secondary {
    color: #212529 !important;
    border-color: #6c757d !important;
}
body .btn-outline-secondary:hover {
    background-color: #e9ecef !important;
}

/* ================== MODO ESCURO ================== */
body.dark {
    background-color: #121212 !important;
    color: #f1f1f1 !important;
}

body.dark .card,
body.dark .password-display,
body.dark .options,
body.dark .list-group-item {
    background-color: #1e1e1e !important;
    color: #f1f1f1 !important;
    border-color: #333 !important;
}

body.dark .btn-primary {
    background-color: #0d6efd !important;
    border-color: #0d6efd !important;
    color: #fff !important;
}

body.dark .btn-success {
    background-color: #198754 !important;
    border-color: #198754 !important;
    color: #fff !important;
}

body.dark .btn-outline-secondary {
    color: #f1f1f1 !important;
    border-color: #555 !important;
}
body.dark .btn-outline-secondary:hover {
    background-color: #333 !important;
}
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="card shadow-lg mx-auto" style="max-width: 500px;">
            <div class="card-body">
                <h1 class="h4 text-center mb-4">🔐 Gerador de Senhas Seguras</h1>
                
                <!-- Senha Gerada -->
                <div class="password-display position-relative border rounded p-3 mb-3 bg-light">
                    <span id="passwordText" class="fw-bold d-block text-center">Sua senha aparecerá aqui</span>
                    <button class="btn btn-success btn-sm position-absolute top-0 end-0 m-2" id="copyBtn">
                        <i class="bi bi-clipboard"></i> Copiar
                    </button>
                </div>

                <!-- Opções -->
                <div class="options border rounded p-3 bg-white">
                    <div class="option-group mb-3">
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" id="uppercase" checked>
                            <span class="form-check-label">Letras maiúsculas (A-Z)</span>
                        </label>
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" id="lowercase" checked>
                            <span class="form-check-label">Letras minúsculas (a-z)</span>
                        </label>
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" id="numbers" checked>
                            <span class="form-check-label">Números (0-9)</span>
                        </label>
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" id="symbols">
                            <span class="form-check-label">Símbolos (!@#$%&*)</span>
                        </label>
                    </div>
                    
                    <div class="option-group mb-3">
                        <label for="length" class="form-label">
                            Comprimento da senha: <span id="lengthValue">12</span>
                        </label>
                        <input type="range" class="form-range" id="length" min="4" max="32" value="12">
                    </div>
                    
                    <!-- Força da Senha -->
                    <div class="strength-meter mb-2">
                        <div class="strength-bar" id="strengthBar" style="height: 8px; border-radius: 5px; width:0%;"></div>
                    </div>
                    <div class="strength-text small fw-bold text-center" id="strengthText">Força da senha: Média</div>
                </div>

                <!-- Botão Gerar -->
                <button class="btn btn-primary w-100 mt-3" id="generateBtn">
                    <i class="bi bi-shuffle"></i> Gerar Nova Senha
                </button>

                <!-- Histórico -->
                <div class="history mt-4">
                    <h3 class="h6">Histórico de Senhas</h3>
                    <ul class="history-list list-group" id="historyList"></ul>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . "/../includes/footer.php" ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const passwordText = document.getElementById('passwordText');
            const copyBtn = document.getElementById('copyBtn');
            const generateBtn = document.getElementById('generateBtn');
            const lengthSlider = document.getElementById('length');
            const lengthValue = document.getElementById('lengthValue');
            const uppercaseCheck = document.getElementById('uppercase');
            const lowercaseCheck = document.getElementById('lowercase');
            const numbersCheck = document.getElementById('numbers');
            const symbolsCheck = document.getElementById('symbols');
            const strengthBar = document.getElementById('strengthBar');
            const strengthText = document.getElementById('strengthText');
            const historyList = document.getElementById('historyList');
            
            let passwordHistory = [];
            
            // Atualizar comprimento
            lengthSlider.addEventListener('input', function() {
                lengthValue.textContent = this.value;
                generatePassword();
            });
            
            // Gerar senha quando mudar opções
            [uppercaseCheck, lowercaseCheck, numbersCheck, symbolsCheck].forEach(checkbox => {
                checkbox.addEventListener('change', generatePassword);
            });
            
            // Botão gerar
            generateBtn.addEventListener('click', generatePassword);
            
            // Botão copiar senha atual
            copyBtn.addEventListener('click', function() {
                const password = passwordText.textContent;
                if (password && password !== 'Sua senha aparecerá aqui') {
                    navigator.clipboard.writeText(password).then(() => {
                        copyBtn.innerHTML = '<i class="bi bi-check2"></i> Copiado!';
                        setTimeout(() => {
                            copyBtn.innerHTML = '<i class="bi bi-clipboard"></i> Copiar';
                        }, 2000);
                    });
                }
            });
            
            // Gerar senha inicial
            generatePassword();
            
            function generatePassword() {
                const length = parseInt(lengthSlider.value);
                const hasUpper = uppercaseCheck.checked;
                const hasLower = lowercaseCheck.checked;
                const hasNumbers = numbersCheck.checked;
                const hasSymbols = symbolsCheck.checked;
                
                if (!hasUpper && !hasLower && !hasNumbers && !hasSymbols) {
                    passwordText.textContent = 'Selecione pelo menos uma opção';
                    updateStrength(0);
                    return;
                }
                
                let charset = '';
                if (hasUpper) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                if (hasLower) charset += 'abcdefghijklmnopqrstuvwxyz';
                if (hasNumbers) charset += '0123456789';
                if (hasSymbols) charset += '!@#$%&*';
                
                let password = '';
                for (let i = 0; i < length; i++) {
                    const randomIndex = Math.floor(Math.random() * charset.length);
                    password += charset[randomIndex];
                }
                
                passwordText.textContent = password;
                addToHistory(password);
                updateStrength(calculatePasswordStrength(password, hasUpper, hasLower, hasNumbers, hasSymbols));
            }
            
            function calculatePasswordStrength(password, hasUpper, hasLower, hasNumbers, hasSymbols) {
                let strength = 0;
                if (password.length >= 8) strength++;
                if (password.length >= 12) strength++;
                if (password.length >= 16) strength++;
                
                let charTypes = 0;
                if (hasUpper) charTypes++;
                if (hasLower) charTypes++;
                if (hasNumbers) charTypes++;
                if (hasSymbols) charTypes++;
                
                strength += Math.min(charTypes - 1, 2);
                return Math.min(strength, 5);
            }
            
            function updateStrength(strength) {
                const strengthPercent = (strength / 5) * 100;
                strengthBar.style.width = strengthPercent + '%';
                
                if (strength <= 1) {
                    strengthBar.style.backgroundColor = '#ff4d4d';
                    strengthText.textContent = 'Força da senha: Muito Fraca';
                } else if (strength <= 2) {
                    strengthBar.style.backgroundColor = '#ff9933';
                    strengthText.textContent = 'Força da senha: Fraca';
                } else if (strength <= 3) {
                    strengthBar.style.backgroundColor = '#ffcc00';
                    strengthText.textContent = 'Força da senha: Média';
                } else if (strength <= 4) {
                    strengthBar.style.backgroundColor = '#99cc33';
                    strengthText.textContent = 'Força da senha: Forte';
                } else {
                    strengthBar.style.backgroundColor = '#33cc33';
                    strengthText.textContent = 'Força da senha: Muito Forte';
                }
            }
            
            function addToHistory(password) {
                passwordHistory.unshift(password);
                if (passwordHistory.length > 5) passwordHistory.pop();
                updateHistoryList();
            }
            
            function updateHistoryList() {
                historyList.innerHTML = '';
                
                passwordHistory.forEach((password) => {
                    const li = document.createElement('li');
                    li.className = 'list-group-item d-flex justify-content-between align-items-center';
                    
                    const span = document.createElement('span');
                    span.textContent = password;
                    
                    const copyBtn = document.createElement('button');
                    copyBtn.className = 'btn btn-outline-secondary btn-sm';
                    copyBtn.innerHTML = '<i class="bi bi-clipboard"></i> Copiar';
                    
                    copyBtn.addEventListener('click', function() {
                        navigator.clipboard.writeText(password);
                        copyBtn.innerHTML = '<i class="bi bi-check2"></i> Copiado!';
                        setTimeout(() => {
                            copyBtn.innerHTML = '<i class="bi bi-clipboard"></i> Copiar';
                        }, 2000);
                    });
                    
                    li.appendChild(span);
                    li.appendChild(copyBtn);
                    historyList.appendChild(li);
                });
            }
        });
    </script>
</body>
</html>