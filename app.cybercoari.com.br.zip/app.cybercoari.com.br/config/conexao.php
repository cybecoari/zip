<?php
// config/conexao.php

// Configurações do banco de dados - AJUSTE COM AS CREDENCIAIS DO SEU BANCO
$host = 'localhost:3306'; // Inclua a porta 3306
$dbname = 'cyber_app'; // Nome do banco que aparece no SQL
$username = 'cyber_app'; // Seu usuário do MySQL (ver no Plesk)
$password = '@cybercoari'; // Senha do banco (ver no Plesk)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Para desenvolvimento, mostre o erro
    die("Erro de conexão com o banco de dados: " . $e->getMessage());
}
?>