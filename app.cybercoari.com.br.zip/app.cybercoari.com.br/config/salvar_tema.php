const toggleBtn = document.getElementById('dark-mode-toggle');
const body = document.body;

toggleBtn.addEventListener('click', () => {
  body.classList.toggle('dark-mode');
  const isDark = body.classList.contains('dark-mode');

  // Troca ícone
  toggleBtn.innerHTML = isDark
    ? '<i class="bi bi-sun-fill"></i>'
    : '<i class="bi bi-moon-stars-fill"></i>';

  // Salva no banco via POST normal (FormData)
  const formData = new FormData();
  formData.append('tema', isDark ? 'escuro' : 'claro');

  fetch('/api/salvar_tema.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'ok') {
      console.log('Tema salvo:', data.tema);
    } else {
      console.error('Erro:', data.message);
    }
  })
  .catch(err => console.error('Erro no fetch:', err));
});