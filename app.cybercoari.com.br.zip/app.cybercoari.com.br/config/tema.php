<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/conexao.php";
require_once __DIR__ . "/funcoes.php";
require_once __DIR__ . "/debug.php";

// Descobre a página atual
$paginaAtual = basename($_SERVER['PHP_SELF']);

// Define páginas públicas (não exigem login)
$paginasPublicas = ['login.php', 'registrar.php', 'recuperar.php'];

// Se não for página pública, exige login
if (!in_array($paginaAtual, $paginasPublicas)) {
    checkLogin();
}