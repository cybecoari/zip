<?php
function checkLogin() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Verifica se a sessão existe
    if (empty($_SESSION['usuario_id'])) {
        // Para evitar loop infinito, envia um aviso em vez de redirecionar em excesso
        header("Location: /login.php?msg=not_logged");
        exit;
    }
}

function isAdmin() {
    if (!isset($_SESSION['user_nivel'])) {
        return false;
    }
    return in_array($_SESSION['user_nivel'], [1, 3]); // Admin ou SuperAdmin
}

/**
 * Retorna os dados do usuário logado
 */
function getUsuario($pdo) {
    if (!isset($_SESSION['usuario_id'])) return null;
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ? LIMIT 1");
    $stmt->execute([$_SESSION['usuario_id']]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Escapa HTML
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Verifica nível do usuário
 * Níveis:
 * 2 = Usuário comum
 * 1 = Admin
 * 3 = SuperAdmin
 */
function isSuperAdmin() {
    return isset($_SESSION['usuario_nivel']) && $_SESSION['usuario_nivel'] == 3;
}

function isAdmin() {
    return isset($_SESSION['usuario_nivel']) && in_array($_SESSION['usuario_nivel'], [1, 3]);
}

function isUser() {
    return isset($_SESSION['usuario_nivel']) && $_SESSION['usuario_nivel'] == 2;
}

/**
 * Marca usuário como online (atualiza IP e última atividade)
 */
function registrarOnline($pdo, $usuarioId) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $tempo = date("Y-m-d H:i:s");

    $stmt = $pdo->prepare("UPDATE usuarios SET ip = ?, ultima_atividade = ? WHERE id = ?");
    $stmt->execute([$ip, $tempo, $usuarioId]);
}

/**
 * Marca usuário como offline (logout)
 */
function registrarLogout($pdo, $usuarioId) {
    $stmt = $pdo->prepare("UPDATE usuarios SET ultima_atividade = NULL WHERE id = ?");
    $stmt->execute([$usuarioId]);
}

/**
 * Retorna total de usuários online + lista
 */
function getUsuariosOnlineInfo($pdo) {
    $expira = date("Y-m-d H:i:s", strtotime("-5 minutes")); // considera online nos últimos 5 min

    // Total (cast para inteiro)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE ultima_atividade >= ?");
    $stmt->execute([$expira]);
    $total = (int) $stmt->fetchColumn();

    // Lista detalhada
    $stmt = $pdo->prepare("SELECT usuario, ultima_atividade FROM usuarios WHERE ultima_atividade >= ? ORDER BY ultima_atividade DESC");
    $stmt->execute([$expira]);
    $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return [
        'total' => $total,
        'lista' => $lista
    ];
}

/**
 * Retorna total de cadastros
 */
function getTotalCadastros($pdo) {
    return (int) $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
}

/**
 * Retorna a data de fundação do site e os dias desde então
 */
function getDiasFundacao($pdo) {
    $stmt = $pdo->prepare("SELECT data_fundacao FROM usuarios WHERE id = 1 LIMIT 1");
    $stmt->execute();
    $siteFundacao = $stmt->fetchColumn();

    if (!$siteFundacao) {
        return null;
    }

    $dataFundacao = new DateTime($siteFundacao);
    $hoje = new DateTime();
    $diff = $dataFundacao->diff($hoje);

    return [
        'data' => $dataFundacao->format("d/m/Y"),
        'dias' => $diff->days,
        'anos' => $diff->y,
        'meses' => $diff->m,
        'diasDetalhado' => $diff->d
    ];
}