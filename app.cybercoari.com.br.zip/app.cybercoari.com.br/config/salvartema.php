<?php
session_start();
require_once __DIR__ . '/conexao.php';

// Define header de resposta como JSON
header('Content-Type: application/json; charset=utf-8');

// Permite apenas POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Método não permitido'
    ]);
    exit;
}

// Verifica sessão e parâmetro
if (!isset($_SESSION['usuario_id'], $_POST['tema'])) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Requisição inválida'
    ]);
    exit;
}

// Normaliza tema
$tema = ($_POST['tema'] === 'escuro') ? 'escuro' : 'claro';
$usuarioId = intval($_SESSION['usuario_id']);

try {
    // Atualiza no banco
    $stmt = $pdo->prepare("UPDATE usuarios SET tema = ? WHERE id = ?");
    $stmt->execute([$tema, $usuarioId]);

    // Atualiza na sessão
    $_SESSION['tema'] = $tema;

    echo json_encode([
        'status' => 'ok',
        'tema'   => $tema
    ]);
} catch (Exception $e) {
    error_log("Erro ao salvar tema: " . $e->getMessage()); // log interno
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Erro no servidor. Tente novamente mais tarde.'
    ]);
}