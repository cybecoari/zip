<?php
session_start();
require_once __DIR__ . '/../config/conexao.php';

// Verifica se veio via POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['id'])) {
    header("Location: ../loja.php?erro=produto_invalido");
    exit();
}

$id = (int) $_POST['id'];

// Busca o produto
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$produto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$produto) {
    die("Produto não encontrado!");
}

// ====== CONFIGURE AQUI ======
$chave_pix = "seu-email@provedor.com"; // sua chave PIX
$nome_recebedor = "CyberCoari";        // nome que aparece no PIX
$cidade = "COARI";                     // cidade obrigatória
$valor = number_format($produto['price'], 2, '.', '');

// 🔹 Txid único por pedido (até 35 caracteres permitidos)
$txid = "PED" . $produto['id'] . "-" . time();
$descricao = "Compra: " . $produto['name'];

// ====== Funções PIX ======
function crc16($string) {
    $crc = 0xFFFF;
    for ($i = 0; $i < strlen($string); $i++) {
        $crc ^= (ord($string[$i]) << 8);
        for ($j = 0; $j < 8; $j++) {
            if ($crc & 0x8000) {
                $crc = ($crc << 1) ^ 0x1021;
            } else {
                $crc = $crc << 1;
            }
            $crc &= 0xFFFF;
        }
    }
    return strtoupper(str_pad(dechex($crc), 4, '0', STR_PAD_LEFT));
}

function format($id, $value) {
    $len = strlen($value);
    return $id . sprintf("%02d", $len) . $value;
}

// ====== Montagem do payload PIX ======
$payload = "000201"; // versão
$payload .= format("26", "0014BR.GOV.BCB.PIX01" . sprintf("%02d", strlen($chave_pix)) . $chave_pix);
$payload .= "52040000"; // merchant category
$payload .= "5303986";  // moeda (986 = BRL)
$payload .= format("54", $valor); // valor
$payload .= "5802BR";   // país
$payload .= format("59", $nome_recebedor); // nome recebedor
$payload .= format("60", $cidade); // cidade
$payload .= format("62", "05" . sprintf("%02d", strlen($txid)) . $txid); // Txid dinâmico

// Adiciona CRC16
$payload .= "6304";
$crc = crc16($payload);
$pix_code = $payload . $crc;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Pagamento PIX</title>
  <link rel="stylesheet" href="https://cybercoari.com.br/cyber/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/qrcode/build/qrcode.min.js"></script>
</head>
<body class="container py-5">

  <h2 class="text-center mb-4">Pagamento PIX</h2>

  <div class="card p-4 shadow">
    <h4><?= htmlspecialchars($produto['name']) ?></h4>
    <p><strong>Preço:</strong> R$ <?= number_format($produto['price'], 2, ',', '.') ?></p>
    <p><strong>Entrega:</strong> <?= htmlspecialchars($produto['delivery_type']) ?></p>
    <p><strong>Txid:</strong> <?= $txid ?></p>

    <div class="text-center my-3">
      <canvas id="qrcode"></canvas>
    </div>

    <textarea id="pixCode" class="form-control mb-3" rows="3" readonly><?= $pix_code ?></textarea>
    
    <button class="btn btn-primary w-100" onclick="copiarPix()">📋 Copiar código PIX</button>
  </div>

  <script>
    // Gera QR Code
    QRCode.toCanvas(document.getElementById('qrcode'), "<?= $pix_code ?>");

    function copiarPix() {
      let codigo = document.getElementById("pixCode");
      codigo.select();
      codigo.setSelectionRange(0, 99999); 
      navigator.clipboard.writeText(codigo.value);
      alert("Código PIX copiado!");
    }
  </script>

</body>
</html>