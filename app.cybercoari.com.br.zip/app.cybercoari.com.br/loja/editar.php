<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

require '../config/conexao.php';
require '../config/funcoes.php';

// Recupera usuário/tema
$usuario = getUsuario($pdo);
$tema = $usuario['tema'] ?? ($_SESSION['tema'] ?? 'claro');
$_SESSION['tema'] = $tema;

$feedback = '';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<script>
        alert('ID inválido!');
        window.location.href = 'listar.php';
    </script>";
    exit;
}

$id = (int) $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$produto = $stmt->fetch();

if (!$produto) {
    echo "<script>
        alert('Produto não encontrado!');
        window.location.href = 'listar.php';
    </script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $price = str_replace(',', '.', $_POST['price']);
    $delivery_type = trim($_POST['delivery_type']);
    $image_url = $produto['image_url'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $fileTmp = $_FILES['image']['tmp_name'];
        $fileName = basename($_FILES['image']['name']);
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($ext, $allowed)) {
            $newName = uniqid() . "." . $ext;
            $destino = "../uploads/" . $newName;

            if (move_uploaded_file($fileTmp, $destino)) {
                $image_url = "uploads/" . $newName;
            }
        }
    }

    $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, delivery_type = ?, image_url = ? WHERE id = ?");
    if ($stmt->execute([$name, $price, $delivery_type, $image_url, $id])) {
        $feedback = 'success';
    } else {
        $feedback = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Produto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="https://cybercoari.com.br/cyber/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/assets/css/darkmode.css?v=7">
    
    <script src="https://cybercoari.com.br/cyber/js/jquery-3.7.1.min.js"></script>
    <script src="https://cybercoari.com.br/cyber/js/sweetalert2.all.min.js"></script>
    <script src="https://cybercoari.com.br/cyber/js/bootstrap.bundle.min.js"></script>
</head>
<body class="container py-4 <?= $tema === 'escuro' ? 'dark-mode bg-dark text-white' : 'bg-light' ?>">
    <h2><i class="bi bi-pencil"></i> Editar Produto</h2>

    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Nome:</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($produto['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Preço (ex: 49.90):</label>
            <input type="text" name="price" class="form-control" value="<?= htmlspecialchars($produto['price']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Tipo de Entrega:</label>
            <input type="text" name="delivery_type" class="form-control" value="<?= htmlspecialchars($produto['delivery_type']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Imagem Atual:</label><br>
            <?php if ($produto['image_url']): ?>
                <img src="../<?= htmlspecialchars($produto['image_url']) ?>" style="height: 60px;">
            <?php else: ?>
                <span>Nenhuma imagem</span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Nova Imagem (opcional):</label>
            <input type="file" name="image" accept="image/*" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="listar.php" class="btn btn-secondary">Cancelar</a>
    </form>

<?php if ($feedback == 'success'): ?>
<script>
Swal.fire('Sucesso', 'Produto atualizado com sucesso!', 'success').then(() => {
    window.location.href = 'listar.php';
});
</script>
<?php elseif ($feedback == 'error'): ?>
<script>
Swal.fire('Erro', 'Erro ao atualizar o produto!', 'error');
</script>
<?php endif; ?>

</body>
</html>