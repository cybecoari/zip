<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

require '../config/conexao.php';
require '../config/funcoes.php';

// Recupera usuário/tema
$usuario = getUsuario($pdo);
$tema = $usuario['tema'] ?? ($_SESSION['tema'] ?? 'claro');
$_SESSION['tema'] = $tema;

$id = $_GET['id'] ?? null;

if (!$id) {
    $mensagem = ['tipo' => 'error', 'titulo' => 'Erro!', 'texto' => 'ID do produto inválido.'];
} else {
    try {
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);

        $mensagem = ['tipo' => 'success', 'titulo' => 'Excluído!', 'texto' => 'Produto removido com sucesso.'];
    } catch (PDOException $e) {
        $mensagem = ['tipo' => 'error', 'titulo' => 'Erro!', 'texto' => 'Erro ao excluir produto.'];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Excluir Produto</title>
  <link rel="stylesheet" href="https://cybercoari.com.br/cyber/css/bootstrap.min.css">
  <link rel="stylesheet" href="/assets/css/darkmode.css?v=7">
  <script src="https://cybercoari.com.br/cyber/js/sweetalert2.all.min.js"></script>
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode bg-dark text-white' : 'bg-light' ?>">
  <script>
    Swal.fire({
      icon: '<?= $mensagem['tipo'] ?>',
      title: '<?= $mensagem['titulo'] ?>',
      text: '<?= $mensagem['texto'] ?>',
      confirmButtonText: 'OK'
    }).then(() => {
      window.location.href = 'listar.php';
    });
  </script>
</body>
</html>