<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

// Recupera o nome do usuário da sessão (deve ser definido no login)
$usuario_nome = $_SESSION['usuario_nome'] ?? 'Usuário';

// Recupera o tema (da sessão ou padrão claro)
$tema = $_SESSION['tema'] ?? 'claro';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Cybercoari - Painel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <link rel="stylesheet" href="/assets/css/darkmode.css?v=7">
  
  <style>
    .logo {
      text-align: center;
      font-size: 2.5rem;
      font-weight: bold;
      color: lime;
      text-shadow: 2px 2px #800080;
      margin-top: 20px;
    }
    .info {
      text-align: center;
      margin-top: 10px;
    }
    .info p {
      margin: 0;
      font-size: 1rem;
    }
    .card-container {
      max-width: 500px;
      margin: 30px auto;
      padding: 30px;
      border: 0px solid #fff;
      border-radius: 20px;
    }
    .menu-item {
      display: flex;
      align-items: center;
      padding: 14px 0;
      border-bottom: 1px solid #3a506b;
      text-decoration: none;
      font-size: 1.1rem;
      transition: all 0.3s ease;
    }
    .menu-item:last-child {
      border-bottom: none;
    }
    .menu-item i {
      margin-right: 12px;
      font-size: 1.2rem;
      transition: all 0.3s ease;
    }
    .menu-item:hover {
      color: #00ffff;
    }
    .menu-item:hover i {
      color: #00ffff;
    }
    .online-status {
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: #0f0;
      box-shadow: 0 0 10px #0f0;
      margin-right: 5px;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
  </style>
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode bg-dark text-white' : 'bg-light text-dark' ?>">

  <div class="info">
    <p class="fs-2">
      <span class="online-status" id="onlineStatus"></span>
      <span class="text-primary mt-5">Bem-vindo,</span>
      <strong class="text-success"><?= htmlspecialchars($usuario_nome, ENT_QUOTES, 'UTF-8') ?></strong>
      <span class="online-status" id="onlineStatus"></span>
    </p>
  </div>

  <div class="card-container container <?= $tema === 'escuro' ? 'bg-dark text-white' : 'bg-light text-dark' ?>">
    <a href="/loja.php" class="menu-item"><i class="bi bi-shop"></i> Loja</a>
    <a href="/loja/adicionar.php" class="menu-item"><i class="bi bi-plus"></i> Adicionar Produtos</a>
    <a href="/loja/listar.php" class="menu-item"><i class="bi bi-list-ul"></i> Listar Produtos</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    function checkOnlineStatus() {
      document.getElementById('onlineStatus').style.backgroundColor = '#0f0';
      $.ajax({
        url: '/api/keepalive.php',
        method: 'GET',
        error: function() {
          document.getElementById('onlineStatus').style.backgroundColor = '#f00';
        }
      });
    }
    setInterval(checkOnlineStatus, 30000);
    window.addEventListener('load', checkOnlineStatus);

    window.addEventListener('offline', function() {
      document.getElementById('onlineStatus').style.backgroundColor = '#f00';
      Swal.fire({
        title: 'Conexão perdida',
        text: 'Você está offline. Algumas funcionalidades podem não estar disponíveis.',
        icon: 'warning',
        confirmButtonText: 'OK',
        background: '#16213e',
        color: 'white'
      });
    });

    document.addEventListener('DOMContentLoaded', function() {
      Swal.fire({
        title: 'Bem-vindo!',
        text: 'Você está logado como <?= htmlspecialchars($usuario_nome, ENT_QUOTES, 'UTF-8') ?>',
        icon: 'success',
        confirmButtonText: 'OK',
        timer: 3000,
        timerProgressBar: true,
        background: '<?= $tema === "escuro" ? "#16213e" : "#fff" ?>',
        color: '<?= $tema === "escuro" ? "white" : "black" ?>'
      });
    });
  </script>
</body>
</html>