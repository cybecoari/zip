<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Caminho correto para conexao.php
require __DIR__ . '/../config/conexao.php';

// Recupera o tema da sessão (ou padrão claro)
$tema = $_SESSION['tema'] ?? 'claro';

// Busca produtos
$stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Lista de Produtos</title>
  <?php @include __DIR__ . '/../includes/cdn.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://cybercoari.com.br/cyber/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cybercoari.com.br/cyber/icons/font/bootstrap-icons.css">
  <link rel="stylesheet" href="/assets/css/darkmode.css?v=7">

  <script src="https://cybercoari.com.br/cyber/js/jquery-3.7.1.min.js"></script>
  <script src="https://cybercoari.com.br/cyber/js/sweetalert2.all.min.js"></script>
  <script src="https://cybercoari.com.br/cyber/js/bootstrap.bundle.min.js"></script>
</head>
<body class="container py-4 <?= $tema === 'escuro' ? 'dark-mode bg-dark text-white' : 'bg-light text-dark' ?>">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2><i class="bi bi-list-ul"></i> Lista de Produtos</h2>
    <a href="adicionar.php" class="btn btn-success">
      <i class="bi bi-plus-circle"></i> Adicionar Produto
    </a>
  </div>

  <table class="table table-bordered table-hover <?= $tema === 'escuro' ? 'table-dark' : 'table-striped' ?>">
    <thead class="<?= $tema === 'escuro' ? 'table-secondary' : 'table-dark' ?>">
      <tr>
        <th>#</th>
        <th>Imagem</th>
        <th>Nome</th>
        <th>Preço</th>
        <th>Entrega</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!empty($produtos)): ?>
        <?php foreach ($produtos as $produto): ?>
          <tr>
            <td><?= $produto['id'] ?></td>
            <td>
              <?php
                $caminhoImagem = __DIR__ . '/../' . $produto['image_url'];
                if (!empty($produto['image_url']) && file_exists($caminhoImagem)):
              ?>
                <img src="/<?= htmlspecialchars($produto['image_url']) ?>" alt="Imagem" width="60">
              <?php else: ?>
                <span>Sem imagem</span>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($produto['name']) ?></td>
            <td>R$ <?= number_format($produto['price'], 2, ',', '.') ?></td>
            <td><?= htmlspecialchars($produto['delivery_type']) ?></td>
            <td>
              <a href="editar.php?id=<?= $produto['id'] ?>" class="btn btn-warning btn-sm">
                <i class="bi bi-pencil"></i>
              </a>
              <button class="btn btn-danger btn-sm btn-excluir" data-id="<?= $produto['id'] ?>">
                <i class="bi bi-trash"></i>
              </button>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr>
          <td colspan="6" class="text-center">Nenhum produto encontrado.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <script>
    $(document).ready(function() {
      $('.btn-excluir').click(function() {
        const id = $(this).data('id');

        Swal.fire({
          title: 'Tem certeza?',
          text: 'Essa ação não poderá ser desfeita!',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#d33',
          cancelButtonColor: '#6c757d',
          confirmButtonText: 'Sim, excluir!',
          cancelButtonText: 'Cancelar',
          background: '<?= $tema === "escuro" ? "#16213e" : "#fff" ?>',
          color: '<?= $tema === "escuro" ? "white" : "black" ?>'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = 'excluir.php?id=' + id;
          }
        });
      });
    });
  </script>

  <?php @include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>