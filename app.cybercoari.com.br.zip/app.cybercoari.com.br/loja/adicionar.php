<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';
require_once '../config/funcoes.php';

// Recupera o usuário e o tema salvo
$usuario = getUsuario($pdo);
$tema = $usuario['tema'] ?? ($_SESSION['tema'] ?? 'claro');
$_SESSION['tema'] = $tema;

$mensagem = '';
$tipo = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nome = $_POST['nome'] ?? '';
  $preco = $_POST['preco'] ?? '';
  $entrega = $_POST['entrega'] ?? '';

  // Upload da imagem
  $imagemUrl = '';
  if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
    $ext = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION);
    $permitidos = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array(strtolower($ext), $permitidos)) {
      $novoNome = uniqid() . '.' . $ext;
      $destino = "../uploads/" . $novoNome;
      if (move_uploaded_file($_FILES['imagem']['tmp_name'], $destino)) {
        $imagemUrl = "uploads/" . $novoNome;
      }
    }
  }

  if (!empty($nome) && !empty($preco) && !empty($entrega)) {
    try {
      $stmt = $pdo->prepare("INSERT INTO products (name, price, delivery_type, image_url) VALUES (?, ?, ?, ?)");
      $stmt->execute([$nome, $preco, $entrega, $imagemUrl]);
      $mensagem = "Produto adicionado com sucesso!";
      $tipo = "success";
    } catch (PDOException $e) {
      $mensagem = "Erro ao adicionar produto.";
      $tipo = "error";
    }
  } else {
    $mensagem = "Preencha todos os campos obrigatórios.";
    $tipo = "warning";
  }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Adicionar Produto</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://cybercoari.com.br/cyber/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <script src="https://cybercoari.com.br/cyber/js/sweetalert2.all.min.js"></script>
  <script src="https://cybercoari.com.br/cyber/js/jquery-3.7.1.min.js"></script>
  <link rel="stylesheet" href="/assets/css/darkmode.css?v=7">

  <!-- Sons -->
  <audio id="som-sucesso" src="https://cybercoari.com.br/cyber/audio/sucesso.mp3"></audio>
  <audio id="som-erro" src="https://cybercoari.com.br/cyber/audio/erro.mp3"></audio>
  <audio id="som-click" src="https://cybercoari.com.br/cyber/audio/click.mp3"></audio>
</head>
<body class="container py-4 <?= $tema === 'escuro' ? 'dark-mode bg-dark text-white' : 'bg-light' ?>">

  <h2><i class="bi bi-plus-circle"></i> Adicionar Produto</h2>

  <form method="POST" enctype="multipart/form-data" class="mt-4">
    <div class="mb-3">
      <label for="nome" class="form-label">Nome do Produto</label>
      <input type="text" class="form-control" id="nome" name="nome" required>
    </div>
    <div class="mb-3">
      <label for="preco" class="form-label">Preço (R$)</label>
      <input type="number" step="0.01" class="form-control" id="preco" name="preco" required>
    </div>
    <div class="mb-3">
      <label for="entrega" class="form-label">Tipo de Entrega</label>
      <input type="text" class="form-control" id="entrega" name="entrega" required>
    </div>
    <div class="mb-3">
      <label for="imagem" class="form-label">Imagem do Produto (opcional)</label>
      <input type="file" class="form-control" id="imagem" name="imagem" accept="image/*">
    </div>
    <button type="submit" class="btn btn-primary" onclick="document.getElementById('som-click').play();">
      <i class="bi bi-save"></i> Salvar Produto
    </button>
    
    <a href="listar.php" class="btn btn-secondary" onclick="document.getElementById('som-click').play();">
      <i class="bi bi-arrow-left"></i> Voltar
    </a>
    
    <a href="/painel.php" class="btn btn-success" onclick="document.getElementById('som-click').play();">
      <i class="bi bi-speedometer2"></i> Painel
    </a>
  </form>

  <?php if (!empty($mensagem)): ?>
    <script>
      document.addEventListener('DOMContentLoaded', function () {
        const tipo = "<?= $tipo ?>";
        if (tipo === "success") {
          document.getElementById('som-sucesso').play();
        } else if (tipo === "error" || tipo === "warning") {
          document.getElementById('som-erro').play();
        }

        Swal.fire({
          icon: tipo,
          title: tipo === "success" ? "Sucesso!" : (tipo === "warning" ? "Atenção" : "Erro!"),
          text: "<?= $mensagem ?>",
        });
      });
    </script>
  <?php endif; ?>

</body>
</html>