<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

require '../config/conexao.php';

// Recupera o tema da sessão (claro padrão)
$tema = $_SESSION['tema'] ?? 'claro';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id            = intval($_POST['id']);
    $name          = $_POST['name'];
    $price         = $_POST['price'];
    $delivery_type = $_POST['delivery_type'];
    $image_url     = $_POST['image_url'];

    try {
        $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, delivery_type = ?, image_url = ? WHERE id = ?");
        $stmt->execute([$name, $price, $delivery_type, $image_url, $id]);
        $status = "success";
    } catch (PDOException $e) {
        $status = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Produto Atualizado</title>
  <link rel="stylesheet" href="https://cybercoari.com.br/cyber/css/bootstrap.min.css">
  <script src="https://cybercoari.com.br/cyber/js/jquery-3.7.1.min.js"></script>
  <script src="https://cybercoari.com.br/cyber/js/sweetalert2.all.min.js"></script>
  <audio id="som-sucesso" src="https://cybercoari.com.br/cyber/audio/sucesso.mp3" preload="auto"></audio>
</head>
<body class="<?= $tema === 'escuro' ? 'bg-dark text-white' : 'bg-light text-dark' ?>">
  <script>
    $(document).ready(function () {
      <?php if ($status === "success"): ?>
        document.getElementById("som-sucesso").play();
        Swal.fire({
          icon: 'success',
          title: 'Produto atualizado!',
          text: 'As alterações foram salvas com sucesso.',
          showConfirmButton: false,
          timer: 2000,
          background: '<?= $tema === "escuro" ? "#16213e" : "#fff" ?>',
          color: '<?= $tema === "escuro" ? "white" : "black" ?>'
        });
      <?php else: ?>
        Swal.fire({
          icon: 'error',
          title: 'Erro!',
          text: 'Ocorreu um problema ao atualizar o produto.',
          confirmButtonText: 'OK',
          background: '<?= $tema === "escuro" ? "#16213e" : "#fff" ?>',
          color: '<?= $tema === "escuro" ? "white" : "black" ?>'
        });
      <?php endif; ?>

      setTimeout(function () {
        window.location.href = 'listar.php';
      }, 2200);
    });
  </script>
</body>
</html>