<?php

require_once __DIR__ . '/config/conexao.php';
require_once __DIR__ . '/config/funcoes.php';
require_once __DIR__ . '/config/tema.php';

?>

<!-- logo apos o titulo da pagina -->
<title>Painel de Controle</title>
<?php include __DIR__ . '/config/cdn.php'; ?>
<link rel="stylesheet" href="/assets/css/darkmode.css?v=2">
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode' : ''; ?>">

<!-- BOTÃO DARK MODE -->
<div class="theme-toggle">
  <button id="theme-toggle" title="Alternar tema">
    <i id="theme-icon" class="bi <?php echo $tema === 'escuro' ? 'bi-sun-fill' : 'bi-moon-fill'; ?>"></i>
  </button>
</div>

<!-- antes do final do /body -->
<script src="/assets/js/darkmode.js"></script>
</body>