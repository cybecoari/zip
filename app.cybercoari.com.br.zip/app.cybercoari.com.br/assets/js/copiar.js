async function copiarSite() {
  const url = $("#url").val().trim();
  const proxy = "https://api.codetabs.com/v1/proxy?quest=";

  if (!url.startsWith("http")) {
    $("#erro")[0].play();
    Swal.fire({
      icon: "warning",
      title: "URL inválida",
      text: "Por favor, inclua http:// ou https:// no início da URL."
    });
    return;
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000); // 10s

    const response = await fetch(proxy + encodeURIComponent(url), {
      signal: controller.signal
    });
    clearTimeout(timeout);

    if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);

    const html = await response.text();

    if (!html) throw new Error("Conteúdo vazio retornado.");

    // 👉 Se quiser renderizar o site dentro do resultado:
    $("#resultado").html(html);

    $("#sucesso")[0].play();
    Swal.fire({
      icon: "success",
      title: "Sucesso",
      text: "HTML copiado com sucesso!",
      showConfirmButton: false,
      timer: 2000
    });

  } catch (error) {
    $("#erro")[0].play();
    Swal.fire({
      icon: "error",
      title: "Erro ao copiar",
      text: error.message
    });
  }
}