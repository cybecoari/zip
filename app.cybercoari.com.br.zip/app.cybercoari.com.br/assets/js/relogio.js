document.addEventListener('DOMContentLoaded', function () {
    const saudacaoEl = document.getElementById('saudacao');
    const dataEl     = document.getElementById('data');
    const horaEl     = document.getElementById('hora');

    function atualizarRelogio() {
        const agora = new Date();

        // Saudação
        if (saudacaoEl) {
            const horas = agora.getHours();
            let saudacao = "Boa noite!";
            if (horas >= 5 && horas < 12) saudacao = "Bom dia!";
            else if (horas >= 12 && horas < 18) saudacao = "Boa tarde!";
            saudacaoEl.innerText = saudacao;
        }

        // Data NO FORMATO DD/MM/YYYY (ex: 01/01/2025)
        if (dataEl) {
            const dia = String(agora.getDate()).padStart(2, '0');
            const mes = String(agora.getMonth() + 1).padStart(2, '0'); // Janeiro = 0
            const ano = agora.getFullYear();
            dataEl.innerText = `${dia}/${mes}/${ano}`;
        }

        // Hora HH:MM:SS (24h)
        if (horaEl) {
            const hh = String(agora.getHours()).padStart(2, '0');
            const mm = String(agora.getMinutes()).padStart(2, '0');
            const ss = String(agora.getSeconds()).padStart(2, '0');
            horaEl.innerText = `${hh}:${mm}:${ss}`;
        }
    }

    atualizarRelogio();
    setInterval(atualizarRelogio, 1000);
});