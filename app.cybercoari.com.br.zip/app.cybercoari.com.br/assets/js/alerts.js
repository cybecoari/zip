document.addEventListener("DOMContentLoaded", function () {
    // 🔹 Confirmação de exclusão
    document.querySelectorAll('.btn-excluir').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            let url = this.getAttribute('data-url');

            Swal.fire({
                title: "Tem certeza?",
                text: "Esta ação não poderá ser desfeita!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#6c757d",
                confirmButtonText: "Sim, excluir!",
                cancelButtonText: "Cancelar"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        });
    });

    // 🔹 Confirmação de logout
    document.querySelectorAll('.btn-logout').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            let url = this.getAttribute('data-url') || "logout.php";

            Swal.fire({
                title: "Deseja sair?",
                text: "Você será desconectado do sistema.",
                icon: "question",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#6c757d",
                confirmButtonText: "Sim, sair",
                cancelButtonText: "Cancelar"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        });
    });

    // 🔹 Mensagens flash automáticas
    const flashMessage = document.body.getAttribute("data-flash-message");
    const flashType = document.body.getAttribute("data-flash-type");

    if (flashMessage) {
        Swal.fire({
            icon: flashType || "info",
            title: flashType === "success" ? "Sucesso!" : 
                   flashType === "error"   ? "Erro!"    : 
                   flashType === "warning" ? "Atenção!" : "Aviso",
            text: flashMessage,
            confirmButtonText: "OK"
        });
    }
});