document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("theme-toggle");
  const icon = document.getElementById("theme-icon");
  const body = document.body;

  if (!toggleBtn || !icon) return; // evita erro em páginas sem botão

  // Atualiza o ícone conforme tema
  const updateIcon = () => {
    if (body.classList.contains("dark-mode")) {
      icon.classList.remove("bi-moon-stars-fill");
      icon.classList.add("bi-sun-fill");
    } else {
      icon.classList.remove("bi-sun-fill");
      icon.classList.add("bi-moon-stars-fill");
    }
  };

  // Ajusta ícone ao carregar
  updateIcon();

  toggleBtn.addEventListener("click", async () => {
    const temaAnterior = body.classList.contains("dark-mode") ? "escuro" : "claro";

    // Alterna tema
    body.classList.toggle("dark-mode");
    const tema = body.classList.contains("dark-mode") ? "escuro" : "claro";

    updateIcon();

    try {
      const response = await fetch("config/salvartema.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "tema=" + encodeURIComponent(tema)
      });

      const result = await response.json();

      if (!response.ok || result.status !== "ok") {
        // Reverte tema se falhar
        body.classList.toggle("dark-mode", temaAnterior === "escuro");
        updateIcon();

        Swal.fire({
          icon: "error",
          title: "Erro",
          text: result.message || "Não foi possível salvar o tema.",
          confirmButtonText: "OK"
        });
      }
    } catch (error) {
      // Reverte tema se falhar
      body.classList.toggle("dark-mode", temaAnterior === "escuro");
      updateIcon();

      console.error("Erro ao salvar tema:", error);
      Swal.fire({
        icon: "error",
        title: "Falha de conexão",
        text: "Não foi possível se conectar ao servidor.",
        confirmButtonText: "OK"
      });
    }
  });
});