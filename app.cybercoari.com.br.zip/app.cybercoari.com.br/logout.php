<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/config/conexao.php";
require_once __DIR__ . "/config/funcoes.php";

// Se tiver usuário logado, registra logout no banco
if (isset($_SESSION['usuario_id'])) {
    if (function_exists('registrarLogout')) {
        registrarLogout($pdo, $_SESSION['usuario_id']);
    }
}

// Limpa variáveis de sessão
$_SESSION = [];

// Destrói cookie de sessão
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destrói sessão
session_destroy();

// Redireciona pro login com flash message
header("Location: /login.php?flashMessage=" . urlencode("Logout realizado com sucesso!") . "&flashType=success");
exit;