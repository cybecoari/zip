<?php
// Debug de erros (desligar em produção)
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Inicia sessão
session_start();

// Includes necessários
require_once __DIR__ . "/../config/conexao.php";
require_once __DIR__ . "/../config/funcoes.php";
require_once __DIR__ . "/../includes/sessao.php"; // se existir

// Variáveis de controle
$uid  = $_SESSION['uid'] ?? null;  // ID do usuário logado
$acao = $_GET['acao'] ?? null;     // ação passada na URL (?acao=...)
$sid  = session_id();              // ID da sessão
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title><?= getConfig('titulo') ?></title>
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/fontawesome.min.css">
</head>
<body>

<div class="container">
    <center>
        <!-- Logotipo -->
        <a href="home.php">
            <img class="mt-5"
                 src="<?= getConfig('logo') ?>"
                 width="<?= getConfig('largura') ?>"
                 height="<?= getConfig('altura') ?>">
        </a><br>

        <!-- Boas-vindas -->
        Bem vindo(a) <b><?= getNickById($uid) ?></b>!<br>

        <!-- MENU -->
        <div class="mt-3 col-12 px-0 mb-4">
            <div class="card border-0 shadow">
                <div class="card-body">

                    <!-- Item 1 -->
                    <div class="d-flex align-items-center justify-content-between border-bottom py-3">
                        <div>
                            <div class="h6 mb-0 d-flex align-items-center">
                                <a href="update/<?= getData('pasta_att', $uid) ?>/config" download="config.json">
                                    <i class="fa-solid fa-download"></i> Baixar JSON
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Item 2 -->
                    <div class="d-flex align-items-center justify-content-between border-bottom py-3">
                        <div>
                            <div class="h6 mb-0 d-flex align-items-center">
                                <a href="app.php"><i class="fa-solid fa-gear"></i> Configurações do app</a>
                            </div>
                        </div>
                    </div>

                    <!-- Item admin -->
                    <?php if (getAdm($uid)) : ?>
                        <div class="d-flex align-items-center justify-content-between border-bottom py-3">
                            <div>
                                <div class="h6 mb-0 d-flex align-items-center">
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#modal-config-site">
                                        <i class="fa-solid fa-gear"></i> Configurações do site
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Perfil -->
                    <div class="d-flex align-items-center justify-content-between border-bottom py-3">
                        <div>
                            <div class="h6 mb-0 d-flex align-items-center">
                                <a href="perfil.php"><i class="fa-solid fa-user"></i> Configurações de perfil</a>
                            </div>
                        </div>
                    </div>

                    <!-- Usuários (admin) -->
                    <?php if (getAdm($uid)) : ?>
                        <div class="d-flex align-items-center justify-content-between border-bottom py-3">
                            <div>
                                <div class="h6 mb-0 d-flex align-items-center">
                                    <a href="usuarios.php"><i class="fa-solid fa-users"></i> Gerenciar usuários</a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Sair -->
                    <div class="d-flex align-items-center justify-content-between pt-3">
                        <div>
                            <div class="h6 mb-0 d-flex align-items-center">
                                <a href="?acao=sair"><i class="fa-solid fa-right-from-bracket"></i> Sair do site</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
</div>

<?php
// Logout
if ($acao === "sair") {
    if (isset($conn, $sid)) {
        $conn->query("DELETE FROM sessao WHERE id='" . $conn->real_escape_string($sid) . "'");
    }
    session_destroy();
    header("Location: /");
    exit;
}
?>

<?php if (getAdm($uid)) : ?>
<!-- MODAL CONFIGURAÇÕES SITE -->
<div class="modal fade" id="modal-config-site" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="h6 modal-title">Configurações do site</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <form action="editar.php?acao=site" method="post">
                    <div class="row">
                        <div class="col">
                            <label>Logotipo</label>
                            <input type="text" name="logo" class="form-control" value="<?= getConfig('logo') ?>">
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col">
                            <label>Largura</label>
                            <input type="text" name="largura" class="form-control" value="<?= getConfig('largura') ?>">
                        </div>
                        <div class="col">
                            <label>Altura</label>
                            <input type="text" name="altura" class="form-control" value="<?= getConfig('altura') ?>">
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col">
                            <label>Link do site</label>
                            <input type="text" name="link" class="form-control" value="<?= getConfig('link') ?>">
                        </div>
                        <div class="col">
                            <label>Título do site</label>
                            <input type="text" name="titulo" class="form-control" value="<?= getConfig('titulo') ?>">
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="atualiza_site" class="btn btn-success">Editar</button>
                </form>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . "/../config/rodape.php"; ?>

<script src="/assets/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/fontawesome.min.js"></script>
</body>
</html>