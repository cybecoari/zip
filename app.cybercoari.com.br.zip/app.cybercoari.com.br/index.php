<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Redireciona para o painel admin
require_once __DIR__ . '/config/conexao.php';
require_once __DIR__ . '/config/funcoes.php';

session_start();

if (isset($_SESSION['user_id'])) {
    // Se já está logado, vai para o painel
    header("Location: /admin/painel.php");
} else {
    // Se não está logado, vai para login
    header("Location: /login.php");
}
exit;