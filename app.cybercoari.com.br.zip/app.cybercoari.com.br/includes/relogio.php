<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/../config/conexao.php";
require_once __DIR__ . "/../config/funcoes.php";
require_once __DIR__ . "/../config/debug.php";

// Atualiza atividade
registrarOnline($pdo, $usuario['id']);

// Tema (do banco ou sessão)
$tema = $usuario['tema'] ?? ($_SESSION['tema'] ?? 'escuro');
$_SESSION['tema'] = $tema;

// Mensagens flash
$flashMessage = "";
$flashType = "";
if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case 'excluido':
            $flashMessage = "✅ Registro excluído com sucesso!";
            $flashType = "success";
            break;
        case 'erro':
            $flashMessage = "⚠️ Ocorreu um erro. Tente novamente.";
            $flashType = "error";
            break;
    }
}

// Totais
$totalCadastros = getTotalCadastros($pdo);
$usuariosOnlineInfo = getUsuariosOnlineInfo($pdo);

// Fundação
$fundacao = function_exists('getDiasFundacao') ? getDiasFundacao($pdo) : null;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Painel</title>
  <?php include __DIR__ . '/../includes/cdn.php' ?>

  <style>
    body {
        font-family: Arial, sans-serif;
        background: <?= $tema === 'escuro' ? '#121212' : '#f5f5f5'; ?>;
        color: <?= $tema === 'escuro' ? '#f5f5f5' : '#121212'; ?>;
        margin: 0;
        padding: 0;
        text-align: center;
    }
    img.banner {
        max-width: 100%;
        border-radius: 10px;
        margin-top: 20px;
    }
    h3 {
        margin-top: 15px;
    }
    .alert {
        padding: 12px 18px;
        border-radius: 6px;
        margin: 15px auto;
        width: 80%;
        max-width: 600px;
        font-weight: bold;
        text-align: center;
    }
    .alert-success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    .alert-error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    .relogio-container {
        margin-top: 20px;
    }
    .info {
        margin-top: 15px;
        font-size: 14px;
    }
    .numero {
        font-weight: bold;
    }
  </style>
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode' : ''; ?>">

    <!-- Banner -->
    <img src="assets/imagens/banner.png"
         alt="Banner" 
         class="banner"
         style="width:<?= e($largura); ?>px; height:<?= e($altura); ?>px;">

    <!-- Mensagem Flash -->
    <?php if (!empty($flashMessage)): ?>
        <div class="alert <?= $flashType === 'success' ? 'alert-success' : 'alert-error'; ?>">
            <?= e($flashMessage); ?>
        </div>
    <?php endif; ?>

    <!-- Saudação -->
    <h3>Bem-vindo, <?= e($usuario['usuario'] ?? "Sistema"); ?>!</h3>

    <!-- Relógio -->
    <div class="relogio-container">
        <h5 id="saudacao"></h5>
        <div id="data"></div>
        <div id="hora"></div>
    </div>

    <!-- Fundação -->
    <?php if ($fundacao): ?>
        <p><strong>Site Online: <?= $fundacao['dias'] ?> dias atrás</strong></p>
    <?php else: ?>
        <p><em>Data de fundação não definida.</em></p>
    <?php endif; ?>

    <!-- Estatísticas -->
    <div class="info">
        <span>Onlines: <span class="numero"><?= $usuariosOnlineInfo['total'] ?? 0 ?></span></span> | 
        <span>Cadastros: <span class="numero"><?= $totalCadastros ?></span></span>
    </div>

    <script>
        function atualizarRelogio() {
            const agora = new Date();
            const horas = agora.getHours().toString().padStart(2, "0");
            const minutos = agora.getMinutes().toString().padStart(2, "0");
            const segundos = agora.getSeconds().toString().padStart(2, "0");

            const opcoesData = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
            const data = agora.toLocaleDateString("pt-BR", opcoesData);

            document.getElementById("hora").textContent = `${horas}:${minutos}:${segundos}`;
            document.getElementById("data").textContent = data;

            let saudacao = "Boa noite";
            if (agora.getHours() < 12) saudacao = "Bom dia";
            else if (agora.getHours() < 18) saudacao = "Boa tarde";

            document.getElementById("saudacao").textContent = saudacao;
        }
        setInterval(atualizarRelogio, 1000);
        atualizarRelogio();
    </script>
</body>
</html>