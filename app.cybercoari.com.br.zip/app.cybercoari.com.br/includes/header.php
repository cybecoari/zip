<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/../config/conexao.php";
require_once __DIR__ . "/../config/funcoes.php";
require_once __DIR__ . "/../config/debug.php";

checkLogin();
$usuario = getUsuario($pdo);
if (!$usuario) {
    session_unset();
    session_destroy();
    header("Location: /login.php");
    exit;
}

// Atualiza atividade
registrarOnline($pdo, $usuario['id'] ?? 0);

// Tema vem do banco e sincroniza com a sessão
$tema = $usuario['tema'] ?? 'claro';
$_SESSION['tema'] = $tema;

// Totais
$totalCadastros = getTotalCadastros($pdo);
$onlineInfo     = getUsuariosOnlineInfo($pdo);
$fundacao       = function_exists('getDiasFundacao') ? getDiasFundacao($pdo) : null;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Painel</title>
  <?php include __DIR__ . '/../includes/cdn.php'; ?>
</head>
<body class="<?= $tema === 'escuro' ? 'dark-mode' : ''; ?>">

<!-- Topo -->
<center>
    <?php if (!empty($usuario['banner'])): ?>
      <img src="<?= e($usuario['banner']); ?>" 
        alt="Banner" 
        style="max-width:100%; width:<?= e($usuario['banner_largura'] ?? 100); ?>px; height:<?= e($usuario['banner_altura'] ?? 100); ?>px; border-radius:10px;">   
    <?php endif; ?>

    <!-- Saudação -->
    <h3 class="text-center mt-2">Bem-vindo, <?= e($usuario['usuario']); ?>!</h3>

    <!-- Relógio -->
    <div class="relogio-container">
        <h5 id="saudacao"></h5>
        <div id="data" class="data"></div>
        <div id="hora" class="hora"></div>
    </div>
    
    <?php if ($fundacao): ?>
    <p><strong>Site online há <?= $fundacao['dias'] ?> dias</strong></p>
    <?php else: ?>
    <p><em>Data de fundação não definida.</em></p>
    <?php endif; ?>
   
    <div class="info">
    <span>Onlines: <span class="numero online"><?= $onlineInfo['total'] ?? 0 ?></span></span> | 
    <span>Cadastros: <span class="numero cadastros"><?= $totalCadastros ?></span></span>
    </div>
</center>
<!-- fim do topo -->