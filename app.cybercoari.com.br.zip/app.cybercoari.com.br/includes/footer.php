<?php
if (!function_exists('e')) {
    function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

$anoAtual      = date("Y");
$versaoSistema = "1.0";
?>
<footer class="text-center mt-4 py-3 border-top footer-custom">
    <p class="mb-1">
        &copy; <?= $anoAtual ?> - <?= e($usuario['usuario'] ?? "Sistema"); ?>
    </p>
    <p class="mb-1">
        Versão <?= $versaoSistema ?> | Desenvolvido com ❤️ em PHP
    </P>

    <p class="mb-1">
        <a href="/" class="mx-2">Início</a> |
        <a href="/painel.php" class="mx-2">Painel</a> |
        <a href="/logout.php" class="mx-2">Sair</a>
    </p>
</footer>

  <!--<style>
/* =====================
   Tema Claro (padrão)
   ===================== */
body {
  background-color: #ffffff;
  color: #000000;
  font-family: Arial, Helvetica, sans-serif;
}

a {
  color: #007bff;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}

footer.footer-custom {
  background-color: #f8f9fa; /* fundo claro */
  color: #000000; /* texto preto */
  font-size: 0.9rem;
}

footer.footer-custom small {
  color: #6c757d; /* cinza do bootstrap */
}

/* =====================
   Tema Escuro (ativado com .dark no <body>)
   ===================== */
.dark {
  background-color: #16213e;
  color: #ffffff;
}

.dark a {
  color: #66b2ff; 
}

.dark a:hover {
  color: #99ccff;
}

.dark footer.footer-custom {
  background-color: #1e1e1e; /* fundo escuro */
  color: #ffffff;
  border-top: 1px solid #333; /* separador discreto */
}

.dark footer.footer-custom small {
  color: #cccccc;
}
  </style>-->

<!-- Scripts globais -->
</body>
</html>