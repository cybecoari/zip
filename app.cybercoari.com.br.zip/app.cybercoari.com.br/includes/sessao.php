<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Tempo limite em segundos (15 min = 900s)
$tempoLimite = 900;

// Se usuário não estiver logado → volta pro login
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

// Se já tem login, verifica inatividade
if (isset($_SESSION['ultimo_acesso'])) {
    $tempoInativo = time() - $_SESSION['ultimo_acesso'];
    if ($tempoInativo > $tempoLimite) {
        // Limpa sessão
        session_unset();
        session_destroy();
        header("Location: login.php?expirou=1");
        exit;
    }
}

// Atualiza timestamp de atividade
$_SESSION['ultimo_acesso'] = time();