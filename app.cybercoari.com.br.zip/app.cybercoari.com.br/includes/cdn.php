<?php
// includes/cdn.php
?>
<!-- ================= META TAGS ================= -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="index, follow">
<meta name="theme-color" content="#0d6efd">
<meta name="description" content="Sistema com suporte a Bootstrap, JS libs e PWA.">
<link rel="manifest" href="/manifest.json">
<link rel="icon" href="/assets/imagens/favicon.ico">
<link rel="stylesheet" href="/assets/css/darkmode.css?v=5">

<!-- ================= GOOGLE FONTS ================= -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<!-- ================= CSS FRAMEWORKS ================= -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">

<!-- ================= CSS (LOCAL FALLBACK) ================= -->
<link href="/cyber/css/bootstrap.min.css" rel="stylesheet">
<link href="/cyber/icones/font/bootstrap-icons.css" rel="stylesheet">
<link href="/cyber/css/fontawesome.min.css" rel="stylesheet">
<link href="/cyber/css/animate.min.css" rel="stylesheet">
<link href="/cyber/css/aos.css" rel="stylesheet">

<!-- ================= JAVASCRIPT (CDN) ================= -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
<script src="https://unpkg.com/html5-qrcode@2.3.8/dist/html5-qrcode.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/dayjs@1/dayjs.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4.17.21/lodash.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>

<!-- ================= JAVASCRIPT (LOCAL FALLBACK) ================= -->
<script src="/cyber/js/jquery-3.7.1.min.js"></script>
<script src="/cyber/js/bootstrap.bundle.min.js"></script>
<script src="/cyber/js/axios.min.js"></script>
<script src="/cyber/js/sweetalert2.all.min.js"></script>
<script src="/cyber/js/qrcode.min.js"></script>
<script src="/cyber/js/html5-qrcode.min.js"></script>
<script src="/cyber/js/chart.min.js"></script>
<script src="/cyber/js/moment.min.js"></script>
<script src="/cyber/js/dayjs.min.js"></script>
<script src="/cyber/js/lodash.min.js"></script>
<script src="/cyber/js/aos.js"></script>

<script src="/assets/js/darkmode.js?v=6"></script>
<script src="/assets/js/relogio.js?v=6"></script>
<script src="/assets/js/alerts.js?v=6"></script>


<!-- ================= FALLBACK CHECK ================= -->
<script>
  // SweetAlert2 Fallback
  if (typeof Swal === 'undefined') {
    document.write('<script src="/cyber/js/sweetalert2.all.min.js"><\/script>');
  }
  // QRCode Fallback
  if (typeof QRCode === 'undefined') {
    document.write('<script src="/cyber/js/qrcode.min.js"><\/script>');
  }
  // jQuery Fallback
  if (typeof window.jQuery === 'undefined') {
    document.write('<script src="/cyber/js/jquery-3.7.1.min.js"><\/script>');
  }
  // Bootstrap Bundle Fallback
  if (typeof bootstrap === 'undefined') {
    document.write('<script src="/cyber/js/bootstrap.bundle.min.js"><\/script>');
  }
</script>