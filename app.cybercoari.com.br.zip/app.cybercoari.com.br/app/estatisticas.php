<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

// Função formatarData - adicionada diretamente para garantir que exista
if (!function_exists('formatarData')) {
    function formatarData($data, $formato = 'd/m/Y H:i') {
        if (empty($data) || $data == '0000-00-00 00:00:00') {
            return '';
        }
        
        try {
            $date = new DateTime($data);
            return $date->format($formato);
        } catch (Exception $e) {
            return $data; // Retorna a data original em caso de erro
        }
    }
}

// Buscar estatísticas
try {
    // Estatísticas gerais
    $total_apps = $pdo->query("SELECT COUNT(*) as total FROM apps")->fetchColumn();
    $total_downloads = $pdo->query("SELECT COUNT(*) as total FROM downloads")->fetchColumn();
    
    // Apps mais baixados
    $stmt = $pdo->query("
        SELECT a.id, a.nome, a.icone, COUNT(d.id) as total_downloads 
        FROM apps a 
        LEFT JOIN downloads d ON a.id = d.app_id 
        GROUP BY a.id 
        ORDER BY total_downloads DESC 
        LIMIT 10
    ");
    $apps_mais_baixados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Downloads por dia (últimos 30 dias)
    $stmt = $pdo->query("
        SELECT DATE(data_download) as data, COUNT(*) as total 
        FROM downloads 
        WHERE data_download >= DATE_SUB(NOW(), INTERVAL 30 DAY) 
        GROUP BY DATE(data_download) 
        ORDER BY data DESC
    ");
    $downloads_por_dia = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Últimos downloads
    $stmt = $pdo->query("
        SELECT d.*, a.nome as app_nome 
        FROM downloads d 
        JOIN apps a ON d.app_id = a.id 
        ORDER BY d.data_download DESC 
        LIMIT 10
    ");
    $ultimos_downloads = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Apps recentes
    $stmt = $pdo->query("SELECT * FROM apps ORDER BY criado_em DESC LIMIT 5");
    $apps_recentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $erro = "Erro ao carregar estatísticas: " . $e->getMessage();
    $total_apps = $total_downloads = 0;
    $apps_mais_baixados = $downloads_por_dia = $ultimos_downloads = $apps_recentes = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estatísticas - Sistema de Apps</title>
    <?php include __DIR__ . "/../includes/cdn.php"; ?> 
    
    <!-- Bootstrap CSS -->
    <!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">-->
    <!-- Bootstrap Icons -->
    <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">-->
    <!-- Chart.js -->
    <!--<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>-->
    
    <style>
        .stat-card {
            transition: transform 0.3s ease;
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 0;
        }
        .stat-icon {
            font-size: 3rem;
            opacity: 0.7;
        }
        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .app-icon-sm {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 8px;
        }
        .progress {
            height: 10px;
            border-radius: 5px;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(0,0,0,0.02);
        }
        .bg-gradient-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .bg-gradient-success {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        .bg-gradient-warning {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        .bg-gradient-info {
            background: linear-gradient(135deg, #4ecdc4 0%, #44a08d 100%);
        }
    </style>
</head>
<body>
    <?php include __DIR__ . "/../includes/header.php"; ?>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="bi bi-phone"></i> AppManager
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_apps.php">Apps</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cadastrar_app.php">Cadastrar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="estatisticas.php">Estatísticas</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <!-- Header -->
        <div class="row mb-5">
            <div class="col-12">
                <h1 class="display-4 fw-bold text-center">
                    <i class="bi bi-graph-up-arrow"></i> Estatísticas do Sistema
                </h1>
                <p class="text-muted text-center">Acompanhe o desempenho e uso dos seus aplicativos</p>
                
                <div class="text-center mb-4">
                    <a href="index.php" class="btn btn-outline-primary me-2">
                        <i class="bi bi-house"></i> Início
                    </a>
                    <a href="lista_apps.php" class="btn btn-primary">
                        <i class="bi bi-list-ul"></i> Ver Todos os Apps
                    </a>
                </div>
            </div>
        </div>

        <?php if (isset($erro)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <!-- Estatísticas Gerais -->
        <div class="row mb-5">
            <div class="col-md-3 mb-4">
                <div class="card stat-card text-white bg-gradient-primary">
                    <div class="card-body text-center">
                        <i class="bi bi-phone stat-icon"></i>
                        <h2 class="stat-number"><?= $total_apps ?></h2>
                        <p class="card-text">Apps Cadastrados</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="card stat-card text-white bg-gradient-success">
                    <div class="card-body text-center">
                        <i class="bi bi-download stat-icon"></i>
                        <h2 class="stat-number"><?= $total_downloads ?></h2>
                        <p class="card-text">Downloads Totais</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="card stat-card text-white bg-gradient-warning">
                    <div class="card-body text-center">
                        <i class="bi bi-calendar-check stat-icon"></i>
                        <h2 class="stat-number"><?= count($downloads_por_dia) ?></h2>
                        <p class="card-text">Dias com Downloads</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="card stat-card text-white bg-gradient-info">
                    <div class="card-body text-center">
                        <i class="bi bi-star stat-icon"></i>
                        <h2 class="stat-number">
                            <?= $apps_mais_baixados[0]['total_downloads'] ?? 0 ?>
                        </h2>
                        <p class="card-text">Downloads do App Mais Popular</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Gráfico de Downloads -->
            <div class="col-lg-8 mb-4">
                <div class="chart-container">
                    <h4 class="mb-4">
                        <i class="bi bi-bar-chart"></i> Downloads nos Últimos 30 Dias
                    </h4>
                    <canvas id="downloadsChart" height="250"></canvas>
                </div>
            </div>

            <!-- Apps Mais Baixados -->
            <div class="col-lg-4 mb-4">
                <div class="chart-container">
                    <h4 class="mb-4">
                        <i class="bi bi-trophy"></i> Top 5 Apps Mais Baixados
                    </h4>
                    <?php if (!empty($apps_mais_baixados)): ?>
                        <?php 
                        $max_downloads = max(array_column($apps_mais_baixados, 'total_downloads'));
                        $top_5 = array_slice($apps_mais_baixados, 0, 5);
                        ?>
                        <?php foreach($top_5 as $index => $app): ?>
                            <div class="d-flex align-items-center mb-3">
                                <?php if ($app['icone']): ?>
                                    <img src="<?= htmlspecialchars($app['icone']) ?>" 
                                         alt="Ícone" 
                                         class="app-icon-sm me-3">
                                <?php else: ?>
                                    <div class="app-icon-sm bg-secondary rounded d-flex align-items-center justify-content-center me-3">
                                        <i class="bi bi-phone text-white"></i>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between">
                                        <strong><?= htmlspecialchars($app['nome']) ?></strong>
                                        <span class="badge bg-primary"><?= $app['total_downloads'] ?> downloads</span>
                                    </div>
                                    <div class="progress mt-1">
                                        <div class="progress-bar bg-success" 
                                             style="width: <?= $max_downloads > 0 ? ($app['total_downloads'] / $max_downloads) * 100 : 0 ?>%">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted">Nenhum download registrado ainda.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Últimos Downloads -->
            <div class="col-lg-6 mb-4">
                <div class="chart-container">
                    <h4 class="mb-4">
                        <i class="bi bi-clock-history"></i> Últimos Downloads
                    </h4>
                    <?php if (!empty($ultimos_downloads)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>App</th>
                                        <th>Data</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($ultimos_downloads as $download): ?>
                                        <tr>
                                            <td>
                                                <strong><?= htmlspecialchars($download['app_nome']) ?></strong>
                                            </td>
                                            <td>
                                                <?= formatarData($download['data_download'], 'd/m/Y H:i') ?>
                                            </td>
                                            <td>
                                                <small class="text-muted"><?= htmlspecialchars($download['ip_address']) ?></small>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Nenhum download registrado ainda.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Apps Recentes -->
            <div class="col-lg-6 mb-4">
                <div class="chart-container">
                    <h4 class="mb-4">
                        <i class="bi bi-plus-circle"></i> Apps Recentes
                    </h4>
                    <?php if (!empty($apps_recentes)): ?>
                        <div class="list-group">
                            <?php foreach($apps_recentes as $app): ?>
                                <a href="editar_app.php?id=<?= $app['id'] ?>" 
                                   class="list-group-item list-group-item-action d-flex align-items-center">
                                    <?php if ($app['icone']): ?>
                                        <img src="<?= htmlspecialchars($app['icone']) ?>" 
                                             alt="Ícone" 
                                             class="app-icon-sm me-3">
                                    <?php else: ?>
                                        <div class="app-icon-sm bg-secondary rounded d-flex align-items-center justify-content-center me-3">
                                            <i class="bi bi-phone text-white"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <h6 class="mb-1"><?= htmlspecialchars($app['nome']) ?></h6>
                                        <small class="text-muted">
                                            Criado em: <?= formatarData($app['criado_em'], 'd/m/Y') ?>
                                        </small>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Nenhum app cadastrado ainda.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Botões de Ação -->
        <div class="row mt-4">
            <div class="col-12 text-center">
                <div class="d-flex gap-2 justify-content-center flex-wrap">
                    <a href="cadastrar_app.php" class="btn btn-success btn-lg">
                        <i class="bi bi-plus-circle"></i> Cadastrar Novo App
                    </a>
                    <a href="lista_apps.php" class="btn btn-primary btn-lg">
                        <i class="bi bi-list-ul"></i> Ver Lista Completa
                    </a>
                    <button onclick="window.print()" class="btn btn-outline-secondary btn-lg">
                        <i class="bi bi-printer"></i> Imprimir Relatório
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="bi bi-phone"></i> AppManager</h5>
                    <p class="mb-0">Sistema de gerenciamento de aplicativos</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0">
                        <i class="bi bi-clock"></i> 
                        Última atualização: <?= date('d/m/Y H:i:s') ?>
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include __DIR__ . "/../includes/footer.php"; ?>
    
    <script>
        // Gráfico de downloads
        const downloadsCtx = document.getElementById('downloadsChart').getContext('2d');
        
        <?php if (!empty($downloads_por_dia)): ?>
            const downloadsData = {
                labels: [
                    <?php 
                    $labels = array_map(function($item) {
                        return "'" . date('d/m', strtotime($item['data'])) . "'";
                    }, array_reverse($downloads_por_dia));
                    echo implode(', ', $labels);
                    ?>
                ],
                datasets: [{
                    label: 'Downloads por Dia',
                    data: [
                        <?php 
                        $values = array_map(function($item) {
                            return $item['total'];
                        }, array_reverse($downloads_por_dia));
                        echo implode(', ', $values);
                        ?>
                    ],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                }]
            };
        <?php else: ?>
            const downloadsData = {
                labels: ['Nenhum dado'],
                datasets: [{
                    label: 'Downloads por Dia',
                    data: [0],
                    backgroundColor: 'rgba(200, 200, 200, 0.2)',
                    borderColor: 'rgba(200, 200, 200, 1)',
                    borderWidth: 2
                }]
            };
        <?php endif; ?>

        const downloadsChart = new Chart(downloadsCtx, {
            type: 'line',
            data: downloadsData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // Atualizar página a cada 5 minutos
        setTimeout(() => {
            window.location.reload();
        }, 300000); // 5 minutos
    </script>
</body>
</html>