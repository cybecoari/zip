<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $link_download = trim($_POST['link_download'] ?? '');
    $icone = trim($_POST['icone'] ?? '');

    // Validações
    if (empty($nome)) {
        $erro = 'O nome do app é obrigatório.';
    } elseif (empty($link_download)) {
        $erro = 'O link de download é obrigatório.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO apps (nome, descricao, link_download, icone, criado_em) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$nome, $descricao, $link_download, $icone]);
            
            $sucesso = 'App cadastrado com sucesso!';
            // Limpar campos após sucesso
            $nome = $descricao = $link_download = $icone = '';
        } catch (PDOException $e) {
            $erro = 'Erro ao cadastrar app: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar App - Sistema</title>
    <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/cdn.php'; ?>
    
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        textarea {
            height: 120px;
            resize: vertical;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        .alert {
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php'; ?>

<div class="container">
    <div class="form-container">
        <h1>Cadastrar Novo App</h1>
        
        <?php if ($sucesso): ?>
            <div class="alert alert-success"><?= htmlspecialchars($sucesso) ?></div>
        <?php endif; ?>
        
        <?php if ($erro): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="nome">Nome do App *</label>
                <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($nome ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label for="descricao">Descrição</label>
                <textarea id="descricao" name="descricao"><?= htmlspecialchars($descricao ?? '') ?></textarea>
            </div>

            <div class="form-group">
                <label for="link_download">Link de Download *</label>
                <input type="text" id="link_download" name="link_download" value="<?= htmlspecialchars($link_download ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label for="icone">URL do Ícone</label>
                <input type="text" id="icone" name="icone" value="<?= htmlspecialchars($icone ?? '') ?>" placeholder="https://exemplo.com/icone.png">
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary">Cadastrar App</button>
                <a href="lista_apps.php" class="btn btn-secondary">Voltar para Lista</a>
            </div>
        </form>
    </div>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
</body>
</html>