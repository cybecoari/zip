<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

// Verificar se o ID foi passado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: lista_apps.php');
    exit;
}

$id = (int)$_GET['id'];

try {
    // Buscar informações do app
    $stmt = $pdo->prepare("SELECT * FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$app) {
        die('App não encontrado.');
    }
    
    // Registrar o download
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Desconhecido';
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Desconhecido';
    
    $stmt = $pdo->prepare("INSERT INTO downloads (app_id, user_agent, ip_address, data_download) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$id, $user_agent, $ip_address]);
    
    // Redirecionar para o link de download
    header('Location: ' . $app['link_download']);
    exit;
    
} catch (PDOException $e) {
    die('Erro ao registrar download: ' . $e->getMessage());
}
?>