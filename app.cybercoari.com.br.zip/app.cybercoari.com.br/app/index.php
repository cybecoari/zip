<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gerenciamento de Apps</title>
    
    <?php include __DIR__ . "/../includes/cdn.php"; ?>
    
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
            margin-bottom: 50px;
        }
        .feature-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            border-radius: 15px;
            overflow: hidden;
        }
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        .card-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        .stats-section {
            background-color: #f8f9fa;
            padding: 60px 0;
        }
        .stat-number {
            font-size: 3rem;
            font-weight: bold;
            color: #667eea;
        }
        .btn-custom {
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 50px;
            transition: all 0.3s ease;
        }
        .btn-primary-custom {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
    </style>
</head>
<body>
    <?php include __DIR__ . "/../includes/header.php"; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">Sistema de Gerenciamento de Apps</h1>
                    <p class="lead mb-4">Gerencie seus aplicativos de forma simples e eficiente. Cadastre, edite e acompanhe todos os seus apps em um só lugar.</p>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="lista_apps.php" class="btn btn-light btn-custom">
                            <i class="bi bi-grid-3x3-gap"></i> Ver Todos os Apps
                        </a>
                        <a href="cadastrar_app.php" class="btn btn-outline-light btn-custom">
                            <i class="bi bi-plus-circle"></i> Novo App
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <img src="https://cdn-icons-png.flaticon.com/512/3159/3159310.png" alt="App Management" class="img-fluid" style="max-height: 300px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Actions -->
    <section class="container mb-5">
        <div class="row text-center mb-5">
            <div class="col-12">
                <h2 class="fw-bold">Acesso Rápido</h2>
                <p class="text-muted">Navegue rapidamente pelas principais funcionalidades do sistema</p>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card feature-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="card-icon text-primary">
                            <i class="bi bi-grid-3x3-gap"></i>
                        </div>
                        <h4 class="card-title fw-bold">Lista de Apps</h4>
                        <p class="card-text text-muted">Visualize todos os aplicativos cadastrados no sistema com informações detalhadas.</p>
                        <a href="lista_apps.php" class="btn btn-primary-custom btn-custom w-100">
                            <i class="bi bi-arrow-right"></i> Acessar Lista
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card feature-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="card-icon text-success">
                            <i class="bi bi-plus-circle"></i>
                        </div>
                        <h4 class="card-title fw-bold">Cadastrar App</h4>
                        <p class="card-text text-muted">Adicione novos aplicativos ao sistema com nome, descrição e link de download.</p>
                        <a href="cadastrar_app.php" class="btn btn-success btn-custom w-100">
                            <i class="bi bi-plus-lg"></i> Novo Cadastro
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card feature-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="card-icon text-warning">
                            <i class="bi bi-graph-up"></i>
                        </div>
                        <h4 class="card-title fw-bold">Estatísticas</h4>
                        <p class="card-text text-muted">Acompanhe métricas e relatórios dos aplicativos mais baixados.</p>
                        <a href="estatisticas.php" class="btn btn-warning btn-custom w-100">
                            <i class="bi bi-bar-chart"></i> Ver Estatísticas
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include __DIR__ . "/../includes/footer.php"; ?>
</body>
</html>