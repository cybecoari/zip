<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

// Verificar se o ID foi passado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: lista_apps.php');
    exit;
}

$id = (int)$_GET['id'];

try {
    // Verificar se o app existe
    $stmt = $pdo->prepare("SELECT * FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$app) {
        $_SESSION['erro'] = 'App não encontrado.';
        header('Location: lista_apps.php');
        exit;
    }
    
    // Excluir o app
    $stmt = $pdo->prepare("DELETE FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    
    $_SESSION['sucesso'] = 'App excluído com sucesso!';
    
} catch (PDOException $e) {
    $_SESSION['erro'] = 'Erro ao excluir app: ' . $e->getMessage();
}

header('Location: lista_apps.php');
exit;
?>