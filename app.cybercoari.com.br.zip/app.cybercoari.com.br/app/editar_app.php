<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

$erro = '';
$sucesso = '';

// Verificar se o ID foi passado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: lista_apps.php');
    exit;
}

$id = (int)$_GET['id'];

// Buscar app existente
try {
    $stmt = $pdo->prepare("SELECT * FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$app) {
        $erro = 'App não encontrado.';
    }
} catch (PDOException $e) {
    $erro = 'Erro ao carregar app: ' . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$erro) {
    $nome = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $link_download = trim($_POST['link_download'] ?? '');
    $icone = trim($_POST['icone'] ?? '');

    // Validações
    if (empty($nome)) {
        $erro = 'O nome do app é obrigatório.';
    } elseif (empty($link_download)) {
        $erro = 'O link de download é obrigatório.';
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE apps SET nome = ?, descricao = ?, link_download = ?, icone = ?, atualizado_em = NOW() WHERE id = ?");
            $stmt->execute([$nome, $descricao, $link_download, $icone, $id]);
            
            $sucesso = 'App atualizado com sucesso!';
            // Atualizar dados locais
            $app = array_merge($app, [
                'nome' => $nome,
                'descricao' => $descricao,
                'link_download' => $link_download,
                'icone' => $icone
            ]);
        } catch (PDOException $e) {
            $erro = 'Erro ao atualizar app: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar App - Sistema</title>
    <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/cdn.php'; ?>
    
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        textarea {
            height: 120px;
            resize: vertical;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .alert {
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .preview-icone {
            max-width: 100px;
            max-height: 100px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php'; ?>

<div class="container">
    <div class="form-container">
        <h1>Editar App</h1>
        
        <?php if ($erro && !$app): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
            <a href="lista_apps.php" class="btn btn-secondary">Voltar para Lista</a>
        <?php else: ?>
            
            <?php if ($sucesso): ?>
                <div class="alert alert-success"><?= htmlspecialchars($sucesso) ?></div>
            <?php endif; ?>
            
            <?php if ($erro): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="nome">Nome do App *</label>
                    <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($app['nome']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <textarea id="descricao" name="descricao"><?= htmlspecialchars($app['descricao']) ?></textarea>
                </div>

                <div class="form-group">
                    <label for="link_download">Link de Download *</label>
                    <input type="text" id="link_download" name="link_download" value="<?= htmlspecialchars($app['link_download']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="icone">URL do Ícone</label>
                    <input type="text" id="icone" name="icone" value="<?= htmlspecialchars($app['icone']) ?>" placeholder="https://exemplo.com/icone.png">
                    <?php if ($app['icone']): ?>
                        <div>
                            <strong>Preview:</strong><br>
                            <img src="<?= htmlspecialchars($app['icone']) ?>" alt="Ícone atual" class="preview-icone" onerror="this.style.display='none'">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Atualizar App</button>
                    <a href="lista_apps.php" class="btn btn-secondary">Voltar para Lista</a>
                    <a href="excluir_app.php?id=<?= $app['id'] ?>" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja excluir este app?')">Excluir App</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
</body>
</html>