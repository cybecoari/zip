<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/sessao.php';
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/funcoes.php';

// Verificar permissões (se necessário)
// if (!usuarioLogado() || !temPermissao('visualizar_apps')) {
//     header('Location: /login.php');
//     exit;
// }

try {
    // Busca todos os apps com tratamento de erro
    $stmt = $pdo->query("SELECT * FROM apps ORDER BY criado_em DESC");
    $apps = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $erro = "Erro ao carregar aplicativos: " . $e->getMessage();
    $apps = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Apps - Sistema</title>

    <!-- CDN de CSS/JS -->
    <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/cdn.php'; ?>
    
    <style>
        .table-container {
            overflow-x: auto;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .table th, .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .table tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-warning {
            background-color: #ffc107;
            color: #212529;
        }
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        .icon-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 8px;
        }
        .no-link {
            color: #dc3545;
            font-style: italic;
        }
        .actions {
            white-space: nowrap;
        }
    </style>
</head>
<body>
<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php'; ?>

<div class="container">
    <h1>Lista de Apps</h1>
    
    <?php if (isset($erro)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>
    
    <div class="mb-3">
        <a href="cadastrar_app.php" class="btn btn-primary">Adicionar Novo App</a>
    </div>

    <?php if (empty($apps)): ?>
        <div class="alert alert-info">
            Nenhum aplicativo cadastrado ainda. <a href="cadastrar_app.php">Clique aqui</a> para adicionar o primeiro.
        </div>
    <?php else: ?>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Download</th>
                        <th>Ícone</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($apps as $app): ?>
                    <tr>
                        <td><?= htmlspecialchars($app['id']) ?></td>
                        <td>
                            <strong><?= htmlspecialchars($app['nome']) ?></strong>
                        </td>
                        <td>
                            <?= htmlspecialchars(
                                strlen($app['descricao']) > 100 
                                ? substr($app['descricao'], 0, 100) . '...' 
                                : $app['descricao']
                            ) ?>
                        </td>
                        <td>
                            <?php if($app['link_download']): ?>
                                <a href="<?= htmlspecialchars($app['link_download']) ?>" 
                                   target="_blank" 
                                   class="btn btn-success btn-sm">
                                    Baixar
                                </a>
                            <?php else: ?>
                                <span class="no-link">Sem link</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($app['icone']): ?>
                                <img src="<?= htmlspecialchars($app['icone']) ?>" 
                                     alt="Ícone do app <?= htmlspecialchars($app['nome']) ?>" 
                                     class="icon-img">
                            <?php else: ?>
                                <span class="text-muted">Sem ícone</span>
                            <?php endif; ?>
                        </td>
                        <td class="actions">
                            <a href="editar_app.php?id=<?= $app['id'] ?>" 
                               class="btn btn-warning btn-sm">
                                Editar
                            </a>
                            <a href="download_app.php?id=<?= $app['id'] ?>" 
                               class="btn btn-primary btn-sm">
                                Registrar Download
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
</body>
</html>