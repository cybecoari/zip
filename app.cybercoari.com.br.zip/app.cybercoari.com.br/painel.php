<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config/conexao.php';
require_once __DIR__ . '/config/funcoes.php';
require_once __DIR__ . '/config/debug.php';

checkLogin();
$usuario = getUsuario($pdo);
if (!$usuario) {
    session_unset();
    session_destroy();
    header("Location: /login.php?msg=not_logged");
    exit;
}

// Atualiza atividade
registrarOnline($pdo, $usuario['id']);

// Só busca usuários se for admin
$usuarios = [];
if (isAdmin()) {
    try {
        $stmt = $pdo->query("SELECT * FROM usuarios ORDER BY id ASC");
        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (PDOException $e) {
        error_log("Erro ao buscar usuários: " . $e->getMessage());
    }
}

// Tema vem do banco e sincroniza com a sessão
$tema = $usuario['tema'] ?? 'claro';
$_SESSION['tema'] = $tema;

// Totais
$totalCadastros = getTotalCadastros($pdo);
$onlineInfo     = getUsuariosOnlineInfo($pdo);

// Fundação do site
$fundacao = function_exists('getDiasFundacao') ? getDiasFundacao($pdo) : null;

// Flash messages
$flashMessage = "";
$flashType = "";
if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case 'excluido':
            $flashMessage = "Usuário excluído com sucesso!";
            $flashType = "success";
            break;
        case 'erro':
            $flashMessage = "Ocorreu um erro. Tente novamente.";
            $flashType = "error";
            break;
    }
}

$title = "Painel Administrativo";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($title) ?></title>
  <?php include __DIR__ . '/includes/cdn.php'; ?>
  <link rel="stylesheet" href="/assets/css/darkmode.css?v=5">
</head>
<body 
    class="<?= $tema === 'escuro' ? 'dark-mode' : 'bg-light'; ?>"
    data-flash-message="<?= htmlspecialchars($flashMessage) ?>"
    data-flash-type="<?= htmlspecialchars($flashType) ?>"
>
  <?php include __DIR__ . '/includes/navbar.php'; ?>

  <!-- Conteúdo principal -->
  <div class="container mb-2 py-2 text-center">
      <?php if ($fundacao): ?>
          <p><strong>Site Online há <?= $fundacao['dias'] ?> dias</strong></p>
      <?php endif; ?>
  </div>

  <!-- Usuários Online -->
  <div class="container">
    <div class="card shadow-sm mb-3" style="border-radius:12px;">
      <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-people-fill"></i> Usuários Online</span>
        <span class="badge bg-light text-success"><?= e($onlineInfo['total']); ?></span>
      </div>
      <div class="card-body">
        <?php if (!empty($onlineInfo['lista'])): ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($onlineInfo['lista'] as $u): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center">
                <span><i class="bi bi-person-circle"></i> <?= e($u['usuario']); ?></span>
                <small class="text-muted"><?= date("H:i", strtotime($u['ultima_atividade'])); ?></small>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="text-muted mb-0">Nenhum usuário online agora.</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Lista de Usuários (somente Admin) -->
  <?php if (isAdmin()): ?>
  <div class="container py-4">
    <div class="table-responsive">
      <table class="table table-bordered table-striped table-hover rounded">
          <thead>
              <tr>
                  <th>ID</th>
                  <th>Usuário</th>
                  <th>Email</th>
                  <th>Nível</th>
                  <th>Tema</th>
                  <th>Data Fundação</th>
                  <th>Último Login</th>
                  <th>Ações</th>
              </tr>
          </thead>
          <tbody>
          <?php foreach ($usuarios as $u): ?>
              <tr>
                  <td><?= $u['id'] ?></td>
                  <td><?= htmlspecialchars($u['usuario']) ?></td>
                  <td><?= htmlspecialchars($u['email']) ?></td>
                  <td>
                      <?= match ($u['nivel']) {
                          1 => "Administrador",
                          2 => "Usuário",
                          3 => "SuperAdmin",
                          default => "?"
                      }; ?>
                  </td>
                  <td><?= htmlspecialchars($u['tema']) ?></td>
                  <td><?= $u['data_fundacao'] ? date("d/m/Y", strtotime($u['data_fundacao'])) : '-' ?></td>
                  <td><?= $u['ultimo_login'] ?: '-' ?></td>
                  <td>
                      <a href="admin/editar_usuario.php?id=<?= $u['id'] ?>" class="btn btn-primary btn-sm">Editar</a>
                      <a href="admin/excluir_usuario.php?id=<?= $u['id'] ?>" 
                         class="btn btn-danger btn-sm"
                         onclick="return confirm('Tem certeza que deseja excluir este usuário?');">
                         Excluir
                      </a>
                  </td>
              </tr>
          <?php endforeach; ?>
          </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
<?php include __DIR__ . "/includes/footer.php"; ?>
</body>
</html>