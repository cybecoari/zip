<?php
// 🔧 Mostrar erros no ambiente de testes
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 🔐 Sessão com mais segurança
session_start([
    'cookie_httponly' => true,
    'cookie_secure'   => isset($_SERVER['HTTPS']), // só HTTPS
    'cookie_samesite' => 'Strict'
]);

require_once __DIR__ . "/config/conexao.php";
require_once __DIR__ . "/config/funcoes.php";
require_once __DIR__ . "/config/debug.php";

// ✄1�7 Se já estiver logado, vai para o painel
if (!empty($_SESSION['usuario_id'])) {
    header("Location: /painel.php");
    exit;
}

$erro = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? "");
    $senha   = $_POST['senha'] ?? "";

    if ($usuario && $senha) {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE usuario = ? LIMIT 1");
        $stmt->execute([$usuario]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && !empty($user['senha']) && password_verify($senha, $user['senha'])) {
            // Criar sessão
            $_SESSION['usuario_id']    = $user['id'];
            $_SESSION['usuario_nivel'] = $user['nivel'];
            $_SESSION['tema']          = $user['tema'] ?? 'claro';

            // Registrar login
            $stmt = $pdo->prepare("UPDATE usuarios SET ultimo_login = NOW() WHERE id = ?");
            $stmt->execute([$user['id']]);

            header("Location: /painel.php");
            exit;
        } else {
            $erro = "Usuário ou senha inválidos.";
        }
    } else {
        $erro = "Preencha todos os campos.";
    }
}


// Tema vem do banco e sincroniza com a sess�0�0o
$tema = $usuario['tema'] ?? 'claro';
$_SESSION['tema'] = $tema;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">

<title>Login - Sistema</title>
<?php include __DIR__ . "/includes/cdn.php"; ?>
</head>
<body class="<?= $tema === 'escuro' ? 'bg-dark text-white' : 'bg-light' ?>">

<div class="container d-flex align-items-center justify-content-center vh-100">
  <div class="card shadow-sm p-4" style="max-width:400px; width:100%; border-radius:12px;">
    
    <h3 class="mb-3 text-center">🔑 Login</h3>

    <?php if ($erro): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <form method="post" action="">
      <div class="mb-3">
        <label for="usuario" class="form-label">Usuário</label>
        <input type="text" name="usuario" id="usuario" class="form-control" required autofocus>
      </div>
      <div class="mb-3">
        <label for="senha" class="form-label">Senha</label>
        <input type="password" name="senha" id="senha" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-success w-100">Entrar</button>
    </form>

    <div class="mt-3 text-center">
    <a href="/"> Voltar ao site</a>
    <?php include __DIR__ . "/includes/footer.php"; ?>
    </div>
  </div>
</div>
<script src="/assets/js/darkmode.js?v=6"></script>
<script src="/assets/js/darkmode.js"></script>
<script src="/assets/js/relogio.js"></script>
</body>
</html>