<?php
require_once __DIR__ . '/../functions.php';
$pdo = pdo();
$user = require_admin();
$config = require __DIR__ . '/../config.php';
ensure_uploads();

$id = intval($_GET['id'] ?? 0);
if(!$id){ header('Location: /admin/dashboard.php'); exit; }

$stmt = $pdo->prepare('SELECT * FROM apps WHERE id = ?');
$stmt->execute([$id]);
$app = $stmt->fetch();
if(!$app){ echo 'App não encontrado'; exit; }

$err = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $title = trim($_POST['title'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $version = trim($_POST['version'] ?? '');
  $package_name = trim($_POST['package_name'] ?? '');

  if(!$title){ $err = 'Título requerido.'; }
  else {
    $logo_path_public = $app['logo_path'];
    // atualizar logo se enviado
    if(isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK){
      $l = $_FILES['logo'];
      $ln = time() . '-logo-' . preg_replace('/[^a-zA-Z0-9._-]/', '-', $l['name']);
      $ldst = $config['uploads_dir'] . '/' . $ln;
      if(move_uploaded_file($l['tmp_name'], $ldst)){
        $logo_path_public = rtrim($config['uploads_url'], '/') . '/' . $ln;
        // opcional: remover logo antiga do servidor
        if($app['logo_path']){
          $old = $_SERVER['DOCUMENT_ROOT'] . $app['logo_path'];
          if(file_exists($old)) @unlink($old);
        }
      }
    }

    // atualizar arquivo do app se enviado
    $file_path_public = $app['file_path'];
    if(isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK){
      $f = $_FILES['file'];
      $fn = time() . '-' . preg_replace('/[^a-zA-Z0-9._-]/', '-', $f['name']);
      $fdst = $config['uploads_dir'] . '/' . $fn;
      if(move_uploaded_file($f['tmp_name'], $fdst)){
        $file_path_public = rtrim($config['uploads_url'], '/') . '/' . $fn;
        if($app['file_path']){
          $oldf = $_SERVER['DOCUMENT_ROOT'] . $app['file_path'];
          if(file_exists($oldf)) @unlink($oldf);
        }
      }
    }

    $stmt = $pdo->prepare('UPDATE apps SET title=?,description=?,package_name=?,version=?,file_path=?,logo_path=? WHERE id=?');
    $stmt->execute([$title,$description,$package_name,$version,$file_path_public,$logo_path_public,$id]);
    $success = 'App atualizado.';
    // recarregar dados
    $stmt = $pdo->prepare('SELECT * FROM apps WHERE id = ?'); $stmt->execute([$id]); $app = $stmt->fetch();
  }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Editar App</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.container { max-width: 600px; margin: 0 auto; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
h2 { margin-bottom: 20px; color: #333; border-bottom: 2px solid #007BFF; padding-bottom: 10px; }
label { display: block; margin-bottom: 10px; font-weight: bold; }
input[type="text"], textarea, input[type="file"] { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 15px; }
textarea { resize: vertical; min-height: 100px; }
.msg { padding: 12px; margin-bottom: 15px; border-radius: 4px; }
.err { background-color: #f8d7da; color: #842029; border: 1px solid #f5c6cb; }
.success { background-color: #d1e7dd; color: #0f5132; border: 1px solid #c3e6cb; }
.btn { padding: 12px 20px; background-color: #007BFF; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; margin-right: 10px; }
.btn:hover { background-color: #0056b3; }
.btn-secondary { background-color: #6c757d; }
.btn-secondary:hover { background-color: #545b62; }
.current-file { background: #f8f9fa; padding: 10px; border-radius: 4px; margin: 10px 0; border: 1px solid #ddd; }
.file-info { font-size: 0.9rem; color: #666; margin-bottom: 5px; }
.preview img { border: 1px solid #ddd; border-radius: 8px; max-width: 200px; }
</style>
</head>
<body>
<div class="container">
<h2>✏️ Editar App</h2>

<?php if($err): ?>
<div class="msg err">❌ <?=h($err)?></div>
<?php endif; ?>

<?php if($success): ?>
<div class="msg success">✅ <?=h($success)?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <label>Título: <input name="title" value="<?=h($app['title'])?>" required></label>
  
  <label>Descrição:<br><textarea name="description" rows="4"><?=h($app['description'])?></textarea></label>
  
  <label>Package name: <input name="package_name" value="<?=h($app['package_name'])?>"></label>
  
  <label>Versão: <input name="version" value="<?=h($app['version'])?>"></label>

  <div class="current-file">
    <strong>Logo atual:</strong>
    <?php if($app['logo_path']): ?>
      <div class="preview"><img src="<?=h($app['logo_path'])?>" width="100" alt="logo"></div>
    <?php else: ?>
      <div class="file-info">Nenhum logo definido</div>
    <?php endif; ?>
  </div>

  <label>Trocar logo (opcional): <input type="file" name="logo" accept="image/*"></label>
  
  <div class="current-file">
    <strong>Arquivo do app atual:</strong>
    <?php if($app['file_path']): ?>
      <div class="file-info">📦 <?=h(basename($app['file_path']))?></div>
      <div class="file-info">⬇️ Downloads: <?=intval($app['downloads'])?></div>
      <a href="<?=h($app['file_path'])?>" download class="btn btn-secondary" style="padding: 8px 12px; font-size: 14px;">📥 Baixar arquivo atual</a>
    <?php else: ?>
      <div class="file-info">Nenhum arquivo definido</div>
    <?php endif; ?>
  </div>

  <label>Substituir arquivo do app (opcional): <input type="file" name="file" accept=".apk,.zip,application/zip,application/vnd.android.package-archive"></label>

  <div style="margin-top: 20px;">
    <button type="submit" class="btn">💾 Salvar Alterações</button>
    <a href="/admin/dashboard.php" class="btn btn-secondary">← Voltar</a>
  </div>
</form>
</div>
</body>
</html>