<?php
require_once __DIR__ . '/../functions.php';
$pdo = pdo();
$user = require_admin();
ensure_uploads();
$config = require __DIR__ . '/../config.php';

$err = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $version = trim($_POST['version'] ?? '');
    $package_name = trim($_POST['package_name'] ?? '');

    if(!$title || !isset($_FILES['file'])){
        $err = 'Título e arquivo do app são obrigatórios.';
    } else {
        $file = $_FILES['file'];
        if($file['error'] !== UPLOAD_ERR_OK){
            $err = 'Erro no upload do arquivo do app.';
        } else {
            $fn = time() . '-' . preg_replace('/[^a-zA-Z0-9._-]/', '-', $file['name']);
            $dst = $config['uploads_dir'] . '/' . $fn;
            if(!move_uploaded_file($file['tmp_name'], $dst)){
                $err = 'Falha ao salvar arquivo do app.';
            } else {
                $file_path_public = rtrim($config['uploads_url'], '/') . '/' . $fn;

                // logo (opcional)
                $logo_path_public = null;
                if(isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK){
                    $l = $_FILES['logo'];
                    $ln = time() . '-logo-' . preg_replace('/[^a-zA-Z0-9._-]/', '-', $l['name']);
                    $ldst = $config['uploads_dir'] . '/' . $ln;
                    if(move_uploaded_file($l['tmp_name'], $ldst)){
                        $logo_path_public = rtrim($config['uploads_url'], '/') . '/' . $ln;
                    }
                }

                $stmt = $pdo->prepare('INSERT INTO apps (title,description,package_name,version,file_path,logo_path,uploaded_by) VALUES (?,?,?,?,?,?,?)');
                $stmt->execute([$title,$description,$package_name,$version,$file_path_public,$logo_path_public,$user['id']]);
                $success = 'App enviado com sucesso.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Enviar App</title>
<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    h2 { margin-bottom: 15px; }
    form { max-width: 500px; margin: 0 auto; }
    label { display: block; margin-bottom: 10px; }
    input[type="text"], textarea, input[type="file"] { width: 100%; padding: 8px; box-sizing: border-box; }
    textarea { resize: vertical; }
    button { padding: 10px 15px; background-color: #007BFF; color: white; border: none; cursor: pointer; }
    button:hover { background-color: #0056b3; }
    .msg { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
    .err { background-color: #f8d7da; color: #842029; }
    .success { background-color: #d1e7dd; color: #0f5132; }
    a { color: #007BFF; text-decoration: none; }
    a:hover { text-decoration: underline; }
</style>
</head>
<body>
<h2>Enviar App</h2>

<?php if($err): ?>
<div class="msg err"><?=h($err)?></div>
<?php endif; ?>

<?php if($success): ?>
<div class="msg success"><?=h($success)?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
    <label>Título: <input type="text" name="title" value="<?=h($_POST['title'] ?? '')?>" required></label>
    <label>Descrição:<br><textarea name="description" rows="4"><?=h($_POST['description'] ?? '')?></textarea></label>
    <label>Package name: <input type="text" name="package_name" value="<?=h($_POST['package_name'] ?? '')?>"></label>
    <label>Versão: <input type="text" name="version" value="<?=h($_POST['version'] ?? '')?>"></label>
    <label>Arquivo do app (APK/ZIP): <input type="file" name="file" accept=".apk,.zip,application/zip,application/vnd.android.package-archive" required></label>
    <label>Logo (opcional): <input type="file" name="logo" accept="image/*"></label>
    <button type="submit">Enviar</button>
</form>

<p><a href="/admin/dashboard.php">Voltar</a></p>
</body>
</html>