<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../functions.php';
$pdo = pdo();
require_admin();

// Token CSRF único para a página
//$csrf_token = csrf_token();

// Paginação para melhor performance com muitos apps
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 50;
$offset = ($page - 1) * $limit;

$stmt = $pdo->prepare('
    SELECT a.*, u.username as uploader 
    FROM apps a 
    LEFT JOIN users u ON a.uploaded_by = u.id 
    ORDER BY a.created_at DESC 
    LIMIT :limit OFFSET :offset
');
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$apps = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Contar total para paginação
$total_stmt = $pdo->query('SELECT COUNT(*) FROM apps');
$total_apps = $total_stmt->fetchColumn();
$total_pages = ceil($total_apps / $limit);
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin</title>
    <style>
        :root {
            --primary-color: #007BFF;
            --border-color: #ddd;
            --hover-color: #0056b3;
        }
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { 
            margin-bottom: 20px; 
            color: #333;
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
        }
        a { 
            text-decoration: none; 
            color: var(--primary-color); 
            transition: color 0.3s;
        }
        a:hover { 
            color: var(--hover-color);
        }
        .top-links { 
            margin-bottom: 25px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        .top-links a {
            padding: 8px 16px;
            border: 1px solid var(--primary-color);
            border-radius: 4px;
            background: white;
        }
        .top-links a:hover {
            background: var(--primary-color);
            color: white;
        }
        table { 
            width: 100%; 
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td { 
            border: 1px solid var(--border-color); 
            padding: 12px; 
            text-align: left; 
        }
        th { 
            background-color: #f8f9fa; 
            font-weight: bold;
        }
        tr:nth-child(even) { 
            background-color: #f8f9fa; 
        }
        tr:hover {
            background-color: #e9ecef;
        }
        .actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        .btn-edit {
            background: #28a745;
            color: white;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        .pagination a, .pagination span {
            padding: 8px 12px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
        }
        .pagination .current {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        @media (max-width: 768px) {
            .container {
                padding: 10px;
                margin: 10px;
            }
            table, thead, tbody, th, td, tr { 
                display: block; 
            }
            thead tr { 
                display: none; 
            }
            td { 
                padding-left: 50%; 
                position: relative; 
                border: none;
                border-bottom: 1px solid var(--border-color);
            }
            td::before {
                content: attr(data-label);
                position: absolute;
                left: 0;
                width: 45%;
                padding-left: 12px;
                font-weight: bold;
                white-space: nowrap;
            }
            .actions {
                justify-content: flex-start;
            }
        }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>📊 Admin Dashboard</h2>
        
        <div class="top-links">
            <a href="/admin/upload.php">📤 Novo App</a>
            <a href="/">🏪 Ver Loja</a>
            <a href="/logout.php" onclick="return confirm('Tem certeza que deseja sair?')">🚪 Sair</a>
        </div>

        <?php if (empty($apps)): ?>
            <div class="empty-state">
                <h3>Nenhum aplicativo encontrado</h3>
                <p>Comece adicionando seu primeiro aplicativo.</p>
                <a href="/admin/upload.php" class="btn btn-edit">Adicionar Primeiro App</a>
            </div>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Título</th>
                            <th>Versão</th>
                            <th>Downloads</th>
                            <th>Uploader</th>
                            <th>Data</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($apps as $app): ?>
                            <tr>
                                <td data-label="ID"><?=intval($app['id'])?></td>
                                <td data-label="Título"><?=h($app['title'])?></td>
                                <td data-label="Versão"><?=h($app['version'])?></td>
                                <td data-label="Downloads">
                                    <span style="color: #28a745;">⬇️ <?=intval($app['downloads'])?></span>
                                </td>
                                <td data-label="Uploader"><?=h($app['uploader'] ?? '—')?></td>
                                <td data-label="Data"><?=date('d/m/Y', strtotime($app['created_at']))?></td>
                                <td data-label="Ações">
                                    <div class="actions">
                                        <a href="/admin/edit_app.php?id=<?=intval($app['id'])?>" 
                                           class="btn btn-edit">✏️ Editar</a>
                                        <form action="/admin/delete_app.php" method="POST" 
                                              onsubmit="return confirm('Tem certeza que deseja excluir o app \'<?= addslashes($app['title']) ?>\'? Esta ação não pode ser desfeita.')">
                                            <input type="hidden" name="id" value="<?=intval($app['id'])?>">
                                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                            <button type="submit" class="btn btn-delete">🗑️ Excluir</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>">‹ Anterior</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?= $page + 1 ?>">Próxima ›</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script>
        // Melhorar confirmação de exclusão
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('form[action*="delete_app"]');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    if (!confirm('Tem certeza que deseja excluir este app? Esta ação não pode ser desfeita.')) {
                        e.preventDefault();
                    }
                });
            });
        });
    </script>
</body>
</html>