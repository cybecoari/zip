<?php
require_once __DIR__ . '/../functions.php';
$pdo = pdo();
require_admin();

// verificar CSRF
if($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')){
    http_response_code(403);
    exit('Acesso negado.');
}

$id = intval($_POST['id'] ?? 0);
if(!$id){ header('Location: /admin/dashboard.php'); exit; }

// obter paths dos arquivos
$stmt = $pdo->prepare('SELECT file_path, logo_path FROM apps WHERE id = ?');
$stmt->execute([$id]);
$app = $stmt->fetch();

if($app){
    // remover do DB
    $pdo->prepare('DELETE FROM apps WHERE id = ?')->execute([$id]);

    // remover arquivos do disco com segurança
    $uploads_dir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/'; // ajuste conforme config
    foreach(['file_path', 'logo_path'] as $key){
        if(!empty($app[$key])){
            $path = $_SERVER['DOCUMENT_ROOT'] . $app[$key];
            // garantir que está dentro da pasta de uploads
            if(str_starts_with(realpath($path), realpath($uploads_dir)) && file_exists($path)){
                @unlink($path);
            }
        }
    }
}

header('Location: /admin/dashboard.php');
exit;