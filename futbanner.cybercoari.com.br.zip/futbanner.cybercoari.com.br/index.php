<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require_once __DIR__ . '/functions.php';
$pdo = pdo();
$stmt = $pdo->query('SELECT id,title,description,version,logo_path,downloads FROM apps ORDER BY created_at DESC');
$apps = $stmt->fetchAll();
$user = current_user();
$config = require __DIR__ . '/config.php';
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>App Store</title>
<link rel="stylesheet" href="modern-normalize.css">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f4f6;color:#222;margin:0;padding:20px}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}
.card{background:#fff;border-radius:8px;padding:14px;box-shadow:0 2px 6px rgba(0,0,0,0.05);transition:transform 0.2s}
.card:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,0.1)}
.card img{width:64px;height:64px;object-fit:cover;border-radius:8px}
.small{color:#666;font-size:0.9rem}
.btn{display:inline-block;padding:8px 10px;background:#0b6; color:#fff;border-radius:6px;text-decoration:none;transition:background 0.2s}
.btn:hover{background:#095}
.toplinks a{margin-left:8px}
.empty-state{text-align:center;padding:40px;color:#666}
@media (max-width: 768px) {
    .header{flex-direction:column;align-items:flex-start;gap:10px}
    .grid{grid-template-columns:1fr}
}
</style>
</head>
<body>
<header class="header">
  <div>
    <h1>App Store</h1>
    <div class="small">Loja de apps • Faça upload e gerencie via painel</div>
  </div>
  <div class="toplinks">
    <?php if($user): ?>
      Olá, <strong><?=h($user['username'])?></strong>
      <a href="/logout.php">Sair</a>
      <?php if($user['role'] === 'admin'): ?>
        • <a href="/admin/dashboard.php">Admin</a>
      <?php endif; ?>
    <?php else: ?>
      <a href="/login.php">Entrar</a> • <a href="/register.php">Registrar</a>
    <?php endif; ?>
  </div>
</header>

<main>
  <?php if(empty($apps)): ?>
    <div class="empty-state">
      <p>Nenhum app disponível no momento.</p>
      <?php if($user && $user['role'] === 'admin'): ?>
        <a href="/admin/upload.php" class="btn">Adicionar Primeiro App</a>
      <?php endif; ?>
    </div>
  <?php else: ?>
  <div class="grid">
    <?php foreach($apps as $app): ?>
      <article class="card">
        <div style="display:flex;gap:12px;align-items:center">
          <?php if($app['logo_path'] && file_exists($_SERVER['DOCUMENT_ROOT'] . $app['logo_path'])): ?>
            <img src="<?=h($app['logo_path'])?>" alt="Logo <?=h($app['title'])?>" loading="lazy">
          <?php else: ?>
            <div style="width:64px;height:64px;background:#eee;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#666">App</div>
          <?php endif; ?>
          <div>
            <h3 style="margin:0;"><?=h($app['title'])?></h3>
            <div class="small">Versão: <?=h($app['version'])?></div>
          </div>
        </div>
        <p style="margin:12px 0;"><?=nl2br(h($app['description']))?></p>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div class="small">Downloads: <strong><?=h($app['downloads'])?></strong></div>
          <div><a class="btn" href="/download.php?id=<?=intval($app['id'])?>" onclick="this.textContent='Baixando...'">Baixar</a></div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</main>

<script>
// Feedback simples para download
document.addEventListener('click', function(e) {
    if(e.target.classList.contains('btn')) {
        setTimeout(() => {
            e.target.textContent = 'Baixar';
        }, 2000);
    }
});
</script>
</body>
</html>