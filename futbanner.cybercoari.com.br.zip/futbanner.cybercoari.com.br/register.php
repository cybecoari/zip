<?php
require_once __DIR__ . '/functions.php';

$pdo = pdo();
$err = '';

// Verificar se usuário está logado e se é admin
session_start_once();
$current_user = $_SESSION['user'] ?? null;
$is_admin = $current_user && $current_user['role'] === 'admin';

// Se não é admin e está tentando acessar registro (já estando logado como usuário comum)
if ($current_user && !$is_admin) {
    header('Location: /');
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Definir role: se for admin criando, usa o selecionado, senão é sempre 'user'
    $role = 'user';
    if ($is_admin && isset($_POST['role'])) {
        $role = $_POST['role'] === 'admin' ? 'admin' : 'user';
    }

    if(!$username || !$password){
        $err = 'Preencha todos os campos';
    } elseif(strlen($password) < 4){
        $err = 'A senha deve ter pelo menos 6 caracteres';
    } elseif($password !== $confirm_password){
        $err = 'As senhas não coincidem';
    } elseif(strlen($username) < 3){
        $err = 'O usuário deve ter pelo menos 3 caracteres';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare('INSERT INTO users (username, password, role) VALUES (?, ?, ?)');
            $stmt->execute([$username, $hash, $role]);
            
            // Redirecionamento diferente para admin vs registro público
            if ($is_admin) {
                header('Location: /admin/dashboard.php?user_created=1');
            } else {
                header('Location: /login.php?registered=1');
            }
            exit;
        } catch(PDOException $e){
            error_log("Erro ao cadastrar usuário: " . $e->getMessage());
            
            if($e->getCode() == 23000){
                $err = 'Este usuário já existe';
            } else {
                $err = 'Erro ao criar conta. Tente novamente.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= $is_admin ? 'Criar Usuário' : 'Registrar' ?></title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 50px auto; padding: 20px; }
        h2 { text-align: center; color: #333; }
        form { background: #f9f9f9; padding: 20px; border-radius: 8px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input, select { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #0b6; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #095; }
        .error { background: #ffe6e6; color: #b00; padding: 10px; border-radius: 4px; margin-bottom: 15px; text-align: center; }
        .links { text-align: center; margin-top: 15px; }
        .links a { color: #0b6; text-decoration: none; margin: 0 10px; }
        .links a:hover { text-decoration: underline; }
        .requirements { font-size: 0.9rem; color: #666; margin-bottom: 15px; }
        .admin-badge { background: #dc3545; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 8px; }
    </style>
</head>
<body>
    <h2>
        <?php if($is_admin): ?>
            👥 Criar Usuário
        <?php else: ?>
            📝 Registrar
        <?php endif; ?>
    </h2>
    
    <?php if($err): ?>
        <div class="error"><?=h($err)?></div>
    <?php endif; ?>
    
    <form method="post">
        <label>Usuário:</label>
        <input type="text" name="username" value="<?=h($_POST['username'] ?? '')?>" required autofocus>
        
        <label>Senha:</label>
        <input type="password" name="password" required>
        
        <label>Confirmar Senha:</label>
        <input type="password" name="confirm_password" required>
        
        <?php if($is_admin): ?>
            <label>Tipo de Usuário:</label>
            <select name="role">
                <option value="user">Usuário Comum</option>
                <option value="admin" <?= ($_POST['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Administrador</option>
            </select>
        <?php endif; ?>
        
        <div class="requirements">
            • Mínimo 4 caracteres para senha<br>
            • Mínimo 3 caracteres para usuário
            <?php if($is_admin): ?>
                <br>• Você está criando um usuário como <strong>Administrador</strong>
            <?php endif; ?>
        </div>
        
        <button type="submit">
            <?php if($is_admin): ?>
                Criar Usuário
            <?php else: ?>
                Criar Conta
            <?php endif; ?>
        </button>
    </form>
    
    <div class="links">
        <?php if($is_admin): ?>
            <a href="/admin/dashboard.php">← Voltar ao Dashboard</a>
        <?php else: ?>
            <a href="/login.php">🔐 Já tenho conta</a> • 
            <a href="/">🏠 Voltar</a>
        <?php endif; ?>
    </div>
</body>
</html>