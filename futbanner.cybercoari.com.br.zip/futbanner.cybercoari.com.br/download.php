<?php
require_once __DIR__ . '/functions.php';
$pdo = pdo();
$config = require __DIR__ . '/config.php';

$id = intval($_GET['id'] ?? 0);
if(!$id){ header('Location: /'); exit; }

$stmt = $pdo->prepare('SELECT file_path FROM apps WHERE id = ?');
$stmt->execute([$id]);
$app = $stmt->fetch();
if(!$app){ header('HTTP/1.1 404 Not Found'); echo 'App não encontrado'; exit; }

$file = $_SERVER['DOCUMENT_ROOT'] . $app['file_path'];
// Se file_path já for um caminho absoluto ou fora do docroot, ajuste conforme seu caso.
// Melhores práticas: armazene file_path como '/uploads/arquivo.ext' e use $_SERVER['DOCUMENT_ROOT'] . $file_path

if(!file_exists($file)){
  header('HTTP/1.1 404 Not Found'); echo 'Arquivo não encontrado'; exit;
}

// Incrementa contador de downloads de forma segura (apenas DB)
$pdo->prepare('UPDATE apps SET downloads = downloads + 1 WHERE id = ?')->execute([$id]);

// Forçar download
$filename = basename($file);
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.rawurldecode($filename).'"');
header('Content-Length: ' . filesize($file));
readfile($file);
exit;