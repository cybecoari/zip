<?php
require_once __DIR__ . '/functions.php';

$pdo = pdo();
$err = '';
$success = '';

// Verificar se usuário está logado
session_start_once();
$current_user = $_SESSION['user'] ?? null;

if (!$current_user) {
    header('Location: /login.php');
    exit;
}

$is_admin = $current_user['role'] === 'admin';

// Se for admin, pode estar tentando alterar senha de outro usuário
$target_user_id = $current_user['id'];
$target_username = $current_user['username'];

if ($is_admin && isset($_GET['user_id'])) {
    $target_user_id = intval($_GET['user_id']);
    
    // Buscar informações do usuário alvo
    $stmt = $pdo->prepare('SELECT id, username, role FROM users WHERE id = ?');
    $stmt->execute([$target_user_id]);
    $target_user = $stmt->fetch();
    
    if ($target_user) {
        $target_username = $target_user['username'];
    } else {
        $err = 'Usuário não encontrado';
        $target_user_id = $current_user['id'];
        $target_username = $current_user['username'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Para usuários comuns, verificar senha atual
    if (!$is_admin || $target_user_id === $current_user['id']) {
        $current_password = $_POST['current_password'] ?? '';
        
        if (!$current_password) {
            $err = 'Digite sua senha atual';
        } else {
            // Verificar senha atual
            $stmt = $pdo->prepare('SELECT password FROM users WHERE id = ?');
            $stmt->execute([$current_user['id']]);
            $user = $stmt->fetch();
            
            if (!$user || !password_verify($current_password, $user['password'])) {
                $err = 'Senha atual incorreta';
            }
        }
    }
    
    if (!$err) {
        if (!$new_password) {
            $err = 'Digite a nova senha';
        } elseif (strlen($new_password) < 6) {
            $err = 'A senha deve ter pelo menos 6 caracteres';
        } elseif ($new_password !== $confirm_password) {
            $err = 'As senhas não coincidem';
        } else {
            $hash = password_hash($new_password, PASSWORD_DEFAULT);
            
            try {
                $stmt = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
                $stmt->execute([$hash, $target_user_id]);
                
                $success = 'Senha alterada com sucesso!';
                
                // Se admin está alterando própria senha, fazer logout?
                if ($is_admin && $target_user_id === $current_user['id']) {
                    // Pode-se optar por fazer logout ou não
                    // session_destroy();
                    // header('Location: /login.php?password_changed=1');
                    // exit;
                }
                
            } catch (PDOException $e) {
                error_log("Erro ao alterar senha: " . $e->getMessage());
                $err = 'Erro ao alterar senha. Tente novamente.';
            }
        }
    }
}

// Se for admin, buscar lista de usuários para o select
$users = [];
if ($is_admin) {
    $stmt = $pdo->query('SELECT id, username, role FROM users ORDER BY username');
    $users = $stmt->fetchAll();
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Alterar Senha</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 20px; }
        h2 { text-align: center; color: #333; }
        .card { background: #f9f9f9; padding: 25px; border-radius: 8px; margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input, select { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #0b6; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #095; }
        .error { background: #ffe6e6; color: #b00; padding: 12px; border-radius: 4px; margin-bottom: 15px; text-align: center; }
        .success { background: #e6ffe6; color: #0b6; padding: 12px; border-radius: 4px; margin-bottom: 15px; text-align: center; }
        .links { text-align: center; margin-top: 20px; }
        .links a { color: #0b6; text-decoration: none; margin: 0 10px; }
        .links a:hover { text-decoration: underline; }
        .user-info { background: #e6f3ff; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .admin-badge { background: #dc3545; color: white; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; margin-left: 8px; }
        .user-badge { background: #28a745; color: white; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; margin-left: 8px; }
    </style>
</head>
<body>
    <h2>🔐 Alterar Senha</h2>
    
    <?php if($err): ?>
        <div class="error"><?=h($err)?></div>
    <?php endif; ?>
    
    <?php if($success): ?>
        <div class="success"><?=h($success)?></div>
    <?php endif; ?>
    
    <div class="card">
        <?php if($is_admin): ?>
            <!-- Seletor de usuário para admin -->
            <form method="get" action="change_password.php" style="margin-bottom: 20px;">
                <label>Selecionar Usuário:</label>
                <select name="user_id" onchange="this.form.submit()">
                    <option value="">-- Selecione um usuário --</option>
                    <?php foreach($users as $user): ?>
                        <option value="<?=intval($user['id'])?>" 
                                <?= $target_user_id == $user['id'] ? 'selected' : '' ?>>
                            <?=h($user['username'])?>
                            <?php if($user['role'] === 'admin'): ?>
                                <span class="admin-badge">ADMIN</span>
                            <?php else: ?>
                                <span class="user-badge">USER</span>
                            <?php endif; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        <?php endif; ?>
        
        <div class="user-info">
            <strong>Alterando senha para:</strong>
            <?=h($target_username)?>
            <?php if($is_admin && $target_user_id === $current_user['id']): ?>
                <span class="admin-badge">VOCÊ (ADMIN)</span>
            <?php elseif($is_admin): ?>
                <span class="user-badge">OUTRO USUÁRIO</span>
            <?php else: ?>
                <span class="user-badge">SUA CONTA</span>
            <?php endif; ?>
        </div>
        
        <form method="post">
            <?php if(!$is_admin || $target_user_id === $current_user['id']): ?>
                <!-- Campo de senha atual para usuários comuns OU admin alterando própria senha -->
                <label>Senha Atual:</label>
                <input type="password" name="current_password" required>
            <?php endif; ?>
            
            <label>Nova Senha:</label>
            <input type="password" name="new_password" required minlength="6">
            
            <label>Confirmar Nova Senha:</label>
            <input type="password" name="confirm_password" required minlength="6">
            
            <div style="font-size: 0.9rem; color: #666; margin-bottom: 15px;">
                • A senha deve ter no mínimo 6 caracteres
            </div>
            
            <button type="submit">
                <?php if($is_admin && $target_user_id !== $current_user['id']): ?>
                    🔧 Alterar Senha do Usuário
                <?php else: ?>
                    🔐 Alterar Minha Senha
                <?php endif; ?>
            </button>
        </form>
    </div>
    
    <div class="links">
        <?php if($is_admin): ?>
            <a href="/admin/dashboard.php">← Voltar ao Dashboard</a>
        <?php else: ?>
            <a href="/">🏠 Voltar à Loja</a>
        <?php endif; ?>
    </div>
</body>
</html>