<?php
// Ativar exibição de erros para desenvolvimento
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Ativar log de erros
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_error.log');

$config = require __DIR__ . '/config.php';

/**
 * Conexão PDO
 */
function pdo(){
    static $pdo = null;
    global $config;
    if($pdo) return $pdo;

    $db = $config['db'] ?? null;
    if(!$db){
        throw new Exception("Configuração de banco de dados não encontrada.");
    }

    $dsn = "mysql:host={$db['host']};dbname={$db['dbname']};charset={$db['charset']}";
    try {
        $pdo = new PDO($dsn, $db['user'], $db['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (PDOException $e) {
        error_log("Erro PDO: " . $e->getMessage());
        throw $e; // relança para aparecer na tela também
    }

    return $pdo;
}

/**
 * Garante que a pasta de uploads exista
 */
function ensure_uploads(){
    global $config;
    $dir = $config['uploads_dir'] ?? null;
    if(!$dir){
        throw new Exception("Diretório de uploads não configurado.");
    }
    if(!is_dir($dir)){
        if(!mkdir($dir, 0755, true)){
            throw new Exception("Não foi possível criar o diretório de uploads: $dir");
        }
    }
}

/**
 * Escape de HTML
 */
function h($s){
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

/**
 * Inicia a sessão se ainda não estiver iniciada
 */
function session_start_once(){
    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
}

/**
 * Retorna usuário atual
 */
function current_user(){
    session_start_once();
    return $_SESSION['user'] ?? null;
}

/**
 * Verifica login
 */
function require_login(){
    $u = current_user();
    if(!$u){
        header('Location: /login.php');
        exit;
    }
    return $u;
}

/**
 * Verifica se é admin
 */
function require_admin(){
    $u = require_login();
    if($u['role'] !== 'admin'){
        header('HTTP/1.1 403 Forbidden');
        echo 'Acesso negado';
        exit;
    }
    return $u;
}

/**
 * Verifica validade do site (data em tabela config)
 * Se o site estiver expirado, exibe aviso e interrompe a execução
 */
function check_site_expiration($pdo) {
    $stmt = $pdo->query("SELECT site_expiration FROM config LIMIT 1");
    $config = $stmt->fetch();

    if ($config && !empty($config['site_expiration'])) {
        $expiration = strtotime($config['site_expiration']);
        if ($expiration < time()) {
            // Site expirado — bloqueia tudo
            die('<h1 style="text-align:center;color:red;">⚠️ O site expirou!</h1><p style="text-align:center;">Entre em contato com o administrador.</p>');
        }
        return $config['site_expiration'];
    }
    return null;
}

/**
 * Verifica se o usuário está dentro do prazo de validade
 * Retorna true se ainda válido, false se expirado
 */
function is_user_valid($user_id){
    $pdo = pdo();
    $stmt = $pdo->prepare("SELECT expires_at FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if(!$user || empty($user['expires_at'])) return true; // sem data, sempre válido

    $today = new DateTime('today');
    $expires = new DateTime($user['expires_at']);

    return $today <= $expires;
}

/**
 * Retorna a quantidade de dias restantes para o usuário
 * Retorna 0 se expirado ou NULL se sem data
 */
function user_days_remaining($user_id){
    $pdo = pdo();
    $stmt = $pdo->prepare("SELECT expires_at FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if(!$user || empty($user['expires_at'])) return null;

    $today = new DateTime('today');
    $expires = new DateTime($user['expires_at']);

    if($expires < $today) return 0;

    return $today->diff($expires)->days;
}