<?php
// config.php - ajuste conforme ambiente
return [
  'db' => [
    'host' => '127.0.0.1',
    'dbname' => 'cyber_apps',
    'user' => 'cyber_apps',
    'pass' => '@cybercoari',
    'charset' => 'utf8mb4'
  ],
  'uploads_dir' => __DIR__ . '/uploads', // pasta física
  'uploads_url' => '/uploads',           // caminho público no site
  'base_url' => '/'                      // URL base do app
];