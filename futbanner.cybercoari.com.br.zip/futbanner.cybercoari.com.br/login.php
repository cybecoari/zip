<?php
require_once __DIR__ . '/functions.php';
$pdo = pdo();
$err = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if(!$username || !$password) {
        $err = 'Preencha todos os campos';
    } else {
        // Pequeno delay para prevenir força bruta
        usleep(500000); // 0.5 segundos
        
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if($user && password_verify($password, $user['password'])){
            session_start_once();
            unset($user['password']);
            $_SESSION['user'] = $user;
            header('Location: /');
            exit;
        } else {
            $err = 'Credenciais inválidas';
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            max-width: 400px; 
            margin: 50px auto; 
            padding: 20px; }
        h2 { 
            text-align: center; 
            color: #333; }
        form { 
            background: #f9f9f9; 
            padding: 20px; 
            border-radius: 8px; }
        label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: bold; }
        input { 
            width: 100%; 
            padding: 10px; 
            margin-bottom: 15px; 
            border: 1px solid #ddd; 
            border-radius: 4px; 
            box-sizing: border-box; }
        button { 
            width: 100%; 
            padding: 12px; 
            background: #0b6; 
            color: white; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
            font-size: 16px; }
        button:hover { 
            background: #095; }
        .text-center {
            text-align: center;
        }
        .error { 
            background: #ffe6e6; 
            color: #b00; 
            padding: 10px; 
            border-radius: 4px; 
            margin-bottom: 15px; 
            text-align: center; }
        .links { 
            text-align: center; 
            margin-top: 15px; }
        .links a { 
            color: #0b6; 
            text-decoration: none; 
            margin: 0 10px; }
        .links a:hover { 
            text-decoration: underline; }
    </style>
</head>
<body>
   <!-- <?php include __DIR__ . '/includes/contador.php'; ?>-->
    <h2>🔐 Login</h2>
    
      <!-- Contador de Site Online -->
   <!-- <b>
    <div class="text-center">
    <font size='4'>Site Online: <span id="contador">
                            </span>
                          </font>
                          </div>
                        </b> -->
    
    <?php if($err): ?>
        <div class="error"><?=h($err)?></div>
    <?php endif; ?>
    
    <form method="post">
        <label>Usuário:</label>
        <input type="text" name="username" value="<?=h($_POST['username'] ?? '')?>" required autofocus>
        
        <label>Senha:</label>
        <input type="password" name="password" required>
        
        <button type="submit">Entrar</button>
    </form>
    
    <div class="links">
        <a href="/register.php">📝 Registrar</a>  1�7 
        <a href="/">🏠 Voltar</a>
    </div>
</body>
</html>