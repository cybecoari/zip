<?php
require_once __DIR__ . '/../functions.php';
session_start_once();
$user = current_user();

$days = null;
$expired = false;

if($user){
    if(!is_user_valid($user['id'])){
        $expired = true;
    } else {
        $days = user_days_remaining($user['id']);
    }
}
?>

<div class="text-center" style="margin: 15px 0;">
  <b><font size="4">
    <?php if($expired): ?>
        <span style="color:red;">Site Expirado</span>
    <?php elseif($days !== null): ?>
        Site Online: <span id="contador"><?= $days ?> <?= $days === 1 ? 'dia' : 'dias' ?></span>
    <?php else: ?>
        Site Online
    <?php endif; ?>
  </font></b>
</div>