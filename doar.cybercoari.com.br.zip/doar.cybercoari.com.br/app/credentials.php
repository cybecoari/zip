<?php

    // https://www.mercadopago.com.br/developers/pt/docs/credentials
    const MERCADO_PAGO_CONFIG = [
        "access_token"     => "APP_USR-3725334823147849-112610-ccb72a76edc39a5c0902ac0975e8c553-2069289633",
        "notification_url" => "https://example.com/payment/notification.php"
    ];

    const DATABASE_CONFIG = [
        "drive"  => "mysql",
        "host"   => "localhost",
        "user"   => "cyber_doar",
        "pass"   => "@cybercoari",
        "dbname" => "cyber_doar"
    ];