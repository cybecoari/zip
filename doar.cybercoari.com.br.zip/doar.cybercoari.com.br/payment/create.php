<?php

// Conexão e MP config
require_once __DIR__ . '/../app/config.php';

// Verifica dados recebidos
$data = checkDataRequest(requiredFields: ["nickname", "email", "message", "valueToPay"]);

$nickname   = trim($data->nickname);
$email      = trim($data->email);
$message    = trim(htmlspecialchars($data->message)) ?? null;
$valueToPay = (float) str_replace(',', '.', $data->valueToPay);

// VALIDAR EMAIL
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    return jsonResponse("error", "Informe um e-mail válido!");
}

// VALIDAR NICKNAME
if (!preg_match('/^[a-zA-Z0-9_.\s]{2,}$/', $nickname)) {
    return jsonResponse("error", "Informe um apelido válido.");
}

// VALIDAR VALOR
if (!filter_var($valueToPay, FILTER_VALIDATE_FLOAT) || $valueToPay <= 0) {
    return jsonResponse("error", "Informe um valor válido.");
}

// Gerar external_reference (identificador)
$externalReference = bin2hex(random_bytes(16));

// Salva no banco
$sql = "INSERT INTO donations (external_reference, nickname, email, message, value, status) 
        VALUES (:external_reference, :nickname, :email, :message, :value, :status)";

$stmt = $pdo->prepare($sql);

$stmt->bindValue(":external_reference", $externalReference);
$stmt->bindValue(":nickname",           $nickname);
$stmt->bindValue(":email",              $email);
$stmt->bindValue(":message",            $message);
$stmt->bindValue(":value",              $valueToPay);
$stmt->bindValue(":status",             "pending");

$stmt->execute();

$donationId = $pdo->lastInsertId();

if (!$donationId) {
    return jsonResponse("error", "Erro ao salvar a doação no banco.");
}

// DADOS PARA MERCADO PAGO
$payload = [
    "transaction_amount" => $valueToPay,
    "description"        => "Doação de {$nickname}",
    "payment_method_id"  => "pix",
    "external_reference" => $externalReference,
    "notification_url"   => MERCADO_PAGO_CONFIG['notification_url'],
    "payer" => [
        "email"      => $email,
        "first_name" => $nickname
    ]
];

// JSON
$jsonPayload = json_encode($payload);

// REQUISIÇÃO CURL
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL            => "https://api.mercadopago.com/v1/payments",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST  => "POST",
    CURLOPT_POSTFIELDS     => $jsonPayload,
    CURLOPT_HTTPHEADER     => [
        "Authorization: Bearer " . MERCADO_PAGO_CONFIG['access_token'],
        "Content-Type: application/json",
        "X-Idempotency-Key: " . uniqid("pix_", true)
    ]
]);

$response = curl_exec($curl);
curl_close($curl);

// Decodifica resposta
$response = json_decode($response, true);

// ERRO NA API?
if (!isset($response['point_of_interaction']['transaction_data'])) {
    return jsonResponse("error", "Erro ao gerar pagamento PIX.", [
        "mp_raw_response" => $response
    ]);
}

$pix = $response['point_of_interaction']['transaction_data'];

// RETORNO PARA O FRONT-END
return jsonResponse("success", "PIX gerado com sucesso!", [
    "code"               => $pix['qr_code'],
    "qr_code_base64"     => $pix['qr_code_base64'],
    "ticket_url"         => $pix['ticket_url'],
    "external_reference" => $externalReference
]);